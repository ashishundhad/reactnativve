<?php

return [
    'currency' => '₹',
];
