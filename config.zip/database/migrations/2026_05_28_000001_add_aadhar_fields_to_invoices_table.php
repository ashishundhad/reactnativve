<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        $hasAadharCardNumber = Schema::hasColumn('invoices', 'aadhar_card_number');
        $hasAadharPhotos = Schema::hasColumn('invoices', 'aadhar_photos');

        if ($hasAadharCardNumber && $hasAadharPhotos) {
            return;
        }

        Schema::table('invoices', function (Blueprint $table) use ($hasAadharCardNumber, $hasAadharPhotos) {
            if (! $hasAadharCardNumber) {
                $table->string('aadhar_card_number', 12)->nullable()->after('customer_no');
            }

            if (! $hasAadharPhotos) {
                $table->json('aadhar_photos')->nullable()->after('aadhar_card_number');
            }
        });
    }

    public function down(): void
    {
        $columns = array_filter([
            Schema::hasColumn('invoices', 'aadhar_card_number') ? 'aadhar_card_number' : null,
            Schema::hasColumn('invoices', 'aadhar_photos') ? 'aadhar_photos' : null,
        ]);

        if (empty($columns)) {
            return;
        }

        Schema::table('invoices', function (Blueprint $table) use ($columns) {
            $table->dropColumn($columns);
        });
    }
};
