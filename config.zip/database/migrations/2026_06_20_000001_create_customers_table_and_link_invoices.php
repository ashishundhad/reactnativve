<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('customers')) {
            Schema::create('customers', function (Blueprint $table) {
                $table->id();
                $table->string('name');
                $table->string('phone', 20)->nullable()->index();
                $table->text('address')->nullable();
                $table->string('aadhar_card_number', 12)->nullable()->index();
                $table->text('aadhar_photos')->nullable();
                $table->timestamps();
            });
        } else {
            Schema::table('customers', function (Blueprint $table) {
                if (! Schema::hasColumn('customers', 'name')) {
                    $table->string('name')->nullable()->after('id');
                }

                if (! Schema::hasColumn('customers', 'phone')) {
                    $table->string('phone', 20)->nullable()->index()->after('name');
                }

                if (! Schema::hasColumn('customers', 'address')) {
                    $table->text('address')->nullable()->after('phone');
                }

                if (! Schema::hasColumn('customers', 'aadhar_card_number')) {
                    $table->string('aadhar_card_number', 12)->nullable()->index()->after('address');
                }

                if (! Schema::hasColumn('customers', 'aadhar_photos')) {
                    $table->text('aadhar_photos')->nullable()->after('aadhar_card_number');
                }
            });
        }

        if (! Schema::hasColumn('invoices', 'customer_id')) {
            Schema::table('invoices', function (Blueprint $table) {
                $table->foreignId('customer_id')
                    ->nullable()
                    ->after('invoice_no')
                    ->constrained('customers')
                    ->nullOnDelete();
            });
        }

        $hasAadharNumber = Schema::hasColumn('invoices', 'aadhar_card_number');
        $hasAadharPhotos = Schema::hasColumn('invoices', 'aadhar_photos');

        DB::table('invoices')
            ->select([
                'id',
                'customer_name',
                'customer_no',
                'customer_address',
                DB::raw($hasAadharNumber ? 'aadhar_card_number' : 'NULL as aadhar_card_number'),
                DB::raw($hasAadharPhotos ? 'aadhar_photos' : 'NULL as aadhar_photos'),
            ])
            ->whereNotNull('customer_name')
            ->orderBy('id')
            ->chunk(100, function ($invoices): void {
                foreach ($invoices as $invoice) {
                    $name = trim((string) $invoice->customer_name);

                    if ($name === '') {
                        continue;
                    }

                    $phone = $this->cleanPhone($invoice->customer_no);
                    $aadharNumber = trim((string) $invoice->aadhar_card_number) ?: null;
                    $address = trim((string) $invoice->customer_address) ?: null;

                    $query = DB::table('customers');

                    if ($phone !== null) {
                        $query->where('phone', $phone);
                    } else {
                        $query->whereRaw('LOWER(name) = ?', [Str::lower($name)])
                            ->where('address', $address)
                            ->where('aadhar_card_number', $aadharNumber);
                    }

                    $customer = $query->first();

                    if (! $customer) {
                        $customerId = DB::table('customers')->insertGetId([
                            'name' => Str::title($name),
                            'phone' => $phone,
                            'address' => $address,
                            'aadhar_card_number' => $aadharNumber,
                            'aadhar_photos' => $invoice->aadhar_photos ?: null,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    } else {
                        $customerId = $customer->id;

                        DB::table('customers')
                            ->where('id', $customerId)
                            ->update([
                                'name' => $customer->name ?: Str::title($name),
                                'address' => $customer->address ?: $address,
                                'aadhar_card_number' => $customer->aadhar_card_number ?: $aadharNumber,
                                'aadhar_photos' => $customer->aadhar_photos ?: ($invoice->aadhar_photos ?: null),
                                'updated_at' => now(),
                            ]);
                    }

                    DB::table('invoices')
                        ->where('id', $invoice->id)
                        ->update(['customer_id' => $customerId]);
                }
            });
    }

    public function down(): void
    {
        if (Schema::hasColumn('invoices', 'customer_id')) {
            Schema::table('invoices', function (Blueprint $table) {
                $table->dropConstrainedForeignId('customer_id');
            });
        }

        Schema::dropIfExists('customers');
    }

    private function cleanPhone($phone): ?string
    {
        $phone = preg_replace('/\D+/', '', (string) $phone);

        return $phone !== '' && $phone !== '0' ? $phone : null;
    }
};
