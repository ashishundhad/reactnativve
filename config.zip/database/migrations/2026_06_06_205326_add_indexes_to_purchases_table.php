<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('purchases', function (Blueprint $table) {
            $table->index(['deleted', 'is_sold', 'purchase_date'], 'purchases_deleted_sold_date_index');
            $table->index(['deleted', 'color'], 'purchases_deleted_color_index');
            $table->index(['deleted', 'storage'], 'purchases_deleted_storage_index');
            $table->index('imei', 'purchases_imei_index');
            $table->index('model', 'purchases_model_index');
            $table->index('purchase_from', 'purchases_purchase_from_index');
        });
    }

    public function down()
    {
        Schema::table('purchases', function (Blueprint $table) {
            $table->dropIndex('purchases_deleted_sold_date_index');
            $table->dropIndex('purchases_deleted_color_index');
            $table->dropIndex('purchases_deleted_storage_index');
            $table->dropIndex('purchases_imei_index');
            $table->dropIndex('purchases_model_index');
            $table->dropIndex('purchases_purchase_from_index');
        });
    }
};
