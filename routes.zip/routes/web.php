<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{PurchaseController, SettingsController, AdminController, SaleController, InvoiceController, ReportController, ExpenseController, RepairingController, TransactionController, GlobalSearchController};
use App\Models\{Sale, Purchase, Invoice};
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\GoogleContactController;
use App\Http\Controllers\GoogleAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/home', function () {
    return view('welcome');
    // return view('auth.login');
});

Route::get('/', function () {
    // return view('welcome');
    return view('auth.login');
});

Route::get('/dashboard', function (Request $request) {
    $stocksInHand = Purchase::where('is_sold', 0)->where('deleted', 0)->count();
    // $todaysSale = Sale::whereDate('saledate', date('Y-m-d'))->count(); // number of items sold today
    $today = Carbon::today();
    $yesterday = Carbon::yesterday();
    $totalSales = 0;
    $totalSales = Invoice::whereDate('invoice_date', $today)->where('deleted', 0)->sum('net_amount');

    // find sum of total sales in current month
    $startOfMonth = Carbon::now()->startOfMonth();
    $endOfMonth = Carbon::now();  //today's date)
    $sevenDaysAgo = Carbon::now()->subDays(7);
    $currentMonthSales = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
        ->where('deleted', 0)
        ->sum('net_amount');
    // return view('sales.index', ['allSales' => $allSales]);
    $filter = $request->input('filtertime');
    $fromdate = $todate = '';
    $fromdate = Carbon::parse($request->input('fromdate'))->startOfDay();
    $todate = Carbon::parse($request->input('todate'))->startOfDay();
    if ($filter == 'yesterday') {
        $invoices = Invoice::whereDate('invoice_date', $yesterday)->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(10);
        // echo $invoices;
    } elseif ($filter == 'lastweek') {
        $invoices = Invoice::whereBetween('invoice_date', [$sevenDaysAgo, $today])->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(10);
    } elseif ($filter == 'month') {
        $invoices = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(10);
    } elseif ($filter == 'lastmonth') {
        $startOfLastMonth = Carbon::now()->subMonth()->startOfMonth();
        $endOfLastMonth   = Carbon::now()->subMonth()->endOfMonth();

        $invoices = Invoice::whereBetween('invoice_date', [$startOfLastMonth, $endOfLastMonth])
            ->where('deleted', 0)
            ->orderBy('created_at', 'desc')
            ->paginate(10);
    } elseif ($filter == 'custom') {
        $invoices = Invoice::whereBetween('invoice_date', [$fromdate, $todate])->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(10);
    } else {
        $invoices = Invoice::whereDate('invoice_date', $today)->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(10);
    }

    // $todaysSales = Invoice::whereDate('invoice_date', $today)->where('deleted', 0)->orderBy('created_at', 'desc')->get();
    $numberOfProductsSoldInMonth = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
                    ->where('deleted', 0)
                    ->count();

    $lastInvoice = Invoice::orderBy('id', 'desc')->first();
    $currentYear = date('Y');
    $nextInvoiceNo = 1;
    if ($lastInvoice) {
        preg_match('/IF(\d{4})/', $lastInvoice->invoice_no, $matches);
        $lastYear = $matches[1] ?? null;

        if ($lastYear == $currentYear) {
            $lastId = intval(substr($lastInvoice->invoice_no, -4)); // Get the last numeric part
            $nextInvoiceNo = $lastId + 1;
        }
    }

    $formattedNumber = "IF" . $currentYear . str_pad($nextInvoiceNo, 4, '0', STR_PAD_LEFT);
    return view('dashboard', [
        'stocksInHand' => $stocksInHand, 
        'totalSales' => number_format($totalSales, 0, '.', ','),
        'currentMonthSales' => number_format($currentMonthSales, 0, '.', ','),
        'currentMonth' => Carbon::now()->format('F'),
        'numberOfProductsSoldInMonth' => $numberOfProductsSoldInMonth,
        // 'todaysSales' => $todaysSales
        'todaysSales' => $invoices,
        'filtertime' => $filter,
        'fromdate' => $fromdate->format('Y-m-d'),
        'todate' => $todate->format('Y-m-d'),
        'totalRecords' => $invoices->total(),
        'lastId' => $formattedNumber
    ]);

})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/admin/profile', [AdminController::class, 'profile'])->name('admin.profile');
    Route::get('/admin/changepassword', [AdminController::class, 'changePassword'])->name('admin.changepassword');
    Route::put('/admin/reset-password', [AdminController::class, 'newPassword'])->name('reset-password');
    Route::post('/admin/storeprofile', [AdminController::class, 'updateProfile'])->name('store.profile');
});

Route::middleware('auth')->group(function () {
    Route::prefix('admin')->group(function() {
        Route::get('/purchases', [PurchaseController::class, 'index'])->name('allpurchases');
        Route::get('/purchase/add', [PurchaseController::class, 'newPurchase'])->name('purchase.create');
        Route::post('/purchase/add', [PurchaseController::class, 'savePurchase'])->name('purchase.store');
        Route::get('/purchase/edit/{id}', [PurchaseController::class, 'editPurchase'])->name('purchase.edit');
        Route::get('/purchase/edit/{id}', [PurchaseController::class, 'edit'])->name('purchase-edit');
        Route::post('/purchase/update', [PurchaseController::class, 'updatePurchase'])->name('purchase.update');
        Route::delete('/purchase/delete/{id}', [PurchaseController::class, 'deleteStock'])->name('delete-stock');
        Route::get('/purchase-detail/{id}', [PurchaseController::class, 'purchaseDetail'])->name('purchase-detail');
        Route::get('/purchase/import', [PurchaseController::class, 'importStocks'])->name('purchase.importform');
        Route::post('/purchase/importdata', [PurchaseController::class, 'importStocksData'])->name('purchase.import');
        Route::get('/purchase/downloadstock', [PurchaseController::class, 'downloadStock'])->name('purchase.downloadstock');
        Route::get('/purchase/getparties', [PurchaseController::class, 'getParties'])->name('purchase.getchparties');
    });

    //Sales Routes
    Route::prefix('admin/sales')->group(function() {
        Route::get('/', [SaleController::class, 'index'])->name('allsales');
        Route::get('/edit/{id}', [SaleController::class, 'editSale'])->name('saleedit');
        Route::post('/update/{id}', [SaleController::class, 'updateSale'])->name('updateedit');
        Route::get('/detail/{id}', [SaleController::class, 'saleDetail'])->name('saledetail');
        Route::get('/{id}', [SaleController::class, 'solditemDetail'])->name('solditemdetail');
    });
    Route::get('/admin/sale', [SaleController::class, 'newSale'])->name('new-sale');
    Route::post('/admin/sale', [SaleController::class, 'saveSale'])->name('save-sale');
    Route::delete('admin/sale/delete/{id}', [SaleController::class, 'deleteSale'])->name('delete-sale');

    // AJax request for fetching data in create sale
    Route::get('/admin/fetchstockdata/{id}', [SaleController::class, 'fetchModelData'])->name('fetchmodeldata');

    Route::get('/admin/fetchstockonimei/{imei}', [InvoiceController::class, 'fetchModelData'])->name('fetchmodeldata');
    Route::get('/admin/search-imei', [InvoiceController::class, 'searchImei'])->name('search.imei');

    // Invoices
    Route::prefix('admin/invoices')->group(function () {
        Route::get('/', [InvoiceController::class, 'index'])->name('allinvoices');
        Route::get('/add', [InvoiceController::class, 'newInvoice'])->name('newinvoice');
        Route::post('/create-invoice', [InvoiceController::class, 'createInvoice'])->name('create-invoice');
        Route::get('/print/{id}', [InvoiceController::class, 'printInvoice'])->name('print-invoice');
        Route::get('/edit/{id}', [InvoiceController::class, 'editInvoice'])->name('invoice-edit');
        Route::post('/update/{id}', [InvoiceController::class, 'updateInvoice'])->name('invoice-update');
        Route::get('/duplicateprint/{id}', [InvoiceController::class, 'printDuplicateInvoice'])->name('duplicateinvoice');
        Route::get('/duplicate/{id}', [InvoiceController::class, 'duplicateinvoice'])->name('invoice-copy');
        Route::post('/savedummy/{id}', [InvoiceController::class, 'saveDummybill'])->name('savedummybill');
        Route::get('/{id}', [InvoiceController::class, 'invoiceDetail'])->name('invoice-detail');
    });
    //Reports
    Route::prefix('admin/reports')->group(function () {
        Route::get('/sales', [ReportController::class, 'sale'])->name('sale-report')->middleware('checkUser');
        Route::get('/excel', [ReportController::class, 'downloadExcel'])->name('sale-export')->middleware('checkUser');
        Route::get('/buyexcel', [ReportController::class, 'downloadPurchaseExcel'])->name('buy-export')->middleware('checkUser');
        Route::get('/purchasereport', [ReportController::class, 'downloadPurchaseReport'])->name('purchase-report')->middleware('checkUser');
        Route::get('/salescharts', [ReportController::class, 'displayCharts'])->name('saleschart')->middleware('checkUser');
        Route::get('/customers', [ReportController::class, 'customers'])->name('customers')->middleware('checkUser');
        Route::get('/exportcustomers', [ReportController::class, 'exportcustomers'])->name('exportcustomers')->middleware('checkUser');

        Route::match(['get', 'post'], '/admin/reports/analytics', [ReportController::class, 'analytics'])->middleware('checkUser')->name('analytics');
        //transactions
        Route::get('/transactions', [TransactionController::class, 'index'])->name('transactions')->middleware('checkUser');
    });

    // Expense Management
    Route::prefix('admin/expenses')->group(function () {
        Route::get('/', [ExpenseController::class, 'index'])->name('expenses');
        Route::get('/add', [ExpenseController::class, 'addExpense'])->name('add-expense');
        Route::post('/save-expense', [ExpenseController::class, 'saveExpense'])->name('save-expense');
        Route::get('/edit/{id}', [ExpenseController::class, 'editExpense'])->name('edit-expense');
        Route::post('/update', [ExpenseController::class, 'updateExpense'])->name('expenseedit');
        Route::delete('/delete/{id}', [ExpenseController::class, 'deleteExpense'])->name('delete-expense');
    });

    Route::prefix('admin/repairing')->group(function () {
        Route::get('/', [RepairingController::class, 'index'])->name('repairing.list');
        // Route::get('/add', [RepairingController::class, 'create'])->name('repairing.add');
        Route::post('/save', [RepairingController::class, 'store'])->name('repairing.store');
        Route::get('/edit-repairing/{id}', [RepairingController::class, 'editRepairing'])->name('edit-repairing');
        // Route::post('/update/{id}', [RepairingController::class, 'updateRepairing'])->name('repairingedit');
        Route::delete('/delete/{id}', [RepairingController::class, 'deleteRepairing'])->name('delete-repairing');
    });

    Route::get('admin/settings', [SettingsController::class, 'index'])->name('managebusiness');
    Route::post('admin/save-settings', [SettingsController::class, 'store'])->name('save-settings');
    Route::get('/admin/search', [GlobalSearchController::class, 'index'])->name('admin.search');
});

require __DIR__.'/auth.php';

Route::get('/google/redirect', [GoogleContactController::class, 'redirectToGoogle'])->name('google.redirect');
Route::get('/google-callback', [GoogleContactController::class, 'handleGoogleCallback'])->name('google.callback');
Route::post('/sync-contact', [GoogleContactController::class, 'syncContact'])->name('sync.contact');
