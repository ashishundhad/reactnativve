@extends('layout.app')

@section('title', 'Business Management')

@section('content')
<style>
    .dropify-wrapper { height: 90px; }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-10 col-sm-6">
            <h4 class="page-title">Manage Business</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            @include('include.alert')
            <div class="card">
                <div class="card-body">
                    <form class="form-horizontal" method="post" action="{{route('save-settings')}}" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="id" value="{{ $business->id ?? '' }}">
                        <div class="row">
                            <div class="col-lg-3 form-group col-md-3">
                                @if(! empty($business->logo))
                                    <input type="file" data-plugins="dropify" data-max-file-size="1M" name="logo" data-default-file="{{ asset($business->logo)}}"/>
                                @else
                                    <input type="file" data-plugins="dropify" data-max-file-size="1M" name="logo"/>
                                @endif
                                <p class="text-muted text-center mt-2 mb-0 form-control d-none">Upload Logo PNG/JPG/ Max 1M</p>
                                @if(! empty($business->logo))
                                    <img src="{{ asset($business->logo)}}" alt="Business logo" class="img-fluid mt-2">
                                @endif
                            </div>
                            <div class="form-group col-lg-3 col-md-4">
                                <label for="businessname">Business Name<span class="text-danger"> *</span></label>
                                <input type="text" value="{{ $business->business_name ?? '' }}" placeholder="Your Business Name.." class="form-control" name="businessname" required id="businessname"/>
                            </div>
                            <div class="form-group col-lg-3 col-md-4">
                                <label for="businessphone">Phone Number<span class="text-danger"> *</span></label>
                                <input type="text" value="{{$business->phone ?? ''}}" class="form-control" name="phone" placeholder="Business Number.." required id="businessphone"/>
                            </div>
                            <div class="form-group col-lg-3 col-md-4">
                                <label for="businessemail">Company E-Mail</label>
                                <input type="text" value="{{ $business->email ?? '' }}" class="form-control" placeholder="Business Email.." name="email" id="businessemail"/>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-3 form-group col-md-3">
                                <label for="shopaddress">Shop Address <span class="text-danger">*</span></label>
                                <textarea name="billing_address" rows="4" columns="10" class="form-control" required>{{ old('billing_address', $business->billing_address ?? '') }}</textarea>
                            </div>
                            <div class="col-lg-3 form-group col-md-3">
                                <label for="businesstate">State </label>
                                <input type="text" name="state" class="form-control" id="businesstate" placeholder="State" value="{{ $business->state ?? '' }}">
                            </div>
                            <div class="col-lg-3 form-group col-md-3">
                                <label for="businesscity">City <span class="text-danger">*</span></label>
                                <input type="text" name="city" id="businesscity" class="form-control" required placeholder="City" value="{{ $business->city ?? '' }}">
                            </div>
                            <div class="col-lg-3 form-group col-md-3">
                                <label for="pincode">Pincode <span class="text-danger">*</span></label>
                                <input type="text" name="pincode" id="pincode" class="form-control" required placeholder="Pincode" value="{{$business->pincode ?? ''}}"> 
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-3 col-md-3 custom-control custom-switch">
                                <input class="custom-control-input" type="checkbox" name="is_gst_registered" 
                                id="is_gst_registered" 
                                {{ old('is_gst_registered', $business->is_gst_registered ?? 0) == 1 ? 'checked' : '' }}>
                                <label for="is_gst_registered" class="custom-control-label">Are you GST Registered? </label>
                            </div>
                            <div class="form-group col-lg-3 col-md-3 {{ old('is_gst_registered', $business->is_gst_registered ?? 0) == 1 ? '' : 'd-none' }}" id="gstinfield">
                                <label for="gstin">GSTIN <span class="text-danger">*</span> </label>
                                <input type="text" class="form-control" name="gstin" id="gstin" placeholder="Enter GST Number*" value="{{ $business->gstin ?? '' }}">
                            </div>
                            <!-- <div class="form-group col-lg-5 col-md-5">
                                <label>Terms & Condition <span class="text-danger">*</span></label>
                                <textarea name="terms" rows="4" columns="10" class="form-control" required>{{ old('terms', $business->terms ?? '') }}</textarea>
                            </div> -->
                        </div>
                        <div class="row">
                            <div class="form-group mb-3 col-sm-12 col-md-6">
                                <button type="submit" class="btn btn-primary" value="Save Settings"> <i class="mdi mdi-checkbox-marked-circle-outline"></i> Save Settings</button>
                                <!-- <input type="reset" class="btn btn-danger ml-2"> -->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const gstCheckbox = document.getElementById('is_gst_registered');

    gstCheckbox.addEventListener('change', function (e) {
        console.log(this.checked);
        if (this.checked) {
            document.getElementById('gstinfield').classList.remove('d-none');
        } else {
            document.getElementById('gstinfield').classList.add('d-none');
        }
    });
});
</script>
@endsection
