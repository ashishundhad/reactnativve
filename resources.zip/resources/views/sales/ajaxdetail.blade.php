@php
    $expirydate = \Carbon\Carbon::parse($sale->warranty_expiry_date);
    $currentDate = \Carbon\Carbon::now();
@endphp
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-bordered table-centered mb-0">
                    <tbody>
                        <tr>
                            @if($sale->item_description)
                                <th>Item Detail:</th>
                                <td>{!! nl2br(e($sale->item_description)) !!}</td>
                            @endif
                        
                            @if($sale->customer_name)
                                <th>Customer Name:</th>
                                <td>{{ $sale->customer_name }}</td>
                            @endif
                        </tr>
                        
                        <tr>
                            @if($sale->payment_type)
                            <th>Payment Type:</th>
                            <td><span class="badge badge-info text-uppercase">{{ strtoupper($sale->payment_type) }}</span></td>
                            @endif
                            @if($sale->customer_no)
                                <th>Customer No:</th>
                                <td>{{ $sale->customer_no }}</td>
                            @endif
                        </tr>
                        <tr>
                            @if($sale->invoice_date)
                                <th>Sale Date:</th>
                                <td>{{ \Carbon\Carbon::parse($sale->invoice_date)->format('d-m-Y') }}</td>
                            @endif
                            @if($sale->warranty_expiry_date)
                                <th>Warranty Expiry Date:</th>
                                <td>
                                    @if($expirydate->lt($currentDate))
                                    <span class="badge badge-danger text-uppercase">{{ \Carbon\Carbon::parse($sale->warranty_expiry_date)->format('d-m-Y') }}</span>
                                    @else
                                    {{ \Carbon\Carbon::parse($sale->warranty_expiry_date)->format('d-m-Y H:i') }}
                                    @endif
                                </td>
                            @endif
                        </tr>
                        <tr>
                            @if($sale->net_amount)
                                <th>Net Amount:</th>
                                <td>₹{{ $sale->net_amount }}</td>
                            @endif
                            @if($sale->invoice_by)
                                <th>Sold By:</th>
                                <td>{{ $soldBy->name }}</td>
                            @endif
                        </tr>
                        @if (Auth::check() && Auth::user()->id == 1)
                            <tr>
                                @if($sale->profit)
                                    <th>Profit:</th>
                                    <td style="font-weight: bold; font-style: italic;">₹{{ $sale->profit }}</td>
                                @endif
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
