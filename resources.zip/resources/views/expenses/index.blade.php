@extends('layout.app')

@section('title')
    Expenses List
@endsection
@section('content')
<div class="container-fluid">
    
    <!-- start page title -->
    <div class="row align-items-center">
        <!-- Title & Buttons for Mobile -->
        <div class="col-12 d-flex justify-content-between align-items-center mb-2 d-md-none">
            <h4 class="page-title mb-0">Expenseas</h4>
            <div class="d-flex align-items-center mt-2">
                <a href="{{ route('add-expense') }}" class="btn btn-info btn-sm mr-2">
                    <i class="fas fa-sync-alt"></i>
                </a>
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#transactionModal" title="Add Expense">
                    Add 
                </button>
            </div>
        </div>

        <!-- Title for Desktop -->
        <div class="col-md-6 mt-2 mb-2 d-none d-md-block">
            <h4 class="page-title">Expenses</h4>
        </div>

        <!-- Buttons for Desktop -->
        <div class="col-md-6 d-none d-md-flex justify-content-end">
            <a href="{{ route('expenses') }}" class="btn btn-info mr-2">
                <i class="fas fa-sync-alt"></i>
            </a>
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#transactionModal" title="Add Expense">
                <i class="mdi mdi-plus-circle"></i> Add Expense
            </button>
        </div>
    </div>     
    <!-- end page title --> 
    <div class="row">
        <!-- Total Expense Amount -->
        <div class="col-6 col-sm-6 col-md-3 mb-2">
            <div class="card text-white" style="background:#dc3545;">
                <div class="card-body text-center p-2">
                    <p class="font-weight-bold text-uppercase mb-1">Total Expense - {{$month}}</p>
                    <h5 style="color: #fff">{{ config('constant.currency') }} <span id="openingBalance">{{$totalExpenseAmount}}</span></h5>
                </div>
            </div>
        </div>
       <!--  <div class="col-12 col-sm-12 col-md-3">
            <div class="card card-pricing card-pricing-recommended">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Total Expense - {{$month}}</p>
                    <h3 class="text-white">₹{{$totalExpenseAmount}}</h3>
                </div>
            </div>
        </div> -->
    </div>
    <div class="row">
        <div class="col-12">
            @if (session('status'))
            <div class="alert alert-success" id="statusMessage">
                {{ session('status') }}
            </div>
            @endif
            <div class="card-box">
                <!-- <h4 class="header-title mb-4">Expenses</h4> -->
                <form action="{{ route('expenses') }}" method="GET" id="filterexpense">
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="example-password">Select Year</label>
                            <select name="year" class="form-control right" id="selectyear">
                                <option value="2026" @selected($year == 2026)>2026</option>
                                <option value="2025" @selected($year == 2025)>2025</option>
                                <option value="2024" @selected($year == 2024)>2024</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="example-password">Select Month</label>
                            <select name="month" class="form-control right" id="selectmonth">
                                <option value="All" @selected($month == 'All')>- All -</option>
                                <option value="January" @selected($month == 'January')>January</option>
                                <option value="February" @selected($month == 'February')>February</option>
                                <option value="March" @selected($month == 'March')>March</option>
                                <option value="April" @selected($month == 'April')>April</option>
                                <option value="May" @selected($month == 'May')>May</option>
                                <option value="June" @selected($month == 'June')>June</option>
                                <option value="July" @selected($month == 'July')>July</option>
                                <option value="August" @selected($month == 'August')>August</option>
                                <option value="September" @selected($month == 'September')>September</option>
                                <option value="October" @selected($month == 'October')>October</option>
                                <option value="November" @selected($month == 'November')>November</option>
                                <option value="December" @selected($month == 'December')>December</option>
                            </select>
                        </div>
                    </div>
                </form>
                
                <div class="table-responsive">
                    @if(count($expenses) > 0)
                    <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Category</th>
                            <th>Amount(₹)</th>
                            <th>Date</th>
                            <th>Note</th>
                            <th class="hidden-sm">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($expenses as $key=>$expense)
                            <tr>
                                <td>{{$key+1}}</td>
                                <td>{{$expense->expense_category}}</td>
                                <td>{{ number_format($expense->amount, 2) }}</td>
                                <td>{{ \Carbon\Carbon::parse($expense->entrydate)->format('d/m/Y H:i') }}</td>
                                <td>{{ $expense->description ? $expense->description : '-' }}</td>
                                <td>
                                    <div class="btn btn-primary btn-sm edit-expenses mr-1" data-id="{{$expense->id}}" data-toggle="modal" data-target="#editexpenseModal">
                                        <i class="fas fa-edit"></i>
                                    </div>
                                    <form method="post" action="{{ route('delete-expense', $expense->id) }}" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="sureToDelete(event)" title="Delete"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @else
                        <p>No Expense found..</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Expense Modal -->
<div class="modal fade" id="transactionModal" tabindex="-1" role="dialog" aria-labelledby="transactionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="transactionModalLabel">Add Expense</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('save-expense')}}" method="POST" class="form-horizontal" id="addnewexpense">
                @csrf
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="category">Expense Category</label>
                                <select id="category" class="form-control " name="expense_category">
                                    <option value="">Select Category</option>
                                    <option value="general">General</option>
                                    <option value="insurance">Insurance</option>
                                    <option value="maintenance">Maintenance</option>
                                    <option value="petrol">Petrol</option>
                                    <option value="food">Food</option>
                                    <option value="salary">Salary</option>
                                    <option value="rent">Rent</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="payment_date">Expense Date <span class="text-danger">*</span></label>
                                <!-- <input type="date" class="form-control" id="payment_date" name="payment_date" required> -->
                                <input type="datetime-local" id="entrydate" 
                                    class="form-control @error('entrydate') is-invalid @enderror" 
                                    name="entrydate" value="{{ old('entrydate') }}" 
                                    required placeholder="Enter Date">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="amount">Amount <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">{{ config('constant.currency') }}</span>
                                    </div>
                                    <input type="number" class="form-control @error('amount') is-invalid @enderror" id="amount" name="amount" step="0.01" min="0" required>
                                </div>
                            </div>
                        
                            <div class="form-group">
                                <label for="note">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Expense</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="editexpenseModal" tabindex="-1" role="dialog" aria-labelledby="edittransactionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="edittransactionModalLabel">Edit Expense</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="{{route('expenseedit')}}" method="POST" class="form-horizontal">
                @csrf
                <input type="hidden" name="id" id="editexpenseid">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="category">Expense Category</label>
                                <select id="editcategory" class="form-control" name="expense_category">
                                    <option value="General" @if(old('expense_category')=='General') selected @endif>General</option>
                                    <option value="Petrol" @if(old('expense_category')=='Petrol') selected @endif>Petrol</option>
                                    <option value="Food" @if(old('expense_category')=='Food') selected @endif>Food</option>
                                    <option value="salary" @if(old('expense_category')=='salary') selected @endif>Salary</option>
                                    <option value="rent" @if(old('expense_category')=='rent') selected @endif>Rent</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="payment_date">Expense Date <span class="text-danger">*</span></label>
                                <input type="datetime-local" id="editentrydate" 
                                    class="form-control @error('entrydate') parsley-error @enderror" 
                                    name="entrydate" value="" required placeholder="Enter Date">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="amount">Amount <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">{{ config('constant.currency') }}</span>
                                    </div>
                                    <input type="number" class="form-control" value="" id="editamount" name="amount" step="0.01" min="0" required>
                                </div>
                            </div>
                        
                            <div class="form-group">
                                <label for="note">Note</label>
                                <textarea class="form-control" id="editdescription" rows="3" name="description"></textarea>
                            </div>
                        </div>
                    </div>
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update Expense</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    setTimeout(function() {
        document.getElementById('statusMessage')?.remove();
    }, 5000);
</script>
@endsection

@section('scripts')
    <script type="text/javascript">
        $(function () {
            // Form validation
            $("#addnewexpense").validate({
                rules: {
                    expense_category: "required",
                    entrydate: "required",
                    amount: "required"
                },
                messages: {
                    expense_category: "Expense Category Required!",
                    entrydate: "Entrydate Required!",
                    amount: "Amount Required!"
                }
            });
        });
    </script>
@endsection