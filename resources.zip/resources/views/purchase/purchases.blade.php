@extends('layout.app')

@section('title')
    Purchases
@endsection

@section('content')
<style>
    label.error {
        color: #f00;
    }
    /*.mdi.mdi-content-copy {
        position: absolute;
        right: 10px;
        font-size: 20px;
        top: 10px;
        cursor: pointer;
    }*/
    #parties_suggestions {
        position: absolute;
        z-index: 9;
        width: 100%;
        height: auto;
        overflow-y: scroll;
    }
    #parties_suggestions a {
        background-color: aliceblue;
        color: #000;
    }
</style>
<div class="container-fluid">

    <!-- start page title -->
    <div class="row align-items-center">
        <!-- Title & Buttons for Mobile -->
        <div class="col-12 d-flex justify-content-between align-items-center mb-2 d-md-none">
            <h4 class="page-title mb-0">Stock Management</h4>
            <div class="d-flex align-items-center mt-2">
                @if (Auth::check() && Auth::user()->id == 1)
                <a href="{{ request()->fullUrlWithQuery(['download' => 'csv']) }}" class="btn btn-info btn-sm mr-2">
                    <i class="mdi mdi-file-excel-box"></i> Download Stock
                </a>
                @endif
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#purchaseModal">
                    Add Stock
                </button>
            </div>
        </div>

        <!-- Title for Desktop -->
        <div class="col-md-6 mt-2 mb-2 d-none d-md-block">
            <h4 class="page-title">Stock Management</h4>
        </div>

        <!-- Buttons for Desktop -->
        <div class="col-md-6 d-none d-md-flex justify-content-end">
            @if (Auth::check() && Auth::user()->id == 1)
            <a href="{{ request()->fullUrlWithQuery(['download' => 'csv']) }}" class="btn btn-info mr-2">
                <i class="mdi mdi-file-excel-box"></i> Download Stock
            </a>
            @endif
            {{-- <button type="button" class="btn btn-success" data-toggle="modal" data-target="#purchaseModal">
               + Add Stock
            </button> --}}
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-3">
            <div class="card card-pricing" style="background: #08b14a; color:#fff">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Available Stock({{config('constant.currency')}})</p>
                    <h3 class="text-white">{{config('constant.currency')}} {{ number_format($totalStockAmount, 2)}}</h3>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-1">
            <div class="card card-pricing mt-2" style="background: blue; color:blue;">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <h3 class="text-white">+</h3>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-3">
            <div class="card card-pricing" style="background: #4fc6e1; color:#fff">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Repairing ({{config('constant.currency')}})</p>
                    <h3 class="text-white">{{config('constant.currency')}}{{$totalRepairingAmount}}</h3>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-1">
            <div class="card card-pricing mt-2" style="background: blue; color:blue;">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <h3 class="text-white">=</h3>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-3">
            <div class="card card-pricing" style="background: #dd5858; color:#fff">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Total Stock Value</p>
                    <h3 class="text-white">{{config('constant.currency')}}{{$totalRepairingAndStockAmount}}</h3>
                </div>
            </div>
        </div>
    </div>
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            @include('include.alert')
            <div class="card-box">
                @php
                    $activeFilters = [];

                    if (request()->filled('search')) {
                        $activeFilters[] = [
                            'label' => 'Search: ' . request('search'),
                            'remove_url' => route('allpurchases', request()->except('search', 'page')),
                        ];
                    }

                    if (! empty($year)) {
                        $activeFilters[] = [
                            'label' => 'Year: ' . $year,
                            'remove_url' => route('allpurchases', request()->except('year', 'page')),
                        ];
                    }

                    if (! empty($month) && (int) $month >= 1 && (int) $month <= 12) {
                        $monthName = \Carbon\Carbon::create(null, (int) $month, 1)->format('F');
                        $activeFilters[] = [
                            'label' => 'Month: ' . $monthName,
                            'remove_url' => route('allpurchases', request()->except('month', 'page')),
                        ];
                    }

                    if (! empty($storage)) {
                        $activeFilters[] = [
                            'label' => 'Storage: ' . $storage . ' GB',
                            'remove_url' => route('allpurchases', request()->except('storage', 'page')),
                        ];
                    }

                    if (! empty($selectedcolor)) {
                        $activeFilters[] = [
                            'label' => 'Color: ' . $selectedcolor,
                            'remove_url' => route('allpurchases', request()->except('color', 'page')),
                        ];
                    }

                    if ($issold !== null && $issold !== '') {
                        $activeFilters[] = [
                            'label' => 'Status: ' . ($issold == 2 ? 'Available' : 'Sold'),
                            'remove_url' => route('allpurchases', request()->except('is_sold', 'page')),
                        ];
                    }

                    $hasPurchaseFilters = ! empty($activeFilters);
                @endphp
                @if (count($allPurchases) || $hasPurchaseFilters)
                    <h4 class="header-title mb-4">Manage Purchase [{{$totalItems}}]</h4>
                    <form action="{{ route('allpurchases') }}" method="GET" id="filterpurchase">
                        <input type="hidden" name="direction" value="{{ $sortDirection }}">
                        <div class="form-row">
                            <div class="form-group col-md-3 input-group input-group-merge">
                                <input type="text" class="form-control" placeholder="Search ..." name="search" 
                                    value="{{ request()->input('search') }}" id="searchstock">
                                <div class="input-group-append">
                                    <button class="btn btn-dark waves-effect waves-light" type="submit">Search</button>
                                    <a href="{{ route('allpurchases') }}" class="btn btn-light waves-effect waves-light">Reset</a>
                                </div>
                            </div>
                            <div class="form-group col-md-1">
                                <select name="year" class="form-control right" id="selectyear">
                                    <option value="">Year</option>
                                    <option value="2025" @selected($year == 2025)>2025</option>
                                    <option value="2026" @selected($year == 2026)>2026</option>
                                    <option value="2027" @selected($year == 2027)>2027</option>
                                    <option value="2028" @selected($year == 2028)>2028</option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <select name="month" class="form-control right" id="selectmonth">
                                    <option value="">- Month -</option>
                                    <option value="1" @selected($month == 1)>January</option>
                                    <option value="2" @selected($month == 2)>February</option>
                                    <option value="3" @selected($month == 3)>March</option>
                                    <option value="4" @selected($month == 4)>April</option>
                                    <option value="5" @selected($month == 5)>May</option>
                                    <option value="6" @selected($month == 6)>June</option>
                                    <option value="7" @selected($month == 7)>July</option>
                                    <option value="8" @selected($month == 8)>August</option>
                                    <option value="9" @selected($month == 9)>September</option>
                                    <option value="10" @selected($month == 10)>October</option>
                                    <option value="11" @selected($month == 11)>November</option>
                                    <option value="12" @selected($month == 12)>December</option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <select name="storage" class="form-control right" id="selectstorage">
                                    <option value="">-- Storage --</option>
                                    <option value="64" @selected($storage == 64)>64 GB</option>
                                    <option value="128" @selected($storage == 128)>128 GB</option>
                                    <option value="256" @selected($storage == 256)>256 GB</option>
                                    <option value="512" @selected($storage == 512)>512 GB</option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <select name="color" class="form-control right" id="selectcolor">
                                    <option value="">-- Color --</option>
                                    @foreach ($colors as $color)
                                        <option value="{{ $color->color }}" @selected(strtolower($color->color) == strtolower($selectedcolor))>{{ $color->color }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <select name="is_sold" class="form-control right" id="findbysold">
                                    <option value="">-- Select Status --</option>
                                    <option value="2" @selected($issold == 2)>Available</option>
                                    <option value="1" @selected($issold == 1)>Sold</option>
                                </select>
                            </div>
                        </div>

                        @if (! empty($activeFilters))
                            <div class="d-flex flex-wrap align-items-center mb-3" style="gap: 6px;">
                                <span class="text-muted small">Active filters:</span>
                                @foreach ($activeFilters as $filter)
                                    <a href="{{ $filter['remove_url'] }}" class="badge badge-soft-primary border">
                                        {{ $filter['label'] }} <span aria-hidden="true">&times;</span>
                                    </a>
                                @endforeach
                            </div>
                        @endif
                    </form>
                    <div class="table-responsive">
                        <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                            <thead>
                                <tr>
                                    <th>
                                        <a href="{{ route('allpurchases', array_merge(request()->except('page'), ['direction' => $sortDirection == 'asc' ? 'desc' : 'asc'])) }}">
                                        Sr.No
                                        @if ($sortDirection == 'asc')
                                            <i class="fa fa-arrow-up"></i>
                                        @else
                                            <i class="fa fa-arrow-down"></i>
                                        @endif
                                        </a>
                                    </th>
                                    <th>Model</th>
                                    <th>Storage(GB)</th>
                                    <th>Color</th>
                                    <th>Buying Cost</th>
                                    <th>Buy Date</th>
                                    <th>Sale Date</th>
                                    <th>Status</th>
                                    <th class="hidden-sm">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @forelse($allPurchases as $key=>$purchase)
                                    <tr>
                                        <td><a href="javascript:void(0);" data-id="{{$purchase->id}}" class="view-detail-btn"><b>#{{ $purchase->id }}</b></a></td>
                                        <td><a data-id="{{$purchase->id}}" class="view-detail-btn" href="{{route('purchase-detail', $purchase->id)}}">{{ ucfirst($purchase->model) }}</a></td>
                                        {{--<td>{{ $purchase->brand }}</td> --}}
                                        <td>{{ $purchase->storage }}</td>
                                        <td>{{ $purchase->color }}</td>
                                        <td>{{ config('constant.currency') . number_format($purchase->purchase_price, 2) }}</td>
                                        <td>{{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y') }}</td>
                                        <td> @if($purchase->sell_date && $purchase->is_sold) {{ \Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y') }}@else -- @endif</td></td>
                                        <td><span class="badge @if($purchase->is_sold == 1) badge-danger @else badge-success @endif">@if($purchase->is_sold == 1) Sold @else Available @endif</span>
                                        </td>

                                        <td>
                                            <div
                                               data-id="{{$purchase->id}}" 
                                               class="view-detail-btn btn btn-primary btn-sm mr-1 mb-1" 
                                               title="View" >
                                                    <i class="fas fa-eye"></i>
                                            </div>    
                                            {{-- @if($purchase->is_sold == 0) --}}
                                            {{-- <a href="{{route('purchase.edit', $purchase->id)}}" title="Update">
                                                <i class="mdi mdi-square-edit-outline font-18 mr-2 text-muted vertical-middle"></i>
                                            </a> --}}
                                            <div class="btn btn-primary btn-sm edit-transaction mr-1 mb-1" data-id="{{$purchase->id}}">
                                                <i class="fas fa-edit"></i>
                                            </div>
                                            {{-- @endif --}}
                                            <!-- <a href="{{route('purchase-detail', $purchase->id)}}" title="View">
                                                <i class="mdi mdi-eye mr-2 text-muted font-18 vertical-middle"></i>
                                            </a> -->
                                            <form method="post" action="{{ route('delete-stock', $purchase->id) }}" style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm delete-transaction mr-1 mb-1" onclick="sureToDelete(event)" title="Delete"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="text-center text-muted py-4">
                                            No stock found for the selected filters.
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination-links">
                        {{ $allPurchases->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                    </div>
                    @else
                        <h4>No Stock found..</h4>
                        <a href="{{ route('allpurchases') }}" class="btn btn-sm btn-success waves-effect waves-light">
                            <i class="mdi mdi-keyboard-backspace"></i> Back
                        </a>
                    @endif
            </div>
        </div><!-- end col -->
    </div>
    <!-- end row -->
</div> <!-- container -->

<div class="modal fade" id="purchaseModal" tabindex="-1" role="dialog" aria-labelledby="purchaseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="purchaseModalLabel">Add Stock</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form id="purchaseForm" action="{{ route('purchase.store')}}" method="POST" enctype="multipart/form-data" novalidate="novalidate" class="form-horizontal">
                @csrf
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="transaction_type">Device Type <span class="text-danger">*</span></label>
                                <select class="form-control" id="devicetype" name="device_type" required value="{{old('device_type')}}" tabindex="1">
                                    <option value="Phone" @if(old('device_type')=='Phone') selected @endif>Phone</option>
                                    <option value="Tablet" @if(old('device_type')=='Tablet') selected @endif>Tablet</option>
                                    <option value="Laptop" @if(old('device_type')=='Laptop') selected @endif>Laptop</option>
                                    <option value="Accessories" @if(old('device_type')=='Accessories') selected @endif>Accessories</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="payment_date">Model <span class="text-danger">*</span></label>
                                <input type="text" id="model" class="form-control @error('model') parsley-error @enderror" name="model" value="{{ old('model') }}" required tabindex="2" placeholder="Enter Model">
                                @error('model')
                                    <ul class="parsley-errors-list filled"  aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="imei">IMEI(<span id="charCount">0</span></span>) <span class="text-danger">*</label>
                                <input type="text" id="imei" class="form-control @error('imei') parsley-error @enderror" name="imei" value="{{ old('imei') }}" required tabindex="4" placeholder="Enter IMEI">
                                @error('imei')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="storage">Storage(GB) <span class="text-danger">*</span></label>
                                <input type="text" id="storage" class="form-control @error('storage') parsley-error @enderror" name="storage" value="{{ old('storage') }}" required tabindex="5" placeholder="Enter Storage"> 
                                @error('storage')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="warrenty">Brand Warrenty <span class="text-danger">*</span></label>
                                <select class="form-control" id="warrenty" name="warrenty" required>
                                    <option value="Non warrenty" @if(old('warrenty')=='Non warrenty') selected @endif>Non Warrenty</option>
                                    <option value="Warrenty" @if(old('warrenty')=='Warrenty') selected @endif>Warrenty</option>
                                </select>
                                <div class="warrenty_date" style="display: none;">
                                    <input type="date" id="warrentydate" class="form-control " name="warrentydate" value="{{ old('warrentydate') }}" 
                                    placeholder="Warrenty Date">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="color">Color <span class="text-danger">*</span></label>
                                <input type="text" id="color" class="form-control" name="color" value="{{ old('color') }}" tabindex="6" placeholder="Enter color">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="purchasefrom">Party Name <span class="text-danger">*</span></label>
                                <input type="text" id="purchasefrom" class="form-control @error('purchase_from') parsley-error @enderror" name="purchase_from" value="{{ old('purchase_from') }}" required tabindex="7" placeholder="Enter Party" autocomplete="off">
                                <div id="parties_suggestions" class="list-group"></div>
                                @error('purchase_from')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group ">
                                <label for="contactno">Party Contact:</label>
                                <input type="number" id="contactno" class="form-control" name="contactno" value="{{ old('contactno') }}" tabindex="8" placeholder="Enter Party Contact">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="purchasedate">Purchase Date <span class="text-danger">*</span></label>
                                <input type="text" id="purchasedate" class="form-control @error('purchase_date') parsley-error @enderror" name="purchase_date" required tabindex="9" placeholder="Enter Purchase Date" value="{{ old('purchase_date', date('d/m/Y')) }}">
                                @error('purchase_date')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="purchasecost">Purchase Cost({{config('constant.currency')}}):</label>
                                <input type="number" id="purchasecost" name="purchase_cost" class="form-control @error('purchase_cost') parsley-error @enderror" name="purchase_cost" value="{{ old('purchase_cost') }}" required tabindex="10" placeholder="Enter Purchase Cost">
                                @error('purchase_cost')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="repairing_charge">Repairing Charge({{config('constant.currency')}}):</label>
                                <input type="number" id="repairing_charge" placeholder="Repairing Charge" class="form-control" name="repairing_charge" value="{{ old('repairing_charge') }}" tabindex="11">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="remark">Remark:</label>
                                <textarea class="form-control" id="remark" rows="3" name="remark" tabindex="12" placeholder="Remark...">{{ old('remark') }}</textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="document">Documents:</label>
                                <input name="document[]" class="form-control" type="file" id="document" accept=".pdf,image/jpeg,image/png,image/webp" multiple>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="product_photos">Photos:</label>
                                <input name="product_photos[]" class="form-control" type="file" id="product_photos" accept="image/jpeg,image/png,image/webp" multiple>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editpurchaseModal" tabindex="-1" role="dialog" aria-labelledby="editpurchaseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editpurchaseModalLabel">Edit Stock- </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form id="editpurchaseForm" action="{{route('purchase.update')}}" method="POST" enctype="multipart/form-data" novalidate="novalidate" class="form-horizontal">
                @csrf
                <input type="hidden" name="id" id="editpurchaseId">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="transaction_type">Device Type <span class="text-danger">*</span></label>
                                <select class="form-control" id="editdevicetype" name="device_type" required>
                                    <option value="Phone" @if(old('device_type')=='Phone') selected @endif>Phone</option>
                                    <option value="Tablet" @if(old('device_type')=='Tablet') selected @endif>Tablet</option>
                                    <option value="Laptop" @if(old('device_type')=='Laptop') selected @endif>Laptop</option>
                                    <option value="Accessories" @if(old('device_type')=='Accessories') selected @endif>Accessories</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="payment_date">Model <span class="text-danger">*</span></label>
                                <input type="text" id="devicemodel" class="form-control @error('model') parsley-error @enderror" name="model" value="{{ old('model') }}" required tabindex="2" placeholder="Enter Model">
                                @error('model')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="imei">IMEI(<span id="charCount">0</span></span>) <span class="text-danger">*</label>
                                <input type="text" id="deviceimei" class="form-control @error('imei') parsley-error @enderror" name="imei" value="{{ old('imei') }}" required tabindex="4" placeholder="Enter IMEI">
                                @error('imei')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="storage">Storage(GB) <span class="text-danger">*</span></label>
                                <input type="text" id="devicestorage" class="form-control @error('storage') parsley-error @enderror" name="storage" value="{{ old('storage') }}" required tabindex="5" placeholder="Enter Storage"> 
                                @error('storage')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="warrenty">Brand Warrenty:</label>
                                <select class="form-control" id="devicewarrenty" name="warrenty" required>
                                    <option value="Non warrenty" @if(old('warrenty')=='Non warrenty') selected @endif>Non Warrenty</option>
                                    <option value="Warrenty" @if(old('warrenty')=='Warrenty') selected @endif>Warrenty</option>
                                </select>
                                <div class="warrenty_date" style="display: none;">
                                    <input type="date" id="warrentydate" class="form-control " name="warrentydate" value="{{ old('warrentydate') }}" 
                                    placeholder="Warrenty Date">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="color">Color <span class="text-danger">*</span></label>
                                <input type="text" id="devicecolor" class="form-control" name="color" value="{{ old('color') }}" tabindex="6" placeholder="Enter color">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="purchasefrom">Party Name <span class="text-danger">*</span></label>
                                <input type="text" id="devicepurchasefrom" class="form-control @error('purchase_from') parsley-error @enderror" name="purchase_from" value="{{ old('purchase_from') }}" required tabindex="7" placeholder="Enter Party">
                                @error('purchase_from')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group ">
                                <label for="contactno">Party Contact:</label>
                                <input type="number" id="partycontactno" class="form-control" name="contactno" value="{{ old('contactno') }}" tabindex="8" placeholder="Enter Party Contact">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="purchasedate">Purchase Date <span class="text-danger">*</span></label>
                                <input type="date" id="devicepurchasedate" class="form-control @error('purchase_date') parsley-error @enderror" name="purchase_date" value="{{ old('purchase_date') }}" required tabindex="9" placeholder="Enter Purchase Date">
                                @error('purchase_date')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="purchasecost">Purchase Cost({{config('constant.currency')}}):</label>
                                <input type="number" id="devicepurchasecost" name="purchase_cost" class="form-control @error('purchase_cost') parsley-error @enderror" name="purchase_cost" value="{{ old('purchase_cost') }}" required tabindex="10" placeholder="Enter Purchase Cost">
                                @error('purchase_cost')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message}}</li>
                                    </ul>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="repairing_charge">Repairing Charge({{config('constant.currency')}}):</label>
                                <input type="number" id="devicerepairing_charge" placeholder="Repairing Charge" class="form-control" name="repairing_charge" value="{{ old('repairing_charge') }}" tabindex="11">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="remark">Remark:</label>
                                <textarea class="form-control" id="deviceremark" rows="3" name="remark" tabindex="12" placeholder="Remark...">{{ old('remark') }}</textarea>
                            </div>
                        </div>
                        <div class="col-md-6" id="documentPreview">
                            <div class="form-group">
                                <label for="document">Documents:</label>
                                <input name="document[]" class="form-control" type="file" id="document" accept=".pdf,image/jpeg,image/png,image/webp" multiple>
                            </div>
                        </div>
                        <div class="col-md-6" id="productPreview">
                            <div class="form-group">
                                <label for="product_photos">Product Photos:</label>
                                <input name="product_photos[]" class="form-control" type="file" id="product_photos" accept="image/jpeg,image/png,image/webp" multiple>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Product Detail Modal -->
<div class="modal fade" id="productDetailModal" tabindex="-1" role="dialog" aria-labelledby="productDetailLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="productDetailLabel">Stock Detail ID : #</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="product-detail-content">
                <!-- Dynamic content will be loaded here -->
                Loading...
            </div>
        </div>
    </div>
</div>

<script>
    function sureToDelete(e) {
        if(confirm('Are You sure you want to delete this?')){
            return true;
        } else {
            e.preventDefault();
        }
    }

document.addEventListener("DOMContentLoaded", function () {
    const partyInput = document.getElementById("purchasefrom");
    const contactno = document.getElementById("contactno");
    let parties_suggestions = document.getElementById("parties_suggestions");

    partyInput.addEventListener("keyup", function () {
        let query = this.value;
        if (query.length >= 2) {
            fetch(`{{ route('purchase.getchparties') }}?partname=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    parties_suggestions.innerHTML = "";
                    data.forEach(item => {
                        let option = document.createElement("a");
                        option.classList.add("list-group-item", "list-group-item-action");
                        option.textContent = item['purchase_from'];
                        option.href = "#";
                        option.addEventListener("click", function (e) {
                            e.preventDefault();
                            partyInput.value = item['purchase_from'];
                            contactno.value = item['contactno'];
                            parties_suggestions.innerHTML = "";
                            let length = partyInput.value.length;
                            purchasedate.focus();
                            partyInput.setSelectionRange(length, length);
                            // suggestions.hide();
                        });
                        parties_suggestions.appendChild(option);
                    });
                });
        } else {
            parties_suggestions.innerHTML = "";
        }
    });
});
</script>
@endsection

@section('scripts')
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script type="text/javascript">
    $(function () {
        // Form validation
        $("#purchaseForm").validate({
            rules: {
                model: "required",
                color: "required",
                purchase_from: "required"
            },
            messages: {
                model: "Please add Model",
                purchase_from: "Please select Purchase",
                color: "Please select Color"
            }
        });
    });
    $(document).ready(function () {
        $("#purchasedate").datepicker({ dateFormat: 'dd/mm/yy' });

        $("#selectyear, #selectmonth, #selectstorage, #selectcolor, #findbysold").on("change.purchaseFilters", function () {
            $("#filterpurchase").find("input[name='page']").remove();
            $("#filterpurchase").submit();
        });
    });
</script>
@endsection
