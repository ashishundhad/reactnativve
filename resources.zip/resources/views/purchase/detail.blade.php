<!-- <div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Stock Detail ID : #{{ $purchase->id }}</h4>
        </div>
    </div>
</div>  -->
<h4 class="mb-3 mt-0 font-18">{{ $purchase->model }} 
    <span class="ml-4 badge @if($purchase->is_sold == 1) badge-danger @else badge-success @endif">
        @if($purchase->is_sold == 1) Sold @else Available @endif</span>
</h4>
<div class="table-responsive">
    <table class="table table-bordered table-centered mb-0">
        <tbody>
            @if($purchase->device_type)
                <tr>
                    <th>Device Type:</th>
                    <td>
                    @if( $purchase->device_type == 'Phone') 
                        <i class="ti-mobile"></i>
                    @endif
                    @if( $purchase->device_type == 'Tablet') 
                        <i class="ti-tablet"></i>
                    @endif
                    @if( $purchase->device_type == 'Laptop') 
                        <i class="mdi mdi-laptop-mac"></i>
                    @endif
                    @if( $purchase->device_type == 'Accessories') 
                        <i class="mdi mdi-ipod"></i>
                    @endif
                    <span class="badge badge-info text-uppercase">{{ $purchase->device_type }}</span></td>
                </tr>
            @endif
            {{--
            <tr>
                <th>Brand:</th>
                <td>{{ $purchase->brand }}</td>
            </tr>
            --}}
            @if($purchase->imei)
            <tr>
                <th>IMEI:</th>
                <td style="position: relative;">{{ $purchase->imei }} <!--<i class="mdi mdi-content-copy" id="copyButton"></i>--> </td>
            </tr>
            @endif
            @if($purchase->storage)
            <tr>
                <th>Storage(GB):</th>
                <td>{{ $purchase->storage }}</td>
            </tr>
            @endif
            @if($purchase->color)
            <tr>
                <th>Color:</th>
                <td>{{ ucfirst($purchase->color) }}</td>
            </tr>
            @endif
            @if($purchase->purchase_from)
            <tr>
                <th>Purchase From:</th>
                <td>{{ ucfirst($purchase->purchase_from) }}</td>
            </tr>
            @endif
            @if($purchase->contactno)
            <tr>
                <th>Mobile No:</th>
                <td>{{ $purchase->contactno }}</td>
            </tr>
            @endif
        </tbody>
    </table>
</div>

@if ($purchase->document != null)
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Documents</h4>
                    <div class="row">
                    @foreach(explode(',', $purchase->document) as $row)
                        <div class="col-sm-2">
                            @if (pathinfo($row, PATHINFO_EXTENSION) == 'pdf')
                                <a href="{{ asset('documents/purchases/'.$row)}}" class="image-popup" title="{{$purchase->model}}"  target="_blank">
                                    <img src="{{ asset('assets/images/pdf-file.svg') }}" style="height:140px" alt="{{$row}}">
                                </a>
                            @else
                                <a href="{{ asset('documents/purchases/'.$row)}}" class="image-popup" title="{{$purchase->model}}"  target="_blank">
                                    <img src="{{ asset('documents/purchases/'.$row)}}" class="img-fluid rounded" alt="work-thumbnail" style="height:140px">
                                </a>
                            @endif
                        </div>
                    @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
@endif