@extends('layout.app')

@section('title')
    Global Search
@endsection

@section('content')
    <style>
        .global-search-page {
            min-height: calc(100vh - 92px);
            margin: -24px -20px 0;
            padding: 28px 24px 36px;
            background:
                radial-gradient(circle at top right, rgba(59, 130, 246, 0.12), transparent 22%),
                radial-gradient(circle at left bottom, rgba(16, 185, 129, 0.12), transparent 26%),
                linear-gradient(180deg, #f5f7fb 0%, #edf2f7 100%);
        }

        .global-search-hero {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 24px;
            padding: 24px;
            border: 1px solid rgba(219, 228, 238, 0.95);
            border-radius: 24px;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.06);
        }

        .global-search-hero__title {
            margin: 0;
            color: #17324d;
            font-size: 28px;
            font-weight: 800;
        }

        .global-search-hero__text {
            margin: 8px 0 0;
            max-width: 640px;
            color: #64748b;
            font-size: 15px;
            line-height: 1.6;
        }

        .global-search-hero__summary {
            min-width: 220px;
            padding: 16px 18px;
            border-radius: 18px;
            background: linear-gradient(135deg, #17324d 0%, #28527a 100%);
            color: #fff;
        }

        .global-search-hero__summary-label {
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            opacity: 0.74;
        }

        .global-search-hero__summary-value {
            margin-top: 8px;
            font-size: 30px;
            font-weight: 800;
            line-height: 1;
        }

        .global-search-hero__summary-note {
            margin-top: 8px;
            font-size: 13px;
            opacity: 0.8;
        }

        .global-search-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 22px;
        }

        .global-search-section {
            border: 1px solid #dbe4ee;
            border-radius: 22px;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 0 18px 36px rgba(15, 23, 42, 0.05);
            overflow: hidden;
        }

        .global-search-section__head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 18px 20px;
            border-bottom: 1px solid #edf2f7;
        }

        .global-search-section__title {
            margin: 0;
            color: #17324d;
            font-size: 18px;
            font-weight: 800;
        }

        .global-search-section__count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 34px;
            height: 34px;
            padding: 0 12px;
            border-radius: 999px;
            background: #eff6ff;
            color: #1d4ed8;
            font-size: 13px;
            font-weight: 800;
        }

        .global-search-results {
            padding: 18px;
            display: grid;
            gap: 14px;
        }

        .search-card {
            display: block;
            padding: 18px;
            border: 1px solid #e2e8f0;
            border-radius: 18px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
            text-decoration: none !important;
            color: inherit;
            box-shadow: 0 12px 24px rgba(15, 23, 42, 0.04);
            transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
        }

        .search-card:hover {
            transform: translateY(-2px);
            border-color: #bfdbfe;
            box-shadow: 0 18px 30px rgba(37, 99, 235, 0.12);
        }

        .search-card__top,
        .search-card__bottom {
            display: flex;
            justify-content: space-between;
            gap: 14px;
        }

        .search-card__top {
            align-items: flex-start;
            margin-bottom: 14px;
        }

        .search-card__title {
            margin: 0 0 6px;
            color: #0f172a;
            font-size: 18px;
            font-weight: 800;
        }

        .search-card__meta {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 5px 10px;
            border-radius: 999px;
            background: #eff6ff;
            color: #1d4ed8;
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }

        .search-card__label,
        .search-card__value,
        .search-card__price {
            color: #475569;
            font-size: 13px;
        }

        .search-card__value strong,
        .search-card__price strong {
            color: #0f172a;
            font-weight: 800;
        }

        .search-card__price {
            text-align: right;
            white-space: nowrap;
        }

        .search-card__tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }

        .search-card__tag {
            display: inline-flex;
            align-items: center;
            padding: 6px 10px;
            border-radius: 999px;
            background: #f1f5f9;
            color: #334155;
            font-size: 12px;
            font-weight: 700;
        }

        .search-state {
            padding: 42px 24px;
            text-align: center;
            color: #64748b;
        }

        .search-state__icon {
            font-size: 34px;
            color: #94a3b8;
            margin-bottom: 10px;
        }

        .search-state__title {
            margin: 0;
            color: #17324d;
            font-size: 18px;
            font-weight: 800;
        }

        .search-state__text {
            margin: 10px auto 0;
            max-width: 420px;
            font-size: 14px;
            line-height: 1.6;
        }

        @media (max-width: 991.98px) {
            .global-search-hero,
            .global-search-grid {
                grid-template-columns: 1fr;
                display: grid;
            }

            .global-search-hero__summary {
                min-width: 0;
            }
        }
    </style>

    @php
        $totalResults = $purchaseResults->count() + $invoiceResults->count();
    @endphp

    <div class="global-search-page">
        <div class="global-search-hero">
            <div>
                <h1 class="global-search-hero__title">Global Search</h1>
               <!--  <p class="global-search-hero__text">
                    Search across purchase stock and invoices from one place. You can look up inventory items,
                    invoice numbers, customer names, IMEI values, and purchase sources.
                </p> -->
            </div>

            <div class="global-search-hero__summary">
                <div class="global-search-hero__summary-label">Search Results</div>
                <div class="global-search-hero__summary-value">{{ $totalResults }}</div>
                <div class="global-search-hero__summary-note">
                    @if($query !== '')
                        Showing matches for "{{ $query }}"
                    @else
                        Start with a keyword from the top bar search.
                    @endif
                </div>
            </div>
        </div>

        @if($query === '')
            <div class="global-search-section">
                <div class="search-state">
                    <div class="search-state__icon">
                        <i class="mdi mdi-magnify"></i>
                    </div>
                    <h2 class="search-state__title">Search purchases and invoices</h2>
                    <p class="search-state__text">
                        Try an invoice ID, customer name, model, IMEI, or supplier name like purchase_from to quickly
                        jump to the right record.
                    </p>
                </div>
            </div>
        @else
            <div class="global-search-grid">
                <section class="global-search-section">
                    <div class="global-search-section__head">
                        <h2 class="global-search-section__title">Purchase Matches</h2>
                        <span class="global-search-section__count">{{ $purchaseResults->count() }}</span>
                    </div>

                    @if($purchaseResults->isEmpty())
                        <div class="search-state">
                            <div class="search-state__icon">
                                <i class="mdi mdi-package-variant-closed"></i>
                            </div>
                            <h3 class="search-state__title">No purchase matches</h3>
                            <p class="search-state__text">No stock records matched "{{ $query }}".</p>
                        </div>
                    @else
                        <div class="global-search-results">
                            @foreach($purchaseResults as $purchase)
                                <a href="{{route('purchase-detail', $purchase->id)}}" class="search-card">
                                    <div class="search-card__top">
                                        <div>
                                            <div class="search-card__meta">Purchase #{{ $purchase->id }}</div>
                                            <h3 class="search-card__title">{{ ucfirst($purchase->model) }}</h3>
                                            <div class="search-card__value">
                                                <strong>IMEI:</strong> {{ $purchase->imei }}
                                            </div>
                                        </div>

                                        <div class="search-card__price">
                                            <strong>{{ config('constant.currency') . number_format((float) $purchase->purchase_price, 2) }}</strong>
                                        </div>
                                    </div>

                                    <div class="search-card__bottom">
                                        <div class="search-card__label">
                                            <strong>Purchase From:</strong> {{ $purchase->purchase_from ?: 'N/A' }}<br>
                                            <strong>Date:</strong>
                                            {{ $purchase->purchase_date ? \Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y') : 'N/A' }}
                                        </div>

                                        <div class="search-card__label text-right">
                                            <strong>Status:</strong> {{ $purchase->is_sold ? 'Sold' : 'Available' }}<br>
                                            <strong>Store:</strong> {{ ucfirst($purchase->storelocation ?: 'N/A') }}
                                        </div>
                                    </div>

                                    <div class="search-card__tags">
                                        @if($purchase->storage)
                                            <span class="search-card__tag">{{ $purchase->storage }} GB</span>
                                        @endif
                                        @if($purchase->color)
                                            <span class="search-card__tag">{{ ucfirst($purchase->color) }}</span>
                                        @endif
                                        @if($purchase->contactno)
                                            <span class="search-card__tag">{{ $purchase->contactno }}</span>
                                        @endif
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    @endif
                </section>

                <section class="global-search-section">
                    <div class="global-search-section__head">
                        <h2 class="global-search-section__title">Invoice Matches</h2>
                        <span class="global-search-section__count">{{ $invoiceResults->count() }}</span>
                    </div>

                    @if($invoiceResults->isEmpty())
                        <div class="search-state">
                            <div class="search-state__icon">
                                <i class="mdi mdi-receipt"></i>
                            </div>
                            <h3 class="search-state__title">No invoice matches</h3>
                            <p class="search-state__text">No invoice records matched "{{ $query }}".</p>
                        </div>
                    @else
                        <div class="global-search-results">
                            @foreach($invoiceResults as $invoice)
                                <a href="{{ route('print-invoice', $invoice->id) }}"
                                    class="search-card">
                                    <div class="search-card__top">
                                        <div>
                                            <div class="search-card__meta">#{{ $invoice->invoice_no ?: 'Invoice #' . $invoice->id }}</div>
                                            <h3 class="search-card__title">{{ $invoice->customer_name }}</h3>
                                            <div class="search-card__value">
                                                <strong>Customer No:</strong> {{ $invoice->customer_no ?: 'N/A' }}
                                            </div>
                                        </div>
                                        
                                        <div class="search-card__price">
                                            <strong>{{ config('constant.currency') . number_format((float) $invoice->net_amount, 2) }}</strong>
                                        </div>
                                    </div>

                                    <div class="search-card__bottom">
                                        <div class="search-card__label">
                                            <strong>Invoice Date:</strong>
                                            {{ $invoice->invoice_date ? \Carbon\Carbon::parse($invoice->invoice_date)->format('d M Y') : 'N/A' }}<br>
                                            <strong>Payment:</strong> {{ $invoice->payment_type ?: 'N/A' }}
                                        </div>

                                        <div class="search-card__label text-right">
                                            <strong>ID:</strong> #{{ $invoice->id }}
                                        </div>
                                    </div>
                                </a>
                            @endforeach
                        </div>
                    @endif
                </section>
            </div>
        @endif
    </div>
@endsection
