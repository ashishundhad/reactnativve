@extends('layout.app')

@section('title')
    Purchase Report
@endsection
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Purchases Report</h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12">
            <form action="{{ route('purchase-report') }}" method="GET" id="purchaseexportreport" class="mb-3">
                <div class="form-row align-items-center">
                    <div class="col-12 col-md-3">
                        <select name="period" class="form-control" id="purchasedownloadperiod">
                            <option value="alls" @selected($timePeriod == 'alls')>All Purchase</option>
                            <option value="thismonth" @selected($timePeriod == 'thismonth')>This Month</option>
                            <option value="lastmonth" @selected($timePeriod == 'lastmonth')>Last Month</option>
                            <option value="thisyear" @selected($timePeriod == 'thisyear')>This Year</option>
                            <option value="custom" @selected($timePeriod == 'custom')>Custom</option>
                        </select>
                    </div>
                    <div class="col-auto">
                        <input type="date" id="fromdate" name="fromdate" class="form-control" value="" style="display:none;">
                    </div>
                    <div class="col-auto">
                        <input type="date" id="todate" name="todate" class="form-control" value="" style="display:none;">
                    </div>
                    <!-- <div class="col-auto col-12 col-md-3 mt-3 mt-md-0">
                        <input type="submit" value="Download Purchase Data" class="form-control btn btn-primary waves-effect waves-light">
                    </div> -->
                </div>
            </form>
            <form action="{{ route('buy-export') }}" method="GET" id="downloadpurchasereport" class="mb-3">
                <div class="col-auto col-12 col-md-3 mt-3 mt-md-0">
                    <input type="hidden" value="" id="selectedperiodforbuyreport" name="period">
                    <input type="hidden" id="fromdatebuy" name="fromdate" value="">
                    <input type="hidden" id="todatebuy" name="todate" value="">
                    <button class="form-control btn btn-primary waves-effect waves-light" id="clicktodownloadpurchasereport">Download Purchase Data</button>
                </div>
            </form>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-12 col-sm-12 col-md-3">
            <a href="{{ route('buy-export')}}" class="btn btn-primary"><i class="mdi mdi-file-excel-box"></i> Download Buy Excel</a>
        </div>
    </div> -->
    <div class="row mt-2">
        <div class="col-12 col-sm-12 col-md-3">
            <div class="card card-pricing card-pricing-recommended">
                <div class="card-body text-center" style="padding: 0.5rem;">
                    <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Total Stock in Price - {{$timePeriod}}</p>
                    <h3 class="text-white">{{$totalPurchaseAmount}}</h3>
                </div>
            </div>
        </div>
    </div>
@endsection