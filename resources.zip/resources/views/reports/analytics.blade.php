@extends('layout.app')

@section('title')
    Analytics
@endsection

@section('content')
    <style>
        .month-card {
            border-radius: 16px;
            border: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            background: white;
            overflow: hidden;
        }

        .month-card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.25rem;
            text-align: center;
            font-weight: 700;
            font-size: 1.25rem;
            letter-spacing: 0.5px;
            position: relative;
        }

        .month-card-header .toggle-icon {
            position: absolute;
            right: 1.25rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1rem;
            transition: transform 0.3s ease;
            display: none;
        }

        .month-card-header.collapsed .toggle-icon {
            transform: translateY(-50%) rotate(-180deg);
        }

        .month-card-body {
            padding: 1.5rem;
            transition: max-height 0.3s ease, opacity 0.3s ease;
        }

        .metric-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid #e2e8f0;
        }

        .metric-row:last-child {
            border-bottom: none;
        }

        .metric-label {
            font-size: 0.9rem;
            font-weight: 600;
            color: #4a5568;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .metric-icon {
            font-size: 1.1rem;
            width: 24px;
            text-align: center;
        }

        .metric-value {
            font-size: 1.1rem;
            font-weight: 700;
        }

        .metric-value.sales {
            color: #667eea;
        }

        .metric-value.profit {
            color: #10b981;
        }

        .metric-value.expense {
            color: #ef4444;
        }

        .metric-value.netprofit {
            color: #059669;
        }

        .metric-value.netprofit-negative {
            color: #dc2626;
        }

        .filter-section {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .form-label {
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 0.5rem;
        }

        .btn-filter {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 0.75rem 2rem;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            transition: all 0.3s ease;
        }

        .btn-filter:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
        }

        /*.month-card-body {
            overflow: hidden;
            transition: max-height 0.3s ease;
            max-height: 2000px; 
        }

        .month-card-body.collapsed {
            max-height: 0;
        }*/

        @media (max-width: 768px) {
            .month-card {
                margin-bottom: 1.5rem;
            }

            .month-card-header {
                font-size: 1.1rem;
                padding: 1rem;
                cursor: pointer;
                user-select: none;
            }

            .month-card-header .toggle-icon {
                display: block;
            }

            .month-card-body {
                padding: 1.25rem;
                transition: max-height 0.3s ease, opacity 0.3s ease, padding 0.3s ease, margin 0.3s ease;
                overflow: hidden;
            }

            .month-card-body.collapsed {
                max-height: 0 !important;
                padding: 0 1.25rem !important;
                margin: 0 !important;
                opacity: 0;
            }

            .metric-label {
                font-size: 0.85rem;
            }

            .metric-value {
                font-size: 1rem;
            }

            .filter-section {
                padding: 1rem;
            }

            .filter-section .row {
                align-items: flex-end;
            }

            .filter-mobile-row {
                display: flex;
                gap: 0.5rem;
                align-items: flex-end;
            }

            .filter-mobile-row > div:first-child {
                flex: 1;
                min-width: 0;
            }

            .filter-btn-mobile {
                flex-shrink: 0;
                margin-bottom: 0;
            }

            .filter-btn-mobile .btn-filter {
                white-space: nowrap;
                padding: 0.625rem 1.25rem;
                height: 38px;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .filter-mobile-row .form-label {
                margin-bottom: 0.5rem;
            }
        }
    </style>

    <!-- Page Title -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Analytics Dashboard</h4>
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-section">
        <form method="POST" action="{{ route('analytics') }}" id="analyticsFilter" class="row g-3 align-items-end">
            @csrf
            <!-- Dropdown and Filter Button Container for Mobile -->
            <div class="col-12 col-md-4 d-flex align-items-end filter-mobile-row">
                <div class="w-100">
                    <label for="period" class="form-label">Filter Period</label>
                    <select name="period" class="form-control" id="selectPeriod">
                        <option value="thisyear" @selected($period == 'thisyear')>This Year</option>
                        <option value="lastyear" @selected($period == 'lastyear')>Last Year</option>
                        <option value="lastmonth" @selected($period == 'lastmonth')>Last Month</option>
                        <option value="last3months" @selected($period == 'last3months')>Last 3 Month</option>
                        <option value="last6months" @selected($period == 'last6months')>Last 6 Month</option>
                        <option value="custom" @selected($period == 'custom')>Custom</option>
                    </select>
                </div>
                <!-- Filter Button for Mobile -->
                <div class="filter-btn-mobile d-md-none">
                    <button type="submit" class="btn btn-filter text-white">
                        <i class="fa fa-filter"></i>&nbsp; Filter
                    </button>
                </div>
            </div>

            <!-- Custom Date Range -->
            <div class="col-md-3 date-range-field" style="display: {{ $period == 'custom' ? 'block' : 'none' }};">
                <label for="fromdate" class="form-label">From Date</label>
                <input type="date" id="fromdate" name="fromdate"
                    class="form-control" value="{{ $fromdate }}">
            </div>
            <div class="col-md-3 date-range-field" style="display: {{ $period == 'custom' ? 'block' : 'none' }};">
                <label for="todate" class="form-label">To Date</label>
                <input type="date" id="todate" name="todate"
                    class="form-control" value="{{ $todate }}">
            </div>

            <!-- Filter Button for Desktop -->
            <div class="col-12 col-md-2 d-none d-md-flex align-items-end">
                <button type="submit" class="btn btn-filter w-100 text-white">
                    <i class="fa fa-filter"></i> Filter
                </button>
            </div>
        </form>
    </div>

    <!-- Analytics Cards -->
    @if(count($monthlyData) > 0)
        <div class="row g-4">
            @foreach($monthlyData as $index => $data)
                <div class="col-lg-4 col-md-6 col-sm-12 card-container">
                    <div class="card month-card">
                        <div class="month-card-header" data-toggle="collapse" data-target="#monthBody{{ $index }}" aria-controls="monthBody{{ $index }}">
                            {{ $data['monthName'] }}
                            <i class="fa fa-chevron-down toggle-icon"></i>
                        </div>
                        <div class="month-card-body collapse show" id="monthBody{{ $index }}">
                            <div class="metric-row">
                                <div class="metric-label">
                                    <span class="metric-icon"><i class="fa fa-shopping-cart"></i></span>
                                    <span>Total Sales</span>
                                </div>
                                <div class="metric-value sales">
                                    ₹{{ number_format($data['totalSales'], 2) }}
                                </div>
                            </div>

                            <div class="metric-row">
                                <div class="metric-label">
                                    <span class="metric-icon"><i class="fa fa-chart-line"></i></span>
                                    <span>Total Profit</span>
                                </div>
                                <div class="metric-value profit">
                                    ₹{{ number_format($data['totalProfit'], 2) }}
                                </div>
                            </div>

                            <div class="metric-row">
                                <div class="metric-label">
                                    <span class="metric-icon"><i class="fe-settings noti-icon"></i></span>
                                    <span>Total Repairing</span>
                                </div>
                                <div class="metric-value repairing  ">
                                    ₹{{ number_format($data['totalRepairing'], 2) }}
                                </div>
                            </div>

                            <div class="metric-row">
                                <div class="metric-label">
                                    <span class="metric-icon"><i class="fa fa-wallet"></i></span>
                                    <span>Total Expense</span>
                                </div>
                                <div class="metric-value expense">
                                    ₹{{ number_format($data['totalExpense'], 2) }}
                                </div>
                            </div>

                            <!-- Net Profit -->
                            <div class="metric-row">
                                <div class="metric-label">
                                    <span class="metric-icon"><i class="fa fa-money-bill-wave"></i></span>
                                    <span>Net Profit</span>
                                </div>
                                <div class="metric-value {{ $data['netProfit'] >= 0 ? 'netprofit' : 'netprofit-negative' }}">
                                    ₹{{ number_format($data['netProfit'], 2) }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <!-- No Data Message -->
        <div class="row">
            <div class="col-12">
                <div class="alert alert-info text-center py-4">
                    <h5 class="mb-0">No data available for the selected period.</h5>
                </div>
            </div>
        </div>
    @endif

@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            // Show/hide date inputs and labels based on period selection
            $('#selectPeriod').on('change', function() {
                if ($(this).val() === 'custom') {
                    $('.date-range-field').show();
                } else {
                    $('.date-range-field').hide();
                }
            });

            // Initialize on page load
            if ($('#selectPeriod').val() === 'custom') {
                $('.date-range-field').show();
            } else {
                $('.date-range-field').hide();
            }

            // Mobile card collapse/expand functionality
            function isMobile() {
                return window.innerWidth <= 768;
            }

            function initCardToggle() {
                $('.month-card-header').off('click');

                if (isMobile()) {
                    $('.month-card-header').on('click', function () {
                        const $header = $(this);
                        const $body = $header.next('.month-card-body');

                        $header.toggleClass('collapsed');
                        $body.toggleClass('collapsed');
                    });

                    Ensure cards start OPEN
                    $('.month-card-body').removeClass('collapsed');
                    $('.month-card-header').removeClass('collapsed');

                } else {
                    // Desktop reset
                    $('.month-card-header').off('click').removeClass('collapsed');
                    $('.month-card-body').removeClass('collapsed').css('max-height', '');
                }
            }

            // Initialize on load
            initCardToggle();

            // Re-initialize on window resize
            $(window).on('resize', function() {
                initCardToggle();
            });
        });
    </script>
@endsection
