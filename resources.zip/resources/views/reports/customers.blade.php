@extends('layout.app')

@section('title')
    Customers
@endsection
@section('content')
    <style>
        .customer-summary-card {
            border: 1px solid #edf1f5;
            border-radius: 6px;
            background: #fff;
            padding: 14px 16px;
            height: 100%;
        }

        .customer-summary-label {
            color: #6c757d;
            font-size: 12px;
            margin-bottom: 4px;
            text-transform: uppercase;
        }

        .customer-summary-value {
            color: #323a46;
            font-size: 22px;
            font-weight: 600;
            line-height: 1.2;
        }

        .customer-name {
            font-weight: 600;
            color: #323a46;
        }

        .customer-muted {
            color: #6c757d;
            font-size: 12px;
        }

        .customer-proof-actions {
            gap: 6px;
        }
    </style>

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Customers</h4>
            </div>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-md-4 mb-2">
            <div class="customer-summary-card">
                <div class="customer-summary-label">Total Customers</div>
                <div class="customer-summary-value">{{ $totalcustomers }}</div>
            </div>
        </div>
        <div class="col-md-4 mb-2">
            <div class="customer-summary-card">
                <div class="customer-summary-label">Total Invoices</div>
                <div class="customer-summary-value">{{ $customers->sum('invoices_count') }}</div>
            </div>
        </div>
        <div class="col-md-4 mb-2">
            <div class="customer-summary-card">
                <div class="customer-summary-label">Total Customer Sales</div>
                <div class="customer-summary-value">Rs. {{ number_format($customers->sum('total_spent'), 2) }}</div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1">Customer Report</h5>
                    <div class="text-muted font-13">Newest customer activity is shown first.</div>
                </div>
                <div>
                    <a href="{{ route('exportcustomers') }}" class="btn btn-sm btn-primary">
                        <i class="mdi mdi-file-excel-box"></i> Download Customers
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0" id="customers-list">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Customer</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th>Invoices</th>
                            <th>Total Sales</th>
                            <th>Last Purchase</th>
                            <th>Aadhar</th>
                            <th>Proof Photos</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $index => $customer)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>
                                    <div class="customer-name">{{ $customer->name ?: '-' }}</div>
                                    <div class="customer-muted">ID: {{ $customer->id }}</div>
                                </td>
                                <td>
                                    @if($customer->phone)
                                        <a href="tel:{{ $customer->phone }}">{{ $customer->phone }}</a>
                                    @else
                                        -
                                    @endif
                                </td>
                                <td>
                                    @if($customer->address)
                                        <span>{{ $customer->address }}</span>
                                    @else
                                        -
                                    @endif
                                </td>
                                <td>{{ $customer->invoices_count }}</td>
                                <td>Rs. {{ number_format((float) $customer->total_spent, 2) }}</td>
                                <td>
                                    @if($customer->last_invoice_date)
                                        {{ \Carbon\Carbon::parse($customer->last_invoice_date)->format('d M Y') }}
                                    @else
                                        -
                                    @endif
                                </td>
                                <td>{{ $customer->aadhar_card_number ?: '-' }}</td>
                                <td>
                                    @if(! empty($customer->aadhar_photos))
                                        <div class="d-flex flex-wrap customer-proof-actions">
                                            @foreach ($customer->aadhar_photos_array as $photo)
                                                <button type="button"
                                                    class="btn btn-sm btn-outline-primary aadhar-image"
                                                    data-image="{{ $customer->aadharPhotoUrl($photo) }}">
                                                    <i class="mdi mdi-eye-outline"></i> View
                                                </button>
                                            @endforeach
                                        </div>
                                    @else
                                        -
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
           
        </div>
    </div>
    <div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalTitle">Aadhar Photo</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center p-2">
                    <img id="modalImage" src="" class="img-fluid" alt="Aadhar photo"
                        style="max-height: calc(100vh - 170px); object-fit: contain;">
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
<script>
$(document).on('click', '.aadhar-image', function(e) {
    e.preventDefault();

    $('#modalImage').attr('src', $(this).data('image'));
    $('#imageModal').modal('show');
});

$('#imageModal').on('hidden.bs.modal', function() {
    $('#modalImage').attr('src', '');
});
</script>
@endsection
