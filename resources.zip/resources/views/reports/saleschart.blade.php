@extends('layout.app')

@section('title')
    Sales Charts Report
@endsection
@section('content')

<script src="https://cdn.plot.ly/plotly-2.26.1.min.js"></script>

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Sales Analytics for [{{$monthName}}]</h4>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-6">
            <form action="{{route('saleschart')}}" method="GET" id="saleschartform" class="mb-3">
                <div class="form-row mb-1">
                    <select name="selectedperiod" class="form-control col-10 col-md-6" id="saleschart">
                        <option value="">None</option>
                        <option value="1" @selected($selectedPeriod == 1)>January</option>
                        <option value="2" @selected($selectedPeriod == 2)>February</option>
                        <option value="3" @selected($selectedPeriod == 3)>March</option>
                        <option value="4" @selected($selectedPeriod == 4)>April</option>
                        <option value="5" @selected($selectedPeriod == 5)>May</option>
                        <option value="6" @selected($selectedPeriod == 6)>Jun</option>
                        <option value="7" @selected($selectedPeriod == 7)>July</option>
                        <option value="8" @selected($selectedPeriod == 8)>August</option>
                        <option value="9" @selected($selectedPeriod == 9)>September</option>
                        <option value="10" @selected($selectedPeriod == 10)>October</option>
                        <option value="11" @selected($selectedPeriod == 11)>November</option>
                        <option value="12" @selected($selectedPeriod == 12)>December</option>
                    </select>
                <input type="submit" value="Filter" class="ml-1 btn btn-primary waves-effect waves-light">
                </div>
            </form>
        </div>
    </div>
</div>

<div class="row analytic" style="background: #38414a;">
    <div class="col-4 col-sm-12 col-md-4"><h3 style="color: #fff;">1. Highest Sales Month: {{$highestMonthlySales->month_name}} </h3></div>
    <div class="col-4 col-sm-12 col-md-4"><h3 style="color: #fff;">2. Highest Sales Till Now: {{$highestMonthlySales->total_sales}} </h3></div>
    <div class="col-4 col-sm-12 col-md-4"><h3 style="color: #fff;">3. Highest Profit Till Now: {{$highestMonthlySales->total_profit}} </h3></div>
</div>

<div class="row">
    <div class="col-6 col-sm-12 col-md-6">        
        <div id="dailySales" class="chart"></div>
    </div>
    <div class="col-6 col-sm-12 col-md-6">
        <div id="paymentMode" class="chart"></div>
    </div>
</div>
<div class="row">
    <div class="col-12 col-sm-12 col-md-12">
        <div id="monthlySales" class="chart"></div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12 col-sm-12 col-md-12">
        <div id="profitAnalysis" class="chart"></div>

        <script>
            const salesData = JSON.parse(@json($salesData));  // structured per date
            const rawSales = JSON.parse(@json($allSales));    // original invoice records for pie chart

            const dailyDates = salesData.map(entry => entry.date);
            const dailyRevenue = salesData.map(entry => entry.net_amount);
            const dailyProfit = salesData.map(entry => entry.profit);

            // Daily Sales Chart
            Plotly.newPlot('dailySales', [{
                x: dailyDates,
                y: dailyRevenue,
                type: 'bar',
                marker: { color: 'blue' },
            }], {
                title: 'Daily Sales Overview',
                xaxis: { title: 'Date' },
                yaxis: { title: 'Revenue (₹)' },
            });

            // Monthly Sales Data
            const monthlySales = JSON.parse(@json($monthlySales));

            const monthlyLabels = monthlySales.map(entry => entry.month);
            const monthlyRevenue = monthlySales.map(entry => entry.total_sales);
            const monthlyProfit = monthlySales.map(entry => entry.total_profit);
console.log(monthlyRevenue);
            // Monthly Sales Chart
            Plotly.newPlot('monthlySales', [
                {
                    x: monthlyLabels,
                    y: monthlyRevenue,
                    type: 'bar',
                    name: 'Sales',
                    marker: { color: 'green' },
                    hovertemplate: '₹%{y:,.0f}<extra></extra>'
                },
                {
                    x: monthlyLabels,
                    y: monthlyProfit,
                    type: 'bar',
                    name: 'Profit',
                    marker: { color: 'orange' }
                }
            ], {
                title: 'Monthly Sales Overview (Last 12 Months)',
                barmode: 'group',
                xaxis: { title: 'Month' },
                yaxis: {
                    title: 'Amount (₹)',
                    tickprefix: '₹',       // show Rupee symbol
                    separatethousands: false, // Indian-style separators
                }
            });

            // Profit Chart
            Plotly.newPlot('profitAnalysis', [{
                x: dailyDates,
                y: dailyProfit,
                type: 'line',
                line: { shape: 'spline', color: 'green' },
            }], {
                title: 'Daily Profit Analysis',
                xaxis: { title: 'Invoice Date' },
                yaxis: { title: 'Profit (₹)' },
            });

            // Group by helper
            const groupBy = (array, key) =>
                array.reduce((result, item) => {
                    (result[item[key]] = result[item[key]] || []).push(item);
                    return result;
                }, {});

            // Payment Mode Pie Chart
            const paymentData = groupBy(rawSales, "payment_type");
            const paymentModes = Object.keys(paymentData);
            const paymentCounts = paymentModes.map(mode => paymentData[mode].length);

            Plotly.newPlot('paymentMode', [{
                labels: paymentModes,
                values: paymentCounts,
                type: 'pie',
            }], {
                title: 'Payment Mode Breakdown',
            });
        </script>
    </div>
</div>
@endsection
