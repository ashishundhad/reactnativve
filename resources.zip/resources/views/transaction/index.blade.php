@extends('layout.app')

@section('title')
    Transactions
@endsection

@section('content')
<style>
.filter-section, .download-section {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 1rem;
}
</style>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Recent Transactions</h4>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-12 col-sm-12 col-md-3">
        <div class="card card-pricing card-pricing-recommended">
            <div class="card-body text-center" style="padding: 0.5rem;">
                <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Cash in Hand</p>
                <h3 class="text-white">₹ 10000.00</h3>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12 col-md-3">
        <div class="card card-pricing" style="background: #08b14a; color:#fff">
            <div class="card-body text-center" style="padding: 0.5rem;">
                <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Bank Balance</p>
                <h3 class="text-white">₹ 50000.00</h3>
            </div>
        </div>
    </div>
</div>
<div class="filter-section">
    <form action="{{ route('sale-report') }}" method="GET" id="salesreport" class="row g-2 align-items-center">
        <div class="col-12 col-md-4">
            <select name="period" class="form-control" id="selectsalesperiod">
                <option value="alls" @selected($period == 'alls')>All Sales</option>
                <option value="thismonth" @selected($period == 'thismonth')>This Month</option>
                <option value="lastmonth" @selected($period == 'lastmonth')>Last Month</option>
                <option value="thisyear" @selected($period == 'thisyear')>This Year</option>
                <option value="lastyear" @selected($period == 'lastyear')>Last Year</option>
                <option value="custom" @selected($period == 'custom')>Custom</option>
            </select>
        </div>
        <div class="col-md-2">
            <input type="date" id="salefromdate" name="fromdate" class="form-control  mr-1 " value="{{$fromdate}}" style="display:none;">
        </div>
        <div class="col-md-2">
            <input type="date" id="saletodate" name="todate" class="form-control " value="{{$todate}}" style="display:none;">
        </div>
        <div class="col-12 col-md-4 d-flex gap-2">
            <input type="submit" value="Filter" class="btn btn-outline-primary w-100 mr-2">
            <a href="{{ route('sale-report') }}" class="btn btn-outline-danger w-100">
                Clear
            </a>
        </div>
    </form>
</div>

<div class="row">
    <div class="col-12">
        <div class="card-box">
            <div class="table-responsive">
                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="analytics-list">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Transaction Date</th>
                            <th>Transaction Type</th>
                            <th>Invoice No</th>
                            <th>Payment Method</th>
                            <th>Amount</th>
                            <th>Party</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($transactions as $index => $data)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ date("d/m/Y h:i A", strtotime($data->payment_date)) }}</td>
                                <td>Sales Invoice</td>
                                <td><a href="{{ route('print-invoice', $data->invoice['id']) }}">#{{ $data->invoice['invoice_no'] }}</a></td>
                                <td>{{ $data->payment_method }}</td>
                                <td style="color: green">₹{{ $data->amount }}</td>
                                <td>{{ $data->invoice['customer_name'] }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection