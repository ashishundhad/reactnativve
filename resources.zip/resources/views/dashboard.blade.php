﻿@extends('layout.app')

@section('title', __('Dashboard'))

@section('content')
@php
    $currency = config('constant.currency');
    $salesStartNumber = ($todaysSales->currentPage() - 1) * $todaysSales->perPage();
    $isCustomFilter = $filtertime === 'custom';

    $summaryCards = [
        [
            'label' => __('Stocks in Hand'),
            'value' => $stocksInHand,
            'icon' => 'fe-plus-circle',
            'iconClass' => 'avatar-lg rounded-circle bg-soft-primary border-primary border',
            'textClass' => 'text-primary',
            'url' => route('allpurchases'),
        ],
        [
            'label' => __(':month Sales', ['month' => $currentMonth]),
            'value' => $currentMonthSales,
            'icon' => 'fe-calendar',
            'iconClass' => 'avatar-md bg-primary rounded',
            'textClass' => 'text-white',
            'url' => null,
        ],
        [
            'label' => __('Items Sold In :month', ['month' => $currentMonth]),
            'value' => $numberOfProductsSoldInMonth,
            'icon' => 'fe-bar-chart-line',
            'iconClass' => 'avatar-lg rounded-circle bg-soft-info border-info border',
            'textClass' => 'text-info',
            'url' => null,
        ],
        [
            'label' => __("Today's Sales"),
            'value' => $totalSales,
            'icon' => 'fe-dollar-sign',
            'iconClass' => 'avatar-lg rounded-circle bg-soft-warning border-warning border',
            'textClass' => 'text-warning',
            'url' => null,
        ],
    ];

    $periodOptions = [
        '' => __('-- Choose Period --'),
        'today' => __('Today'),
        'yesterday' => __('Yesterday'),
        'lastweek' => __('Last 7 Days'),
        'month' => __('This Month'),
        'lastmonth' => __('Last Month'),
        'custom' => __('Custom Period'),
    ];

    $paymentTypes = [
        'Cash' => __('Cash'),
        'Online' => __('Online/UPI'),
        'Credit Card' => __('Credit Card'),
    ];
@endphp

<style>
    .dashboard-clock { color: #000; }
    .dashboard-greeting { color: #1abc9c; }
    .modal-xl { max-width: 1400px; }

    #imei_suggestions {
        position: absolute;
        z-index: 9;
        width: 100%;
        max-height: 220px;
        overflow-y: auto;
    }

    #imei_suggestions a {
        background-color: aliceblue;
        color: #000;
    }

    .showdefault { display: block !important; }
    .dnone { display: none; }

    .form-control.error,
    label.error {
        border-color: #ff0000;
        color: #ff0000;
    }

    .invoice-items-header {
        font-weight: 700;
        text-align: center;
    }

    .amountcalc ul {
        float: right;
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .amountcalc li {
        display: flex;
        justify-content: space-between;
        width: 220px;
        padding: 3px 0;
    }

    .amountcalc .due-amount,
    .amountcalc .paid-amount {
        border-top: 1px solid #e0e0e0;
        margin-top: 5px;
        padding-top: 6px;
    }

    .due-amount span {
        color: #f1556c;
        font-weight: 700;
    }
</style>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <p class="dashboard-clock mb-0">
                        <i class="mdi mdi-clock font-18"></i>
                        <strong>{{ __('Date:') }}</strong> {{ now()->format('d-m-Y') }}
                        &nbsp;
                        <strong>{{ __('Time:') }}</strong> <span id="currentTime">--:--:--</span>
                    </p>
                </div>

                <h4 class="page-title">
                    <span id="greeting" class="dashboard-greeting"></span>
                    {{ auth()->user()->name }}
                </h4>
            </div>
        </div>
    </div>

    <div class="row">
        @foreach ($summaryCards as $card)
            <div class="col-md-6 col-xl-3">
                @if ($card['url'])
                    <a href="{{ $card['url'] }}" class="text-reset">
                @endif

                <div class="widget-rounded-circle card-box">
                    <div class="row align-items-center">
                        <div class="col-5">
                            <div class="{{ $card['iconClass'] }}">
                                <i class="{{ $card['icon'] }} font-22 avatar-title {{ $card['textClass'] }}"></i>
                            </div>
                        </div>
                        <div class="col-7">
                            <div class="text-right">
                                <h3 class="text-dark mt-1">
                                    <span data-plugin="counterup">{{ $card['value'] }}</span>
                                </h3>
                                <p class="text-muted mb-1 text-truncate">{{ $card['label'] }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                @if ($card['url'])
                    </a>
                @endif
            </div>
        @endforeach
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="card-box">
                <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
                    <h4 class="header-title mb-2 mb-sm-0">
                        <i class="mdi mdi-autorenew"></i>
                        {{ __('Recent Sales') }} [{{ $totalRecords }}]
                    </h4>

                    <div>
                        <a href="{{ route('purchase.create') }}" class="btn btn-primary">
                            <i class="mdi mdi-plus-circle"></i> {{ __('Add Stock') }}
                        </a>
                        <button type="button" class="btn btn-success ml-1 create-invoice-btn">
                            <i class="mdi mdi-plus-circle"></i> {{ __('New Invoice') }}
                        </button>
                    </div>
                </div>

                <form action="{{ route('dashboard') }}" method="GET" class="mb-3" id="dashboardfilter">
                    <div class="row">
                        <div class="col-md-2">
                            <div class="form-group">
                                <label class="sr-only" for="findbystatus">{{ __('Period') }}</label>
                                <select name="filtertime" id="findbystatus" class="form-control w-100 mr-1 mb-2">
                                    @foreach ($periodOptions as $value => $label)
                                        <option value="{{ $value }}" @selected($filtertime == $value)>{{ $label }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="col-md-2 dnone">
                            <div class="form-group">
                                <label class="sr-only" for="fromdate">{{ __('From Date') }}</label>
                                <input type="date" id="fromdate" name="fromdate" class="form-control mr-2 @if ($isCustomFilter) showdefault @endif" value="{{ $fromdate }}" style="display: none;">
                            </div>
                        </div>

                        <div class="col-md-2 dnone">
                            <div class="form-group">
                                <label class="sr-only" for="todate">{{ __('To Date') }}</label>
                                <input type="date" id="todate" name="todate" class="form-control @if ($isCustomFilter) showdefault @endif" value="{{ $todate }}" style="display: none;">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block"><i class="fe-filter font-14 text-white pr-1"></i>{{ __('Apply Filter') }}</button>
                            </div>
                        </div>
                    </div>
                </form>

                <div class="table-responsive mt-10">
                    @if ($todaysSales->count())
                        <table class="table table-borderless table-hover table-nowrap table-centered m-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>{{ __('Sr. No.') }}</th>
                                    <th>{{ __('Item Detail') }}</th>
                                    <th>{{ __('Customer') }}</th>
                                    <th>{{ __('Payment Mode') }}</th>
                                    <th>{{ __('Sale Date') }}</th>
                                    <th>{{ __('Amount') }}</th>
                                    <th class="hidden-sm">{{ __('Action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($todaysSales as $key => $sale)
                                    <tr>
                                        <td><strong>#{{ $salesStartNumber + $key + 1 }}</strong></td>
                                        <td>{!! nl2br(e($sale->item_description)) !!}</td>
                                        <td>
                                            <ul class="list-unstyled mb-0">
                                                <li><strong>{{ __('Name:') }}</strong> {{ $sale->customer_name }}</li>
                                                @if ($sale->customer_no)
                                                    <li>
                                                        <strong>{{ __('Contact:') }}</strong>
                                                        <a href="tel:{{ $sale->customer_no }}">{{ $sale->customer_no }}</a>
                                                    </li>
                                                @endif
                                            </ul>
                                        </td>
                                        <td>
                                            <span class="badge badge-primary text-uppercase">{{ $sale->payment_type }}</span>
                                        </td>
                                        <td>{{ \Carbon\Carbon::parse($sale->invoice_date)->format('d/m/Y') }}</td>
                                        <td>{{ $currency }}{{ number_format($sale->net_amount, 2) }}</td>
                                        <td>
                                            <button type="button" class="view-sale-detail btn btn-primary btn-sm mr-1" data-id="{{ $sale->id }}" data-invoice="{{ $sale->invoice_no }}" title="{{ __('View') }}">
                                                <i class="fas fa-eye"></i>
                                            </button>

                                            <form method="post" action="{{ route('delete-sale', $sale->id) }}" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-xs btn-danger" onclick="sureToDelete(event)" title="{{ __('Delete') }}">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                        <div class="pagination-links">
                            {{ $todaysSales->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                        </div>
                    @else
                        <h4 class="mb-0">{{ __('No Recent sale found.') }}</h4>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="invoiceModal" tabindex="-1" role="dialog" aria-labelledby="invoiceModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="invoiceModalLabel">{{ __('Create Invoice') }} #{{ $lastId }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="{{ __('Close') }}">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body" id="create-invoice-content">
                <h4 class="header-title text-uppercase">{{ __('Invoice Basic Info:') }}</h4>
                <hr>

                <form action="{{ route('create-invoice') }}" method="post" id="createinvoiceform" class="@if ($errors->count()) was-validated @endif">
                    @csrf

                    <input type="hidden" name="invoice_no" value="{{ $lastId }}">
                    <input type="hidden" name="item_id" value="" id="itemID">
                    <input type="hidden" name="item_model" id="item_model" value="">

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label for="model_imei">{{ __('IMEI') }}*</label>
                                <input type="text" name="imei" required class="form-control border-bottom" id="model_imei" tabindex="1" placeholder="{{ __('Search IMEI...') }}" autocomplete="off">
                                <div id="imei_suggestions" class="list-group"></div>
                                <ul class="parsley-errors-list filled" id="parsley-id-imei" aria-hidden="false" style="display: none;">
                                    <li class="parsley-required">{{ __('IMEI Not Found in Stock!') }}</li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label for="customer_name">{{ __('Customer Name') }}*</label>
                                <input type="text" name="customer_name" required class="form-control border-bottom @error('customer_name') parsley-error @enderror" id="customer_name" tabindex="2" placeholder="{{ __('Customer Name') }}" value="{{ old('customer_name') }}">
                                @error('customer_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group mb-3">
                                <label for="invoicedate">{{ __('Invoice Date') }}</label>
                                <input type="text" name="invoice_date" class="form-control border-bottom" id="invoicedate" tabindex="3" value="{{ old('invoice_date', date('d/m/Y')) }}">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group mb-3">
                                <label for="warrantydate">{{ __('Warranty Expiry Date') }}</label>
                                <input type="text" name="warranty_expiry_date" class="form-control border-bottom" id="warrantydate" tabindex="4" value="{{ old('warranty_expiry_date', \Carbon\Carbon::now()->addDays(29)->format('d/m/Y')) }}">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group mb-3">
                                <label for="customer_no">{{ __('Contact No:') }}</label>
                                <input type="text" name="customer_no" class="form-control border-bottom" id="customer_no" maxlength="10" tabindex="5" placeholder="{{ __('Customer mobile') }}" autocomplete="off">
                            </div>
                        </div>

                        <div class="col-md-8">
                            <div class="form-group mb-3">
                                <label for="customer_address">{{ __('Address:') }}</label>
                                <input type="text" name="customer_address" class="form-control border-bottom" id="customer_address" tabindex="6" placeholder="{{ __('Customer Address') }}">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h4 class="header-title text-uppercase">{{ __('Item Details') }}</h4>
                            <hr>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 border p-1 invoice-items-header">{{ __('DESCRIPTIONS') }}</div>
                        <div class="col-md-2 border p-1 invoice-items-header">{{ __('QUANTITY') }}</div>
                        <div class="col-md-4 border p-1 invoice-items-header">{{ __('TOTAL AMOUNT') }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6 border p-2">
                            <textarea rows="5" class="form-control @error('item_description') parsley-error @enderror" name="item_description" id="item_description" tabindex="7"></textarea>
                        </div>
                        <div class="col-md-2 border p-2">
                            <input type="text" class="form-control text-right" required name="quantity" id="quantity" tabindex="8" readonly>
                        </div>
                        <div class="col-md-4 border p-2">
                            <input type="text" name="total_amount" id="totalAmountInput" class="form-control text-right @error('total_amount') parsley-error @enderror" tabindex="9" placeholder="{{ __('Enter Amount') }}" autocomplete="off" oninput="calculateNetAmount()">
                            @error('total_amount')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="row mt-0">
                        <div class="col-12">
                            <h4 class="header-title text-uppercase">{{ __('Payment Details') }}</h4>
                            <hr>
                        </div>

                        <div class="col-md-8">
                            <div id="payment-rows">
                                <div class="row payment-row mb-2">
                                    <div class="col-md-5">
                                        <select name="transaction_type[]" class="form-control border-bottom" required>
                                            <option value="">{{ __('- Payment Type -') }}</option>
                                            @foreach ($paymentTypes as $value => $label)
                                                <option value="{{ $value }}">{{ $label }}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-4">
                                        <input type="text" name="amount[]" class="form-control text-right payment-amount" placeholder="{{ __('Amount') }}" required oninput="calculateNetAmount()">
                                    </div>

                                    <div class="col-md-1">
                                        <button type="button" class="btn btn-success add-payment" aria-label="{{ __('Add payment row') }}">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4 amountcalc">
                            <ul>
                                <li>
                                    <strong>{{ __('Sub Total:') }}</strong>
                                    <span>{{ $currency }}<span id="totalAmountDisplay">0.00</span></span>
                                </li>
                                <li>
                                    <strong>{{ __('Total:') }}</strong>
                                    <span>{{ $currency }}<span id="netAmountDisplay">0.00</span></span>
                                    <input type="hidden" value="0" name="net_amount" id="netAmount">
                                </li>
                                <li class="paid-amount">
                                    <span>{{ __('Paid Amount:') }}</span>
                                    <span>{{ $currency }}<span id="totalPaidAmountDisplay">0.00</span></span>
                                    <input type="hidden" value="0" name="total_paid" id="totalPaidAmount">
                                </li>
                                <li class="due-amount">
                                    <span>{{ __('Due Amount:') }}</span>
                                    <span>{{ $currency }}<span id="totalDueAmountDisplay">0.00</span></span>
                                    <input type="hidden" value="0" name="total_due" id="totalDueAmount">
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="modal-footer px-0 pb-0">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ __('Close') }}</button>
                        <button type="submit" class="btn btn-primary">{{ __('Save') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="productDetailModal" tabindex="-1" role="dialog" aria-labelledby="productDetailLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="productDetailLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="{{ __('Close') }}">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="product-detail-content">{{ __('Loading...') }}</div>
        </div>
    </div>
</div>

<div
    id="dashboard-js-config"
    data-sale-detail-url-template="{{ route('solditemdetail', ['id' => '__SALE_ID__']) }}"
    data-imei-search-url="{{ route('search.imei') }}"
    data-hello="{{ __('Hello,') }}"
    data-good-morning="{{ __('Good Morning!') }}"
    data-good-afternoon="{{ __('Good Afternoon!') }}"
    data-good-evening="{{ __('Good Evening!') }}"
    data-good-night="{{ __('Good Night!') }}"
    data-remove-payment-row="{{ __('Remove payment row') }}"
    data-model="{{ __('Model:') }}"
    data-color="{{ __('Color:') }}"
    data-storage="{{ __('Storage:') }}"
    data-imei="{{ __('IMEI:') }}"
    data-imei-required="{{ __('IMEI compulsory') }}"
    data-customer-name-required="{{ __('Customer Name required!') }}"
    data-loading="{{ __('Loading...') }}"
    data-sales-detail="{{ __('SALES DETAIL:') }}"
    data-failed-to-load-data="{{ __('Failed to load data.') }}"
    data-payment-pending="{{ __('Payment Pending') }}"
    data-payment-pending-confirm="{{ __('Due amount is still pending. Do you want to continue?') }}"
    data-save-pending-invoice="{{ __('Yes, save invoice') }}"
    data-cancel="{{ __('Cancel') }}"
    data-payment-complete="{{ __('Payment Complete') }}"
    data-invoice-will-be-saved="{{ __('Invoice will be saved successfully.') }}"
    hidden
></div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script src="{{ asset('assets/js/dashboard.js') }}"></script>
@endsection
