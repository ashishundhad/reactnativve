@extends('layout.app')

@section('title', 'Repairing List')

@section('css')
<style>
    .error { color: #f00 }
</style>
@endsection

@section('content')
<div class="container-fluid">

    <!-- start page title -->
    <div class="row align-items-center">
        <!-- Title & Buttons for Mobile -->
        <div class="col-12 d-flex justify-content-between align-items-center mb-2 d-md-none">
            <h4 class="page-title mb-0">Repairing Management</h4>
            <div class="d-flex align-items-center mt-2">
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#repairingModal">
                    Add Entry
                </button>
            </div>
        </div>

        <!-- Title for Desktop -->
        <div class="col-md-6 mt-2 mb-2 d-none d-md-block">
            <h4 class="page-title">Repairing Management</h4>
        </div>

        <!-- Buttons for Desktop -->
        <div class="col-md-6 d-none d-md-flex justify-content-end">
            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#repairingModal">
               + Add Repairing
            </button>
        </div>
    </div>

    <div class="col-12 col-sm-12 col-md-3">
        <div class="card card-pricing" style="background: #08b14a; color:#fff">
            <div class="card-body text-center" style="padding: 0.5rem;">
                <p class="card-pricing-plan-name font-weight-bold text-uppercase" style="padding-bottom:0;">Available Repairing - {{$month}}</p>
                <h3 class="text-white">{{config('constant.currency')}} {{$totalRepairingAmount}}</h3>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-12">
    @if (session('status'))
        <div class="alert alert-success" id="statusMessage">
            {{ session('status') }}
        </div>
    @endif
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <form action="{{ route('repairing.list') }}" method="GET" id="filterrepairing">
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="example-password">Select Year</label>
                            <select name="year" class="form-control right" id="selectyear">
                                <option value="2026" @selected($year == 2026)>2026</option>
                                <option value="2027" @selected($year == 2027)>2027</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="example-password">Select Month</label>
                            <select name="month" class="form-control right" id="selectmonth">
                                <option value="All" @selected($month == 'All')>- All -</option>
                                <option value="January" @selected($month == 'January')>January</option>
                                <option value="February" @selected($month == 'February')>February</option>
                                <option value="March" @selected($month == 'March')>March</option>
                                <option value="April" @selected($month == 'April')>April</option>
                                <option value="May" @selected($month == 'May')>May</option>
                                <option value="June" @selected($month == 'June')>June</option>
                                <option value="July" @selected($month == 'July')>July</option>
                                <option value="August" @selected($month == 'August')>August</option>
                                <option value="September" @selected($month == 'September')>September</option>
                                <option value="October" @selected($month == 'October')>October</option>
                                <option value="November" @selected($month == 'November')>November</option>
                                <option value="December" @selected($month == 'December')>December</option>
                            </select>
                        </div>
                    </div>
                </form>
                @if (count($repairing))
                    <div class="table-responsive">
                        <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                            <thead>
                                <tr>
                                    <th># </th>
                                    <th>Customer Name</th>
                                    <th>Contact number</th>
                                    <th>Device</th>
                                    <th>Repairing Charge</th>
                                    <th>Note</th>
                                    <th>Date</th>
                                    <th class="hidden-sm">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach($repairing as $key=>$repair)
                                    <tr>
                                        <td><b>{{ $key+1 }}</b></td>
                                        <td> {{ $repair->customer_name ? $repair->customer_name : '-'  }}</td>
                                        <td>{{ $repair->phone ? $repair->phone : '-' }}</td>
                                        <td>{{ $repair->device_name ? $repair->device_name : '-' }}</td>
                                        <td class="text-right">{{ '₹' .number_format($repair->amount, 2) }}</td>
                                        <td>{{ $repair->note }}</td>
                                        <td>{{ \Carbon\Carbon::parse($repair->repairing_date)->format('d/m/Y') }}</td>
                                        <td>
                                            <div class="btn btn-primary btn-sm edit-repairing mr-1 mb-1" data-id="{{ $repair->id }}">
                                                <i class="fas fa-edit"></i>
                                            </div>
                                           
                                            <form method="post" action="{{ route('delete-repairing', $repair->id) }}" style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm delete-repairing mr-1 mb-1" onclick="sureToDelete(event)" title="Delete"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <h4>No Stock found..</h4>
                    <a href="{{ route('allpurchases') }}" class="btn btn-sm btn-success waves-effect waves-light">
                        <i class="mdi mdi-keyboard-backspace"></i> Back
                    </a>
                @endif
            </div>
        </div><!-- end col -->
    </div>
</div>

<div class="modal fade" id="repairingModal" tabindex="-1" role="dialog" aria-labelledby="repairingLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="repairingLabel">Add New Repairing</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body pt-0" id="newrepairing-form-content">
                <form class="form-horizontal row g-3" method="post" id="addNewRepairForm" action="{{ route('repairing.store')}}">
                    <input type="hidden" name="id" id="repairingID">
                    @csrf
                    <div class="col-md-6 mb-3">
                        <label for="customer_name" class="form-label">Customer Name <span class="text-danger">*</span></label>
                        <input type="text" id="customer_name" class="form-control @error('customer_name') is-invalid @enderror" name="customer_name" value="{{ old('customer_name') }}" required tabindex="1" placeholder="Enter Name">
                        @error('customer_name')
                            <ul class="parsley-errors-list filled">
                                <li class="parsley-required">{{ $message}}</li>
                            </ul>
                        @enderror
                    </div> 
                    <div class="col-md-6 mb-3">
                        <label for="mobileno" class="form-label">Mobile Number</label>
                        <input type="number" id="mobileno" class="form-control" name="phone" value="{{ old('phone') }}" tabindex="2" placeholder="Enter mobile number">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="device_name" class="form-label">device name</label>
                        <input type="text" id="device_name" class="form-control" name="device_name" value="{{ old('device_name') }}" tabindex="3" placeholder="Enter Device Name">
                    </div>
                   
                    <div class="col-md-6 mb-3">
                        <label for="amount" class="form-label">Repairing Amount <span class="text-danger">*</span></label>
                        <input type="number" id="amount" class="form-control" name="amount" tabindex="5" placeholder="Enter Amount" value="{{ old('amount') }}">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="date" class="form-label">Repairing Date</label>
                        <input type="date" class="form-control @error('repairing_date') is-invalid @enderror" name="repairing_date" tabindex="5" placeholder="Enter Date" id="repairing_date" value="{{ old('repairing_date') }}" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="note" class="form-label">Note</label>
                        <textarea id="note" class="form-control" name="note" placeholder="Enter Note">{{ old('note') }}</textarea>
                    </div>

                    <div class="text-left col-12">
                        <button type="submit" class="btn btn-primary waves-effect waves-light col-md-2 mb-2" tabindex="13"><i class="fe-check-circle mr-1"></i>Save</button>
                        <button type="reset" class="btn btn-danger waves-effect waves-light col-md-2 mb-2" tabindex="14"><i class="fe-x mr-1"></i>Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
@if(Session::has('message'))
     var type = "{{ Session::get('alert-type','info') }}"
     switch(type){
        case 'info':
        toastr.info(" {{ Session::get('message') }} ");
        break;

        case 'success':
        toastr.success(" {{ Session::get('message') }} ");
        break;

        case 'warning':
        toastr.warning(" {{ Session::get('message') }} ");
        break;

        case 'error':
        toastr.error(" {{ Session::get('message') }} ");
        break; 
     }
@endif 
</script>
<script>
jQuery(document).ready(function() {
    // Initialize Bootstrap modal
    $('#repairingModal').modal({
        show: false,
        backdrop: 'static',
        keyboard: false
    });
    $("#addNewRepairForm").validate({
        rules: {
            customer_name: "required",
            amount: 'required'
        },
        messages: {
            customer_name: "Please Enter Name",
            amount: 'Please Enter Amount'
        }
    });

    $(document).on('click', '.edit-repairing', function () {
        const repairingID = $(this).data('id');
        $('#addNewRepairForm')[0].reset();
        $('#addNewRepairForm').validate().resetForm();

        $('#repairingID').val(repairingID);

        $.ajax({
            url: "/admin/admin/repairing/edit-repairing/" + repairingID,
            type: 'GET',
            success: function(response) {
                // console.log(response)
                // Pre-fill form fields
                $('#addNewRepairForm #customer_name').val(response.customer_name);
                $('#addNewRepairForm #mobileno').val(response.phone);
                $('#addNewRepairForm #device_name').val(response.device_name);
                $('#addNewRepairForm #amount').val(response.amount);
                $('#addNewRepairForm #note').html(response.note);
                $('#addNewRepairForm #repairing_date').val(response.repairing_date);
                // $('#addNewRepairForm #repairing_date').val(new Date().toISOString().split('T')[0]);

                // Show modal
                $('#repairingModal').modal('show');
            },
            error: function(xhr) {
                toastr.error('Error fetching transaction details');
            }
        });
    });
    
});
</script>
@endsection