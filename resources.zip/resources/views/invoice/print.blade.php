@extends('layout.app')

@section('title')
    Invoice #{{$invoice->invoice_no}}
@endsection
@section('content')
<style>
    ol {
        padding-left: 15px;
    }
    ol li {
        font-size: 11px;
        font-weight: 600;
        line-height: 17px;
    }
    .card-box { box-shadow: 0 0 25px rgba(40, 50, 30, .1); margin: auto; max-width: 1100px; padding-top: 100px;}
    table.bill-table tr table td { padding-left:5px; }
    table.bill-table tr.billed-to td { padding-left:5px; color: #000; }
    .item_details thead th { text-align: center; }
    .tax_details h5 { margin: 0px 0; }
    .blueheader { background-color: #eb4d53b5; border-bottom: 1px solid #eee; }
    .terms { color: #ed1547;  }
    .conditions { color: #eb4d53b5; }
    .fs15 { font-size: 15px; }
    .fs16 { font-size: 16px; }
    tr td ul {  padding-bottom: 20px;  padding-left: 15px;  }
    tr td ul li {  font-size: 10px; font-weight: 400; padding-bottom: 4px; }
    td { color: #000; font-size:15px; }
    .footer-text { color: #000; text-align: right; padding-right: 30px; -webkit-print-color-adjust: exact; color-adjust: exact; }
    h3.businessname { margin: 0 0 10px 0; }
    .gstnote li { font-size:12px; }
    ul.gstnote { padding-bottom:0px; margin-bottom:0; } 
    .gst-note { -webkit-print-color-adjust: exact !important; margin: 10px 0 20px; padding: 15px 20px;  background: #f9f9f9; border-left: 4px solid #ee2150; 
    border-radius: 4px;  font-size: 12px;  line-height: 18px;  color: #444; }
    /* ---------- PRINT FIXES ---------- */
    @media print {
        @page {
            margin: 0;
        }
        body {
            -webkit-print-color-adjust: exact !important;
            color-adjust: exact !important;
            margin: 0;
            background: #fff !important;
        }
        table.bill-table tr table td { padding-left:5px; }
        table.bill-table tr.billed-to td { padding-left:5px; color: #000; }
        .item_details thead th { text-align: center; }
        .tax_details h5 { margin: 0px 0; }
        /* .bill-table { border: 1px solid; } */
        .terms { color: #ed1547; -webkit-print-color-adjust: exact; color-adjust: exact; }
        .conditions { color: #0382cd; -webkit-print-color-adjust: exact; color-adjust: exact; }
        .blueheader { 
            background-color: #eb4d53b5; 
            border-bottom: 1px solid #eee; 
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
        }
        ul {
            padding-left: 15px;
            -webkit-print-color-adjust: exact;
            padding-bottom: 50px;
        }
        ul li { 
            font-size: 11px;
            font-weight: 600;
            line-height: 17px;
            font-weight: 800;
            padding-bottom: 4px;
        }
        .fs15 { font-size: 15px; }
        .fs16 { font-size: 16px; }
        .footer-text { color: #000; text-align: right; padding-right: 30px; -webkit-print-color-adjust: exact; color-adjust: exact; }
        table tr td { color: #000; font-size:15px; }
    }
</style>
<div class="container-fluid">

    <div= class="row">
        <div class="col-12">
            <div class="page-title-box">
        
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-12">
            <div class="card-box">
                <!-- Company Info -->
                 <h2 style="text-align: center;">RECEIPT</h2>
                <div class="clearfix">
                    <table style="width:100%; margin-top: 50px; border-color: #000; border: 1px solid;" class="bill-table">
                        <tr style="border: 1px solid #000">
                            <td style="width:50%">
                                <table>
                                    <tr>
                                        <td style="padding-left: 40px;"><img src="{{asset('assets/images/ifirst.png')}}" width="130"></td>
                                        <td style="padding-left: 50px;"><h3 class="businessname">{{$settings->business_name}}</h3><span>{!! nl2br(e($settings->billing_address)) !!}</span><br>@if($settings->gstin)<b>GSTIN: </b>{{ $settings->gstin }}<br/>@endif<span><b>Mo: </b>{{$settings->phone}}</span></td>
                                    </tr>
                                </table>
                            </td>
                            <td style="width:50%;border: 1px solid #000;" colspan="4">
                                <table style="width:100%; border-bottom: 1px solid #000;">
                                    <tr style=" border-bottom: 1px solid #000;" class="blueheader">
                                        <td colspan="2" align="center" style="padding: 5px 0; font-size: 16px;"><b style="color:#000">Invoice Detail</b></td>
                                    </tr>
                                    <!-- <tr><td colspan="2" style="line-height: 5px;">&nbsp;</td></tr> -->
                                    <tr>
                                        <td style="width:50%; padding: 10px 5px; border-right:1px solid #a19c9c; line-height: 35px;"><b style="color:#000">Invoice/Bill No.: </b>#{{ $invoice->invoice_no }}</td>
                                        <td><b style="color:#000">Date:</b> {{ date("d/m/Y", strtotime($invoice->invoice_date)) }}</td>
                                    </tr>
                                    <!-- <tr><td style="line-height: 5px;">&nbsp;</td></tr> -->
                                </table>
                                <table style="width:100%;">
                                    <tbody>
                                    <tr>
                                        <td style="width:50%;  border-right:1px solid #a19c9c; line-height: 40px; padding: 5px;"><b style="color:#000">Payment Type: </b> {{ $invoice->payment_type }}</td>
                                        <td>
                                            @if($invoice->warranty_expiry_date != null)
                                            <b style="color:#000">Warrenty Expiry: </b> {{ date("d/m/Y", strtotime($invoice->warranty_expiry_date)) }}
                                            @else
                                                &nbsp;
                                            @endif
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr class="billed-to">
                            <td colspan="5" class="mb-2 fs15" style="padding: 10px;">
                                <h5>BILL TO:</h5>
                                <span><b style="color:#000">Name: &nbsp; </b> {{$invoice->customer_name}}</span><br/>
                                @if($invoice->customer_no)<span><b style="color:#000; ">Mobile:</b>&nbsp;(+91){{$invoice->customer_no}}</span> @endif
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <table style="width:100%;" class="item_details">
                                    <thead class="">
                                        <tr>
                                            <th align="center" style="width:10%; color:#000; background-color: #eb4d53b5; border-right: 1px solid #fff; text-align:left; padding-left: 5px; text-align: center;">#</th>
                                            <th align="center" style="width:60%; color:#000; background-color: #eb4d53b5; border-right: 1px solid #fff; padding-top: 10px; padding-bottom: 10px;">PARTICULARS</th>
                                            <th align="center" style="width:10%; color:#000; background-color: #eb4d53b5; border-right: 1px solid #fff;">QTY.</th>
                                            <th align="center" style="width:10%; color:#000; background-color: #eb4d53b5; border-right: 1px solid #fff;">RATE</th>
                                            <th align="center" style="width:15%; color:#000; background-color: #eb4d53b5;">AMOUNT(₹)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr style="border-bottom: 1px solid #a19c9c;">
                                            <td style="width:10%; color:#000; border-right: 1px solid #a19c9c; text-align:center;">1</td>
                                            <td style="width:60%; color:#000; border-right: 1px solid #a19c9c; padding: 20px 10px; ">{!! nl2br(e($invoice->item_description)) !!}</td>
                                            <td style="width:10%; color:#000; border-right: 1px solid #a19c9c; text-align:center;">1</td>
                                            <td style="width:10%; color:#000; border-right: 1px solid #a19c9c;text-align:right; padding-right:20px;">₹{{ number_format($invoice->total_amount, 2) }}</td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px;">₹{{ number_format($invoice->total_amount, 2)}}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="5">
                                <table style="width:100%;" class="tax_details" border="0">
                                    <tbody>
                                        <tr style="border-bottom: 1px solid #a19c9c;">
                                            <td colspan="4" align="right" style="padding-top: 6px; padding-bottom: 6px;"><h4>Sub Total:</h4></td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px; padding-top: 6px; padding-bottom: 6px;"><b>₹{{ $invoice->total_amount }}</b></td>
                                        </tr>
                                        @if ($paymentText)
                                        <tr style="border-bottom: 1px solid #000;">
                                            <td colspan="4" align="right" style="padding-top: 6px; padding-bottom: 6px;"><h5>Payment Details: ({{ $paymentText }}):</h5></td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px; padding-top: 6px; padding-bottom: 6px;"><b>₹{{ number_format($invoice->total_amount, 2) }}</b></td>
                                        </tr>
                                        @endif
                                        @if($invoice->cgst_rate)
                                        <tr>
                                            <td colspan="4" align="right"><b>CGST @if($invoice->cgst_rate) @ {{$invoice->cgst_rate}}% @endif :</td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px; "><b>₹{{ $invoice->cgst_amount }}</b></td>
                                        </tr>
                                        @endif
                                        @if($invoice->sgst_rate)
                                        <tr>
                                            <td colspan="4" align="right"><b>CGST @if($invoice->sgst_rate) @ {{$invoice->sgst_rate}}% @endif :</td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px;"><b>₹{{ $invoice->sgst_amount }}</b></td>
                                        </tr>
                                        @endif
                                        @if($invoice->igst_rate)
                                        <tr>
                                            <td colspan="4" align="right"><b>CGST @if($invoice->igst_rate) @ {{$invoice->igst_rate}}% @endif :</td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px;"><b>₹{{ $invoice->igst_amount }}</b></td>
                                        </tr>
                                        @endif
                                        @if($invoice->discount)
                                        <tr>
                                            <td colspan="4" align="right"><b>Discount @if($invoice->discount_rate) @ {{$invoice->discount_rate}}% @endif :</td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px;"><b>- ₹{{ number_format($invoice->discount, 2) }}</b></td>
                                        </tr>
                                        @endif
                                        @if($invoice->net_amount)
                                        <tr>
                                            <td colspan="4" align="right" style="padding-top: 6px; padding-bottom: 6px;"><h4>Grand Total:</h4></td>
                                            <td style="width:15%; color:#000; text-align:right; padding-right:10px; border-top: 1px solid; padding-top: 6px; padding-bottom: 6px;"><h4 style="color:#000">₹{{ number_format($invoice->net_amount, 2) }}</h4></td>
                                        </tr>
                                        @endif
                                       
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr style="color: #000; background-color: #ffd8d8b5; border-bottom: 1px solid #a19c9c; border-top: 1px solid #a19c9c;" class="blueheader">
                            <td colspan="4" style="padding:10px 10px; font-size: 15px; ">
                                <b>Amount (in words): </b> {{ $amountInWords }}
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4" style="padding-left: 20px; padding-top: 20px;">
                                <h4><span class="terms">Terms & Conditions</span></h4>
                                <ul>
                                    <li>પાણીથી /ભાંગ તૂટથી/ ઇલેક્ટ્રીક શોર્ટ સર્કિટથી થયેલી નુકસાની ની વોરંટી મળશે નહીં.</li>
                                    <li>કંપની વોરંટી દરમિયાન ગ્રાહકે જાતે જ કંપનીના સર્વિસ સેન્ટરમાં જવાનું રહેશે અને કંપનીનો નિર્ણય જ માન્ય ગણાશે.</li>
                                    <li>અમારી શોપ વોરંટી Expiry Date સુધી ગણાશે.</li>
                                    <li>અમારી વોરંટી દરમિયાન ફોનમાં કોઈ ખામી આવે તો તેની સર્વિસ થશે પાછું લેવા કે રિફંડ આપવામાં આવશે નહીં.</li>
                                    <li>ફોન લીધા બાદ જો રીટર્ન આપવું હશે કે એક્સચેન્જ કરવું હશે તો અમે આપેલા ભાવ જ માન્ય ગણાશે - ભાવ બાબતે કોઈ રક-જક કરવી નહીં.</li>
                                    <li>કોઈ પણ ફોન ની બેટરી (mAh) & ફોન ના વપરાશ ઉપર આધાર રાખે છે જેથી વોરંટી દરમિયાન ચેક કર્યા બાદ જો કોઈ ખામી જણાય તો જ (સર્વિસ/ચેન્જ) કરી આપવામાં આવશે. </li>
                                    <li>ફોન લેવા કે વેચવા માટે અમે આપેલા ભાવ એક દિવસ જ માન્ય રહેશે. </li>
                                    <li>ઇન્ટરનેશનલ(ગ્લોબલ) નવા કે જુના ફોનમાં કંપનીના નિયમો બદલાતા રહેતા હોય છે જેથી જે તે સમયે કંપની વોરંટી દરમિયાન કંપનીનો નિયમ જ માન્ય રહેશે. </li>
                                    <li>ફોન લેતા સમયે ફોન પર રહેલા ડેન્ટ કે સ્ક્રેચ ચકાસીને લેવા પછીથી આ બાબતે અમારી કોઇ જવાબદારી રહેશે નહીં.</li>
                                    <li>ફોન લીધા બાદ 24 કલાકની અંદર કંપનીના સર્વિસ સેન્ટરમાં ચેક કરાવી લેવું (જેમકે રીપેર થયેલ છે કે નહીં પાર્ટ્સ ચેન્જ છે કે નહીં બહાર ઓપન કરાવેલ છે કે નહીં વગેરે) પછીથી આ બાબતે અમારી કોઇ જવાબદારી રહેશે નહીં.</li>
                                    <li>રિપ્લેસમેન્ટ વખતે જે મોડલ ખરીદેલ હશે સામે બીજું સેમ મોડેલ જ મળશે.</li>
                                    <li>Display માં લાઈન-ડોટ-કલર ચેન્જ કે બીજી અન્ય તકલીફ માં વોરંટી મળશે નહીં.</li>
                                    <li>Android ઇન્ટરનેશનલ ફોનમાં 5G નેટવર્ક બેન્ડ અલગ આવતા હોવાથી 5G ચાલવા કે ના ચાલવાની જવાબદારી મળતી નથી.</li>
                                </ul>
                                <div class="gst-note">
                                    <h4><span class=" terms">GST & HSN Notes</h4>
                                    <ul class="gstnote">
                                        <li>GST on Refurbished mobile phone (HSN Code 8517) and Refurbished Laptop / Desktop (HSN Code: 8471) has been charged under the margin scheme of GST.</li>
                                        <li>For HSN code: 8517 (Refurbished Mobile phones) and HSN Code: 8471 (Refurbished Laptop / Desktop), value of supply is determined in accordance with Section 15(5) of the <br/>Central Goods and Services Tax Act read with Rule 32(5) of “Determination of the value of supply”. The credit for GST input shall not be available to the buyer if buyer follows the same valuation rule.</li>
                                        <li>For HSN code 8517 (other than refurbished Mobile), GST is charged as per the prescribed rate on the full value of the product, for which input credit shall be available to the registered buyer.</li>
                                    </ul>
                                </div>
                                <p class="footer-text">
                                    For <b>{{$user->shopname}}</b><br>Authorised Signatory
                                </p>
                                <p class="thanks-text" style="text-align: center; font-weight: 700; font-size: 16px;color: #de1e22;">✨ Thanks for Visit! ✨</p>
                            </td>
                        </tr>
                    </table>
                    <!-- <div class="text-center">
                        <h1>Vision Mobile</h1>
                    </div>
                    <div class="text-center">
                        <span>Shop no.31, 1st floor, <br/>Rudra square, Opp.kalupur co.op.Bank, <br/>Judges Banglow cross Road,Bodakdev, Ahmedabad - 380054</span><br>
                        <span><b>Mo:</b>+91 89898 09797, +91 89899 05757</span>
                    </div> -->
                    <!-- <div class="row pb-1">
                        <div class="col-6 text-right">
                            <span class="text-right"><b>PAN NO:</b> TEST02984</span>
                        </div>
                        <div class="col-6">
                            <span>
                                <b>GSTIN NO:</b> TEST92895C0DE3</span>
                        </div>
                    </div> -->
                </div>
                <!-- end row -->
                <!-- <div class="row">
                    <div class="col-12 text-center border">
                        <b>
                            <h3 class="m-1">GST INVOICE </h3>
                        </b>
                    </div>
                </div> -->
                {{--
                    <div class="row text-center ">
                    <div class="col-md-6 border p-0">
                        <b>
                            <div class="border-bottom">
                                <h5>Billed To:</h5>
                            </div>
                        </b>
                        @if($invoice->customer_name)
                        <div class="row pl-2 pt-1">
                            <div class="col-12 d-flex justiy-content-start">
                                <span><b>{{$invoice->customer_name}} </b></span>
                            </div>
                        </div>
                        @endif
                        @if($invoice->customer_no)
                        <div class="row pl-2">
                            <div class="col-12 d-flex justiy-content-start">
                                <label>Mobile:</label>
                                <span class="ml-1"> {{$invoice->customer_no}} </span>
                            </div>
                        </div>
                        @endif
                        @if($invoice->customer_address)
                            <div class="row pl-2">
                                <div class="col-12 d-flex justiy-content-start">
                                    <label>Address:</label>
                                    <span class="ml-1"> {{ $invoice->customer_address}} </span>
                                </div>
                            </div>
                        @endif
                    </div>
                    <div class="col-md-6 border p-0">
                        <b>
                            <div class="border-bottom">
                                <h5>Invoice Details</h5>
                            </div>
                        </b>
                        <div class="row pl-2 pt-1">
                            <div class="col-12 d-flex justiy-content-start">
                                <label><b>Invoice Number:</b></label>
                                <span class="ml-1">{{ $invoice->invoice_no }}</span>
                            </div>
                        </div>
                        <div class="row pl-2">
                            <div class="col-12 d-flex justiy-content-start">
                                <label><b>Invoice Date:</b></label>
                                <span class="ml-1">{{ date("d-m-Y", strtotime($invoice->invoice_date)) }}</span>
                            </div>
                        </div>
                        <div class="row pl-2">
                            <div class="col-12 d-flex justiy-content-start">
                                <label><b>Payment Type:</b></label>
                                <span class="ml-1">{{ $invoice->payment_type }}</span>
                            </div>
                        </div>
                    </div>
                    </div>
                --}}
                <!-- end row -->
            {{--
                <div class="row">
                    <div class="col-12 p-0">
                        <div class="table-responsive table-bordered">
                            <table class="table mt-4 table-centered border">
                                <thead>
                                    <tr>
                                        <th class="py-0 text-center" style="width: 5%; background-color: rgb(130, 210, 241); color: black;">S.NO.</th>
                                        <th class="py-0 text-center" style="width: 62%; background-color: rgb(130, 210, 241); color: black;">ITEM DESCRIPTION</th>
                                        <th class="py-0 text-center" style="width: 8%; background-color: rgb(130, 210, 241); color: black;">QTY.</th>
                                        <th class="py-0 text-center" style="width: 10%; background-color: rgb(130, 210, 241); color: black;">RATE</th>
                                        <th style="width: 15%; background-color: rgb(130, 210, 241); color: black;" class="text-center py-1"> AMOUNT </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{{ $invoice->id }}</td>
                                        <td>{!! nl2br(e($invoice->item_description)) !!}</td>
                                        <td class="text-right">1 Pcs.</td>
                                        <td class="text-right"> {{$invoice->total_amount}}</td>
                                        <td class="text-right"> {{$invoice->total_amount}}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div> <!-- end table-responsive -->
                    </div> <!-- end col -->
                </div>
            --}}
            {{--    <div class="row border">
                    <div class="col-sm-6 col-lg-9 p-0">
                        <!-- <div class="clearfix pt-2 pb-2 mt-1 mb-1 ml-1 text-center" style="background-color: rgba(218, 218, 218, 0.37); border-radius: 5px;">
                            <h5><b>Bank Details</b></h5>
                            <p><b>bank_name  - ACCOUNT NO: account_no - IFSC: ifsc_code</b></p>
                        </div> -->
                        <div class="clearfix pt-2 pb-2 mt-1 mb-1 ml-1" style="background-color: rgba(218, 218, 218, 0.37); border-radius: 5px;">
                            <p><b>Amount in words:</b> {{ $amountInWords }} </p>
                        </div>
                    </div> <!-- end col -->
                    <div class="col-sm-6 col-lg-3 mt-1">
                        <ul class="list-unstyled">
                            <li><b>Total :</b> <span class="float-right"><i class="fas fa-rupee-sign"></i> {{ $invoice->total_amount }}</span></li>
                            @if($invoice->cgst_amount)
                                <li><b>CGST @if($invoice->cgst_rate) @ {{$invoice->cgst_rate}}% @endif :</b><span class="float-right"><i class="fas fa-rupee-sign"></i> {{$invoice->cgst_amount }}</span></li>
                            @endif
                            @if($invoice->sgst_amount)
                                <li><b>SGST @if($invoice->sgst_rate) @ {{$invoice->sgst_rate}}% @endif :</b><span class="float-right"><i class="fas fa-rupee-sign"></i> {{ $invoice->sgst_amount }}</span></li>
                            @endif
                            @if($invoice->igst_amount)
                                <li><b>IGST @if($invoice->igst_rate) @ {{$invoice->igst_rate}}% @endif :</b><span class="float-right"><i class="fas fa-rupee-sign"></i> {{ $invoice->igst_amount }}</span></li>
                            @endif
                            @if($invoice->total_tax)
                                <li><b>Total Tax :</b><span class="float-right"><i class="fas fa-rupee-sign"></i> {{ $invoice->total_tax }}</span></li>
                            @endif
                            @if($invoice->discount_rate)
                                <li><b>Discount ({{ $invoice->discount_rate }}%) - :</b><span class="float-right"> <i class="fas fa-rupee-sign"></i> {{ $invoice->discount }}</span></li>
                            @endif
                            <hr style="margin-top: 0.5rem; margin-bottom: 0.5rem;"/>
                            <li><b>Net Amount :</b><span class="float-right"><h3><i class="fas fa-rupee-sign"></i> {{ $invoice->net_amount }}</h3></span></li>
                        </ul>
                        <div class="clearfix"></div>
                    </div> <!-- end col -->
                </div>
            --}}

                <div class="mt-4 mb-1">
                    <div class="text-right d-print-none">
                        <a href="javascript:window.print()" title="#{{$invoice->invoice_no}}" class="btn btn-primary waves-effect waves-light">Print <i class="mdi mdi-printer mr-1"></i></a>
                        <a href="{{ route('allinvoices') }}" class="btn btn-danger waves-effect waves-light">All
                            Invoices <i class="fas fa-rupee-sign"></i></a>
                    </div>
                </div>
            </div> <!-- end card-box -->
        </div>
    </div>
    <script>
        window.onload = function() {
            window.print();
        }
    </script>

</div> 
@endsection
