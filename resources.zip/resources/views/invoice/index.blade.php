@extends('layout.app')

@section('title')
    Manage Invoices
@endsection
@section('content')
<style>
ul.billinfo li { display: flex; }
ul.billinfo li b { min-width: 110px; }
.amountinr { min-width: 80px; text-align: right; }
</style>
<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="page-title-box">
                <h2 class="page-title font-weight-bold text-uppercase">Manage Invoices</h2>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="table-responsive">
                        @if (count($allInvoices))
                        <table class="table table-centered mb-0" id="invoice-table">
                            <thead class="thead-light">
                                <tr>
                                    <th class="font-weight-bold">Sr No</th>
                                    <th class="font-weight-bold">Invoice No.</th>
                                    <th class="font-weight-bold">Customer Detail</th>
                                    <th class="font-weight-bold">Billing Info</th>
                                    <th class="font-weight-bold">Invoice Date</th>
                                    <th class="font-weight-bold">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                @foreach($allInvoices as $key=>$invoice)
                                    @php
                                        $imei = Str::after($invoice->item_description, 'IMEI: ');
                                    @endphp
                                    <tr>
                                        <td><b>{{ $key+1 }}</b></td>
                                        <td>
                                            <b>#{{ $invoice->invoice_no }}</b>
                                        </td>
                                        <td>
                                            <ul class="list-unstyled">
                                                <li><b>Name:</b> {{ ucfirst($invoice->customer_name) }} </li>
                                                <li><b>IMEI:</b> {{ $imei }} </li>
                                                @if($invoice->customer_no)<li><b>Contact:</b> <a href="tel:{{$invoice->customer_no}}">{{$invoice->customer_no}}</a> </li> @endif
                                            </ul>
                                        </td>
                                        <td>
                                            <ul class="list-unstyled billinfo">
                                                @if($invoice->total_amount)
                                                    <li><b>Total Amount:</b> <span class="amountinr">₹{{ $invoice->total_amount }}</span></li>
                                                @endif
                                                @if($invoice->tax_amount)
                                                    <li><b>TAX:</b> <span class="amountinr">₹{{ $invoice->tax_amount }}</span></li>
                                                @endif
                                                @if($invoice->discount)
                                                    <li><b>Discount:</b> <span class="amountinr">₹{{ $invoice->discount }}</span></li>
                                                @endif
                                                @foreach($invoice->transactions as $transaction)
                                                    <li><b>{{ $transaction->payment_method }}:</b> <span class="amountinr">₹{{ $transaction->amount }}</span></li>
                                                @endforeach
                                                @if($invoice->net_amount)
                                                    <li><b>Net Amount:</b> <span class="amountinr">₹{{ $invoice->net_amount }}</span></li>
                                                @endif
                                            </ul>
                                        </td>
                                        <td>{{ date("d/m/Y", strtotime($invoice->invoice_date)) }}</td>
                                        <td>
                                            <a href="{{route('invoice-edit', $invoice->id)}}" class="btn  btn-blue waves-effect waves-light" title="Update">
                                                <i class="mdi mdi-pencil"></i>
                                            </a>
                                            <!-- <a href="{{route('invoice-detail', $invoice->id)}}" class="btn  btn-blue waves-effect waves-light" title="View">
                                                <i class="mdi mdi-eye"></i>
                                            </a> -->
                                            <a href="{{route('invoice-copy', $invoice->invoice_no)}}" class="btn  btn-blue waves-effect waves-light" title="Copy">
                                                <i class="mdi mdi-content-duplicate"></i>
                                            </a>
                                            <a href="{{ route('print-invoice', $invoice->id) }}"  class="btn btn-success waves-effect waves-light" title="print"><i class="mdi mdi-printer"></i>
                                            </a>
                                           {{--  @php
                                                $pdfUrl = asset('invoices/Invoice_IF20260029.pdf');
                                                $whatsappUrl = "https://wa.me/917600384076?text=" . urlencode("Here is your invoice: $pdfUrl");
                                            @endphp
                                            <a href="{{ $whatsappUrl }}" target="_blank" class="btn btn-success waves-effect waves-light" title="Whatsapp"><i class="mdi mdi-printer"></i>
                                            </a>
                                            --}}
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        @else
                            <h4>No Invoices Found</h4>
                        @endif
                    </div>

                </div>
            </div>
        </div>
    </div>
    
</div>
@endSection