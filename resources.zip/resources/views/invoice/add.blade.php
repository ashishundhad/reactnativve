@extends('layout.app')

@section('title')
    Create Invoice
@endsection
@section('content')
<style>
#imei_suggestions { position: absolute; z-index: 9;  width: 100%;  height: auto;  overflow-y: scroll;  }
#imei_suggestions a { background-color: aliceblue; color: #000;  }
.due-amount { border-top: 1px solid #e0e0e0; padding-top: 5px;  margin-top: 5px; }
.due-amount span { color: #f1556c; }
.amountcalc li { width:200px; }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title font-weight-bold"> CREATE INVOICE : #{{ $lastId }}</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    @include('include.alert')

                    <h4 class="header-title text-uppercase">Invoice Basic Info: </h4>
                    <hr>
                    <form action="{{ route('create-invoice') }}" method="post" class="@if(count($errors)) was-validated @endif" id="invoiceform" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="invoice_no" value="{{ $lastId}}"/>
                        <div class="row">
                            <input type="hidden" name="item_id" value="" id="itemID"/>
                            <input type="hidden" name="item_model" id="item_model" value=""/>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="salemodel">IMEI*:</label>
                                    <input type="text" placeholder="Search IMEI.." name="imei" required class="form-control border-bottom" id="model_imei" tabindex="1" autocomplete="off">
                                    <div id="imei_suggestions" class="list-group"></div>
                                    <ul class="parsley-errors-list filled" id="parsley-id-imei" aria-hidden="false" style="display:none;">
                                        <li class="parsley-required">IMEI Not Found in Stock!</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="customer_name">Customer Name*</label>
                                    <input type="text" required placeholder="Customer Name" name="customer_name" class="form-control border-bottom @error('customer_name') parsley-error @enderror" id="customer_name" tabindex="2" value="{{ old('customer_name') }}">
                                    @error('customer_name')
                                        <div class="invalid-feedback">{{ $message}} </div>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group mb-3">
                                    <label for="invoicedate">Invoice Date</label>
                                    <input type="text" name="invoice_date" class="form-control border-bottom" id="invoicedate" tabindex="3" value="{{ old('invoice_date', date('d/m/Y')) }}">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group mb-3">
                                    <label for="warrantydate">Warrenty Expiry Date</label>
                                    <input type="text" name="warranty_expiry_date" class="form-control border-bottom" id="warrantydate" tabindex="4" value="{{ old('warranty_expiry_date', \Carbon\Carbon::now()->addDays(29)->format('d/m/Y')) }}">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group mb-3">
                                    <label for="customer_no">Contact No:* <span class="pl-2">
                                        <!--<input type="checkbox" name="customer_no_sync" id="customer_no_sync"><label class="pl-1 mb-0" for="customer_no_sync">Would you like to sync with your phone?</label></span> --> </label>
                                    <input type="text" name="customer_no" class="form-control border-bottom" id="customer_no" maxlength="10" tabindex="5" placeholder="Customer mobile" autocomplete="off">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group mb-3">
                                    <label for="customer_address">Address:</label>
                                    <input type="text" name="customer_address" class="form-control border-bottom " id="customer_address" tabindex="6" placeholder="Customer Address">
                                </div>
                            </div>
                            {{--<div class="col-md-3">
                                <div class="form-group mb-3">
                                    <label for="payment_type">Payment Mode:*</label>
                                    <select name="payment_type" class="form-control border-bottom @error('payment_type') parsley-error @enderror" id="payment_type" tabindex="7" required>
                                        <option value="">- Payment Type -</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Online">Online/UPI</option>
                                        <option value="Credit Card">Credit Card</option>
                                    </select>
                                </div>
                            </div> --}}
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                 <div class="form-group mb-3">
                                    <label class="form-label fw-semibold" for="aadhar_card_number">Aadhar Card Number*</label>
                                    <input type="text" name="aadhar_card_number"
                                        class="form-control @error('aadhar_card_number') parsley-error @enderror"
                                        id="aadhar_card_number" maxlength="12" pattern="[0-9]{12}"
                                        placeholder="Enter 12 digit Aadhar number"
                                        value="{{ old('aadhar_card_number') }}">
                                    @error('aadhar_card_number')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-4 ">
                                <div class="form-group mb-3">
                                    <label class="form-label fw-semibold" for="aadhar_photos">Aadhar Photos</label>
                                    <input type="file" name="aadhar_photos[]"
                                        class="form-control @error('aadhar_photos') parsley-error @enderror @error('aadhar_photos.*') parsley-error @enderror"
                                        id="aadhar_photos" accept="image/jpeg,image/png,image/jpg,image/webp" multiple>
                                    @error('aadhar_photos')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    @error('aadhar_photos.*')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <h4 class="header-title text-uppercase">Item Details</h4>
                                <hr>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 border p-1 text-center">
                                <b>DESCRIPTIONS</b>
                            </div>
                            <div class="col-md-2 border p-1 text-center">
                                <b>QUANTITY</b>
                            </div>
                            <div class="col-md-4 border p-1 text-center">
                                <b>TOTAL AMOUNT</b>
                            </div>
                        </div>

                        <div class="row mb-3">
                                <div class="col-md-6 border p-2">
                                    <textarea rows="5" cols="50" class="form-control @error('item_description') parsley-error @enderror" name="item_description" name="description" id="item_description" tabindex="6"></textarea>
                                </div>
                                <div class="col-md-2 border p-2">
                                    <input type="text" class="form-control text-right " required name="quantity" name="quantity" id="quantity" tabindex="7"/>
                                </div>
                                <div class="col-md-4 border p-2">
                                    <input class="form-control @error('total_amount') parsley-error @enderror text-right" type="text" name="total_amount" id="totalAmountInput" oninput="calculateNetAmount()" tabindex="8" autocomplete="off">
                                    @error('total_amount')
                                        <div class="invalid-feedback">{{ $message}} </div>
                                    @enderror
                                </div>
                            </div>

                        <div class="row mt-0">
                            <!-- <div class="col-md-2">
                                <label>CGST (%)</label>
                                <input type="text" class="form-control border-bottom" placeholder="CGST Rate" name="cgst_rate" id="cgst" oninput="calculateNetAmount()" tabindex="9">
                                <span class="float-right gststyle" id="cgstDisplay">0</span>
                                <input type="hidden" id="cgstAmount" name="cgst_amount" value="0">
                            </div>

                            <div class="col-md-2">
                                <label>SGST (%)</label>
                                <input type="text" class="form-control border-bottom" placeholder="SGST Rate" name="sgst_rate" id="sgst" oninput="calculateNetAmount()" tabindex="10">
                                <span class="float-right gststyle" id="sgstDisplay">0</span>
                                <input type="hidden" id="sgstAmount" name="sgst_amount" value="0">
                            </div>

                            <div class="col-md-2">
                                <label>IGST (%)</label>
                                <input type="text" class="form-control border-bottom" placeholder="IGST Rate" name="igst_rate" id="igst" oninput="calculateNetAmount()" tabindex="11">
                                <span class="float-right gststyle" id="igstDisplay">0</span>
                                <input type="hidden" id="igstAmount" name="igst_amount" value="0">
                            </div>
                            <div class="col-md-2">
                                <label>Discount Amount</label>
                                <input type="number" class="form-control border-bottom" placeholder="Discount" name="discount_amount" id="discAmount" oninput="calculateNetAmount()" min="0" tabindex="12">
                            </div> -->
                            <div class="col-12">
                                <h4 class="header-title text-uppercase">Payment Details</h4>
                                <hr>
                            </div>
                            <div class="col-md-8">
                                <div id="payment-rows">
                                    <div class="row payment-row mb-2">
                                        <div class="col-md-5">
                                            <select name="transaction_type[]" class="form-control border-bottom" required>
                                                <option value=""> - Payment Type - </option>
                                                <option value="Cash">Cash</option>
                                                <option value="Online">Online/UPI</option>
                                                <option value="Credit Card">Credit Card</option>
                                            </select>
                                        </div>

                                        <div class="col-md-4">
                                            <input type="text" name="amount[]" class="form-control text-end payment-amount" placeholder="Amount" required oninput="calculateNetAmount()">
                                        </div>

                                        <div class="col-md-1">
                                            <button type="button" class="btn btn-success add-payment">+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 amountcalc">
                                <ul style="list-style: none;float: right;">
                                    <li>
                                        <b>Sub Total:</b> <span class="outer" style="float: inline-end;">₹<span type="text" id="totalAmountDisplay">0.00</span></span>
                                    </li>
                                    <li>
                                        <b>Total:</b> <span class="outer" style="float: inline-end;">₹<span type="text" id="netAmountDisplay">0.00</span></span>
                                        <input type="hidden" value="0" name="net_amount" id="netAmount">
                                    </li>
                                    <!-- <li>
                                        <b>Tax:</b> ₹ <span type="text" id="taxDisplay">0</span>
                                        <input type="hidden" value="0" name="tax_amount" id="taxAmount">
                                    </li>
                                    <li>
                                        <b>Net Amount:</b> ₹ <span type="text" id="netAmountDisplay">0</span>
                                        <input type="hidden" value="0" name="net_amount" id="netAmount">
                                    </li> -->
                                    <li style="border-top: 1px solid #e0e0e0; padding-top: 5px;" >
                                        Paid Amount: <span class="outer" style="float: inline-end;">₹<span type="text" id="totalPaidAmountDisplay">0.00</span></span>
                                        <input type="hidden" value="0" name="total_paid" id="totalPaidAmount">
                                    </li>
                                    <li class="due-amount">
                                        Due Amount: <span class="outer" style="float: inline-end; font-weight: bold;">₹<span type="text" id="totalDueAmountDisplay">0.00</span></span>
                                        <input type="hidden" value="0" name="total_due" id="totalDueAmount">
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" name="declaration" class="form-control border-bottom" id="validationCustom05" placeholder="Declaration">
                                </div>
                                <button type="submit" class="btn btn-primary float-right mb-2 ml-2"><i class="mdi mdi-printer"></i> Save & Print</button>
                                <a class="btn btn-danger float-right mb-2 ml-2" href="{{ route('allinvoices') }}"><i class="mdi mdi-keyboard-backspace"></i> Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const imeiInput     = document.getElementById("model_imei");
    const suggestions   = document.getElementById("imei_suggestions");
    const itemDescInput = document.getElementById("item_description"); 

    imeiInput.addEventListener("keyup", function () {
        let query = this.value;

        if (query.length >= 1) {
            fetch(`{{ route('search.imei') }}?imei=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    suggestions.innerHTML = "";
                    data.forEach(item => {
                        let option = document.createElement("a");
                        option.classList.add("list-group-item", "list-group-item-action");
                        option.textContent = item['imei'] + ' - '+item['model'];
                        option.href = "#";
                        option.addEventListener("click", function (e) {
                            e.preventDefault();
                            imeiInput.value = item['imei'];
                            suggestions.innerHTML = "";

                            let descriptionTxt = "";
                            descriptionTxt += "Model: " + (item['model'] || "") + "\n";
                            if (item['color']) {
                                descriptionTxt += "Color: " + item['color'] + "\n";
                            }
                            if (item['storage']) {
                                descriptionTxt += "Storage: " + item['storage'] + "\n";
                            }
                            if (item['imei']) {
                                descriptionTxt += "IMEI: " + item['imei'] + "\n";
                            }
                            document.getElementById("itemID").value = item['id'] || "";
                            document.getElementById("item_description").value = descriptionTxt;
                            document.getElementById("item_model").value = item['model'];
                            imeiInput.focus();
                            imeiInput.setSelectionRange(imeiInput.value.length, imeiInput.value.length);
                            $("#quantity").val(1);
                        });
                        suggestions.appendChild(option);
                    });
                });
        } else {
            suggestions.innerHTML = "";
        }
    });
});
document.addEventListener("click", function (e) {
    if (e.target.classList.contains("add-payment")) {
        const row = e.target.closest(".payment-row");
        const clone = row.cloneNode(true);

        // Clear values in cloned row
        clone.querySelectorAll("input, select").forEach(el => el.value = "");

        // Change + button to remove (–)
        const btn = clone.querySelector(".add-payment");
        btn.classList.remove("btn-success");
        btn.classList.add("btn-danger");
        btn.textContent = "–";
        btn.classList.remove("add-payment");
        btn.classList.add("remove-payment");

        document.getElementById("payment-rows").appendChild(clone);
    }

    if (e.target.classList.contains("remove-payment")) {
        e.target.closest(".payment-row").remove();
    }
});

document.getElementById('invoiceform').addEventListener('submit', function (e) {
    e.preventDefault();
    const form = this;
    const netAmount = parseFloat(
        document.getElementById('netAmount').value
    ) || 0;
    totalDueAmount = parseFloat(document.getElementById('totalDueAmount').value) || 0;
    totalPaidAmount = parseFloat(document.getElementById('totalPaidAmount').value) || 0;

    if (totalDueAmount > 0) {
        Swal.fire({
            title: 'Payment Pending df',
            text: 'Due amount is still pending. Do you want to continue?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            showConfirmButton: false,
            // confirmButtonText: 'Ok',
            cancelButtonText: 'OK'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit(); // ✅ submit manually
            }
        });
    }
    if (totalPaidAmount != netAmount) {
        Swal.fire({
            icon: 'warning',
            title: 'Payment Pending',
            text: 'Due amount is still pending. Do you want to continue?',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            showConfirmButton: false,
            cancelButtonText: 'Ok'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit(); // ✅ submit manually
            }
        });
    } else {
        Swal.fire({
            icon: 'success',
            title: 'Payment Complete',
            text: 'Invoice will be saved successfully.',
            timer: 1200,
            showConfirmButton: false
        }).then(() => {
            form.submit();
        });
    }
});
</script>
@endsection

@section('scripts')
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script>
    $(document).ready(function () {
        $("#invoicedate, #warrantydate").datepicker({ dateFormat: 'dd/mm/yy' });
    });
</script>
@endsection
