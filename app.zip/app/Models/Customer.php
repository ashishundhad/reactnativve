<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Customer extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function getAadharPhotosArrayAttribute(): array
    {
        if (! $this->aadhar_photos) {
            return [];
        }

        $photos = json_decode($this->aadhar_photos, true);

        if (! is_array($photos)) {
            $photos = explode(',', $this->aadhar_photos);
        }

        return collect($photos)
            ->map(fn ($photo) => trim((string) $photo, " \t\n\r\0\x0B\"'[]"))
            ->filter()
            ->values()
            ->all();
    }

    public function aadharPhotoUrl(string $photo): string
    {
        $photo = trim($photo);

        if (Str::startsWith($photo, ['http://', 'https://'])) {
            return $photo;
        }

        $photo = ltrim(str_replace('\\', '/', $photo), '/');
        $photo = preg_replace('#^(public/|storage/)#', '', $photo);

        if (! Str::startsWith($photo, 'invoices/aadhar_photos/')) {
            $photo = 'invoices/aadhar_photos/' . basename($photo);
        }

        return asset('storage/' . $photo);
    }

    public static function cleanPhone($phone): ?string
    {
        $phone = preg_replace('/\D+/', '', (string) $phone);

        return $phone !== '' && $phone !== '0' ? $phone : null;
    }

    public static function normalizeName(string $name): string
    {
        return Str::title(trim($name));
    }
}
