<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;

class TransactionController extends Controller
{
    //
    public function index(Request $request)
    {
        $period = $request->input('period');
        $fromDate = $toDate = '';
        $transactions = Transaction::orderBy('id', 'desc')->get();
        return view('transaction.index', [
            'transactions'  => $transactions, 
            'period'        => $period, 
            'fromdate'      => $fromDate, 
            'todate'        => $toDate
        ]);
    }
}
