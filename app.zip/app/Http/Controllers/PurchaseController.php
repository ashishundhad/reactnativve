<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\{Purchase, Invoice};
use App\Http\Controllers\InvoiceController;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Str;

class PurchaseController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        $isSold = $request->input('is_sold');
        $year = $request->input('year');
        $month = $request->input('month');
        $storage = $request->input('storage');
        $color = $request->input('color');
        $sortDirection = in_array($request->input('direction'), ['asc', 'desc'], true)
            ? $request->input('direction')
            : 'desc';

        if ($request->query('download') === 'csv') {
            $fileName = 'stock';
            if ($color)
                $fileName .= ''.$color;
            if ($storage)
                $fileName .= '-'.$storage;
            if ($year)
                $fileName .= '-'.$year;
            if ($month)
                $fileName .= '-'.$month;
            if ($isSold) {
                if ($isSold == 2) 
                    $fileName .= '-Available';
                else
                    $fileName .= '-Sold';
            }

            $fileName = $fileName.'-.csv';
            // $fileName = $year.'-'.$storage.'-'.$color.'-stock.csv';
            $headers = array(
                "Content-type"        => "text/csv",
                "Content-Disposition" => "attachment; filename=$fileName",
                "Pragma"              => "no-cache",
                "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                "Expires"             => "0"
            );
            $purchasesQuery = $this->purchaseIndexQuery($request)
                ->select([
                    'id',
                    'purchase_date',
                    'imei',
                    'model',
                    'storage',
                    'color',
                    'sell_date',
                    'purchase_from',
                    'contactno',
                    'purchase_cost',
                    'repairing_charge',
                    'purchase_price',
                    'is_sold',
                    'remark',
                ])
                ->orderBy('id', 'asc');

            $callback = function() use ($purchasesQuery) {
                $file = fopen('php://output', 'w+');

                // Add the CSV header (modify this based on your model)
                fputcsv($file, ['Sr No', 'Purchase Date', 'IMEI', 'Model', 'Storage(GB)', 'Color', 'Sell Date', 'Purchase From', 'Mobile No', 'Purchase Cost', 'Repairing', 'Purchase Price', 'Sold', 'Remark'], ';'); // Specify the custom separator (;)

                // Add the data rows
                $sellDate = '';
                $totalCost = $repairingCost = $purchasePrice = 0;
                foreach ($purchasesQuery->cursor() as $row) {
                    fputcsv($file, [
                        $row->id, 
                        Carbon::parse($row->purchase_date)->format('d/m/Y'),
                        (string)$row->imei,
                        $row->model,
                        $row->storage,
                        $row->color,
                        ($row->sell_date)?Carbon::parse($row->sell_date)->format('d/m/Y'):'',
                        $row->purchase_from,
                        $row->contactno,
                        $row->purchase_cost,
                        ($row->repairing_charge)?$row->repairing_charge:0,
                        $row->purchase_price,
                        ($row->is_sold == 1)?'Yes':'No',
                        $row->remark
                    ], ';');
                    $totalCost += $row->purchase_cost;
                    $repairingCost += $row->repairing_charge;
                    $purchasePrice += $row->purchase_price;
                }
                fputcsv($file, ['', '', '', '', '', '', '', '', '', '', '', '', '', ''], ';');
                fputcsv($file, ['', '', '', '', '', '', '', '', '', $totalCost, $repairingCost, $purchasePrice, '', ''], ';');

                fclose($file);
            };
            return Response::stream($callback, 200, $headers);
        } else {
            $allPurchases = $this->purchaseIndexQuery($request)
                ->select([
                    'id',
                    'model',
                    'storage',
                    'color',
                    'purchase_price',
                    'purchase_date',
                    'sell_date',
                    'is_sold',
                ])
                ->orderBy('id', $sortDirection)
                ->paginate(20);

            $colors = $this->purchaseIndexQuery($request, false)
                ->select('color')
                ->distinct()
                ->whereNotNull('color')
                ->orderBy('color', 'asc') // Optional: order by color alphabetically
                ->get();

            $stockTotals = Purchase::query()
                ->where('deleted', 0)
                ->where('is_sold', 0)
                ->selectRaw('
                    COALESCE(SUM(purchase_cost), 0) as total_stock_amount,
                    COALESCE(SUM(repairing_charge), 0) as total_repairing_amount,
                    COALESCE(SUM(purchase_price), 0) as total_repairing_and_stock_amount
                ')
                ->first();

            return view('purchase.purchases', [
                'allPurchases' => $allPurchases,
                'issold' => $isSold,
                'year' => $year,
                'month' => $month,
                'storage' => $storage,
                'sortDirection' => $sortDirection,
                'totalItems' => $allPurchases->total(),
                'colors' => $colors,
                'selectedcolor' => $color,
                'totalStockAmount' => $stockTotals->total_stock_amount,
                'totalRepairingAmount' => $stockTotals->total_repairing_amount,
                'totalRepairingAndStockAmount' => $stockTotals->total_repairing_and_stock_amount
            ]);
        }
    }

    private function purchaseIndexQuery(Request $request, bool $includeColorFilter = true)
    {
        return Purchase::query()
            ->where('deleted', 0)
            ->when($request->filled('search'), function ($query) use ($request) {
                $search = $request->input('search');

                $query->where(function ($q) use ($search) {
                    $q->where('id', 'like', "%{$search}%")
                      ->orWhere('imei', 'like', "%{$search}%")
                      ->orWhere('model', 'like', "%{$search}%")
                      ->orWhere('purchase_from', 'like', "%{$search}%");
                });
            })
            ->when($request->input('is_sold') !== null && $request->input('is_sold') !== '', function ($query) use ($request) {
                $query->where('is_sold', $request->input('is_sold') == 2 ? 0 : 1);
            })
            ->when($request->filled('year') || $request->filled('month'), function ($query) use ($request) {
                $this->applyPurchaseDateFilter($query, $request->input('year'), $request->input('month'));
            })
            ->when($request->filled('storage'), function ($query) use ($request) {
                $query->where('storage', 'like', '%' . $request->input('storage') . '%');
            })
            ->when($includeColorFilter && $request->filled('color'), function ($query) use ($request) {
                $query->where('color', $request->input('color'));
            });
    }

    private function applyPurchaseDateFilter($query, $year, $month): void
    {
        if ($month && ((int) $month < 1 || (int) $month > 12)) {
            return;
        }

        if ($year && $month) {
            $startDate = Carbon::create((int) $year, (int) $month, 1)->startOfMonth();
            $endDate = (clone $startDate)->endOfMonth();

            $query->whereBetween('purchase_date', [$startDate->toDateString(), $endDate->toDateString()]);
            return;
        }

        if ($year) {
            $query->whereBetween('purchase_date', [
                Carbon::create((int) $year, 1, 1)->toDateString(),
                Carbon::create((int) $year, 12, 31)->toDateString(),
            ]);
            return;
        }

        if ($month) {
            $query->whereMonth('purchase_date', $month);
        }
    }

    //New purchase form
    public function newPurchase() {
        return view('purchase.newpurchase');
    }

    public function purchaseDetail($id) {
        $purchase = Purchase::findOrFail($id);
        return view('purchase.ajaxdetail', compact('purchase'));
    }

    public function savePurchase(Request $request)
    {
        if ($request->purchase_date) {
            try {
                $convertedDate = Carbon::createFromFormat('d/m/Y', $request->purchase_date)->format('Y-m-d');
                $request->merge(['purchase_date' => $convertedDate]);
            } catch (Exception $e) {
                return back()->withErrors(['error' => 'Invalid invoice date format. Please use dd/mm/yyyy format.'])->withInput();
            }
        }
        $request->validate([
            'model'=>'required',
            'imei'=>'required',
            'purchase_date'=>'required',
            'color'=>'required',
            'storage'=>'required',
            'purchase_from'=>'required',
            'purchase_cost'=>'required',
            'document.*' => 'file|mimes:pdf,jpg,jpeg,png,webp|max:5120',
            'product_photos.*' => 'image|mimes:jpg,jpeg,png,webp|max:5120',
        ], [
            // 'contactno.required' => 'Please Correct Phone Number',
        ]);
        
        $purchase = new Purchase();
        $purchase->device_type = $request->device_type;
        $purchase->model = $request->model;
        // $purchase->brand = $request->brand;
        $purchase->imei = $request->imei;
        $purchase->purchase_date = $request->purchase_date;
        $purchase->color = $request->color;
        $purchase->storage = $request->storage;
        $purchase->purchase_from = $request->purchase_from;
        $purchase->contactno = $request->contactno;
        $purchase->warrentydate = $request->warrentydate;
        $purchase->purchase_cost = $request->purchase_cost;
        $purchase->repairing_charge = $request->repairing_charge;
        
        $repairingCharge = $purchase_price = $purchase->purchase_price = 0;
        if ($purchase->repairing_charge > 0) {
            $repairingCharge = $purchase->repairing_charge;
        }
        if ($purchase->purchase_cost > 0) {
            $purchaseCost = $purchase->purchase_cost;
        }
        $purchase->purchase_price = floatval($purchaseCost + $repairingCharge);
        $purchase->remark = $request->remark;
        $purchase->user_id = Auth::user()->id;

        if ($request->file('document') != null && count($request->file('document')) > 0) {
            $basePath = 'documents/purchases/';
            $purchase->document = $this->uploadFiles($request->file('document'), $request->imei, $basePath);
        }
        if ($request->file('product_photos') != null && count($request->file('product_photos')) > 0) {
            $basePath = 'documents/productphotos/';
            $purchase->product_photos = $this->uploadFiles($request->file('product_photos'), '', $basePath);
        }

        $purchase->save();
        $notification = [
            'message' => 'Stock Added Successfully',
            'alert-type' => 'success'
        ];
        return redirect()->route('allpurchases')->with($notification);
    }

    public function deleteStock($id, Request $request) {
        // $purchase = Purchase::findOrFail($id);
        // // $purchase->delete();
        // $purchase->deleted = 1; 
        // $purchase->update($purchase->deleted);

        Purchase::where('id', $id)->update(['deleted' => 1]);
        return redirect()->route('allpurchases')->withStatus('Stock Deleted Successfully..');
    }

    public function editPurchase($id) {
        $purchase = Purchase::findOrFail($id);
        return view('purchase.editpurchase', ['purchase' => $purchase]);
    }

    public function edit($id) {
        $data = Purchase::findOrFail($id);
        $response = [
            'status' => true,
            'message' => 'Transaction retrieved successfully',
            'data' => $data,
        ];
        return response()->json($response, 200);
    }

    public function updatePurchase(Request $request) {
        $request->validate([
            'model'=>'required',
            'imei'=>'required',
            'purchase_date'=>'required',
            'storage'=>'required',
            'purchase_from'=>'required',
            'purchase_cost'=>'required',
            'document.*' => 'file|mimes:pdf,jpg,jpeg,png,webp|max:5120',
            'product_photos.*' => 'image|mimes:jpg,jpeg,png,webp|max:5120',
        ]);
        $purchase = Purchase::findOrFail($request->id);
        $purchase->model = $request->model;
        $purchase->device_type = $request->device_type;
        $purchase->imei = $request->imei;        
        $purchase->purchase_date = $request->purchase_date;
        $purchase->color = $request->color;
        $purchase->storage = $request->storage;
        $purchase->purchase_from = $request->purchase_from;
        $purchase->contactno = $request->contactno;
        $purchase->purchase_cost = $request->purchase_cost;
        $purchase->repairing_charge = $request->repairing_charge;
        $purchase->warrentydate = $request->warrentydate;
        
        $repairingCharge = $purchase_price = $purchase->purchase_price = 0;
        if ($purchase->repairing_charge > 0) {
            $repairingCharge = $purchase->repairing_charge;
        }
        if ($purchase->purchase_cost > 0) { 
            $purchaseCost = $purchase->purchase_cost;
        }
        $purchase->purchase_price = floatval($purchaseCost + $repairingCharge);
        $purchase->remark = $request->remark;
        $purchase->user_id = Auth::user()->id;

        if ($request->file('document') != null && count($request->file('document')) > 0) {
            $basePath = 'documents/purchases/';
            $purchase->document = $this->uploadFiles($request->file('document'), $request->imei, $basePath);
        }
        if ($request->file('product_photos') != null && count($request->file('product_photos')) > 0) {
            $basePath = 'documents/productphotos/';
            $purchase->product_photos = $this->uploadFiles($request->file('product_photos'), '', $basePath);
        }
        // If item is_sold = 1 then update invoice row
        if ($purchase->is_sold) {
            $invoice = Invoice::where('item_id', $purchase->id)->firstOrFail();
            $invoice->profit = $invoice->net_amount - $purchase->purchase_price;
            $invoice->update();
        }
        $purchase->update();
        $notification = [
            'message' => "Stock Updated Successfully - '".$purchase->model."'",
            'alert-type' => 'success'
        ];
        return redirect()->route('allpurchases')->with("Stock Updated Successfully.. :: '".$purchase->model."'");
    }

    // Function for uploading documents
    public function uploadFiles($documents, $imei, $basePath) {
        foreach ($documents as $file) { 
            $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $safeName = Str::slug($originalName) ?: 'file';
            $imeiPrefix = $imei ? Str::slug($imei) . '-' : '';
            $filename = now()->format('YmdHis') . '-' . Str::random(8) . '-' . $imeiPrefix . $safeName . '.' . $file->extension();
            $file->move(public_path($basePath), $filename);
            $docs[] = $filename;
        }
        return implode(',', $docs);
    }

    public function importStocks() {
        return view('purchase.import');
    }

    public function importStocksData(Request $request) {
        $request->validate([
            'stockdata' => 'required|mimes:csv,txt',
        ]);
        $file = $request->file('stockdata');

        if (($handle = fopen($file, 'r')) !== false) {
            fgetcsv($handle, 1000, ';');
            while (($data = fgetcsv($handle, 1000, ';')) !== false) {
                if ($data[8]) {
                    $is_sold = 1;
                } else {
                    $is_sold = 0;
                }
                Purchase::create([
                    'purchase_date' => \DateTime::createFromFormat('d.m.Y', $data[1])->format('Y-m-d'),
                    'imei' => $data[2],
                    'model' => $data[3],
                    'storage' => $data[4],
                    'color'=> $data[5],
                    'purchase_from'=> $data[6],
                    'contactno' => ($data[7])?$data[7]:null,
                    'purchase_cost' => trim(($data[9])?$data[9]:0),
                    'repairing_charge' => trim($data[10]?$data[10]:0),
                    'remark' => $data[11],
                    'purchase_price' => trim( $data[12]),
                    'user_id' => Auth::user()->id,
                    'device_type' => 'Phone',
                    'is_sold' => $is_sold,
                ]);
            }
            fclose($handle);
        }
        return redirect()->route('allpurchases')->withStatus('Stocks imported successfully.');
    }

    /* Get parties on add stock form */
    public function getParties(Request $request)
    {
        $search = $request->get('partname');

        $parties = Purchase::select('purchase_from', 'contactno')
            ->where('purchase_from', 'LIKE', '%' . $search . '%')
            ->where('deleted', 0)
            ->groupBy('purchase_from', 'contactno')
            ->limit(10)
            ->get();

        return response()->json($parties);
    }
}
