<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Purchase, Invoice, Dummyinvoice, Settings, Transaction, Customer};
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class InvoiceController extends Controller
{
    protected $googleContactService;

    public function __construct()
    {
        $this->googleContactService = app('GoogleContact');
    }

    //
    public function index()
    {
        $allInvoices = Invoice::with('customer')->where('deleted', 0)->orderBy('invoice_no', 'desc')->get();
        return view('invoice.index', ['allInvoices' => $allInvoices]);
    }

    public function newInvoice()
    {
        $stocksModel = Purchase::where('deleted', 0)->orderBy('purchase_date', 'desc')->get();

        $lastInvoice = Invoice::orderBy('id', 'desc')->first();
        $currentYear = date('Y');
        $nextInvoiceNo = 1; // Default to 1
        if ($lastInvoice) {
            // Extract the year from the last invoice number
            preg_match('/IF(\d{4})/', $lastInvoice->invoice_no, $matches);
            $lastYear = $matches[1] ?? null;

            if ($lastYear == $currentYear) {
                // If the year matches, increment the invoice number
                $lastId = intval(substr($lastInvoice->invoice_no, -4)); // Get the last numeric part
                $nextInvoiceNo = $lastId + 1;
            }
        }

        $formattedNumber = "IF" . $currentYear . str_pad($nextInvoiceNo, 4, '0', STR_PAD_LEFT);

        return view('invoice.add', [
            'stocksModel' => $stocksModel,
            'lastId' => $formattedNumber
        ]);
    }

    public function createInvoice(Request $request)
    {
        if ($request->invoice_date) {
            try {
                $convertedDate = Carbon::createFromFormat('d/m/Y', $request->invoice_date)->format('Y-m-d');
                $request->merge(['invoice_date' => $convertedDate]);
            } catch (\Exception $e) {
                return back()->withErrors(['error' => 'Invalid invoice date format. Please use dd/mm/yyyy format.'])->withInput();
            }
        }

        if ($request->warranty_expiry_date) {
            try {
                $date = $request->warranty_expiry_date;

                if (strpos($date, '/') !== false) {
                    $convertedDate = Carbon::createFromFormat('d/m/Y', $date)->format('Y-m-d');
                } else {
                    $convertedDate = Carbon::parse($date)->format('Y-m-d');
                }

                $request->merge(['warranty_expiry_date' => $convertedDate]);
            } catch (\Exception $e) {
                return back()->withErrors(['error' => 'Invalid warranty expiry date format. Please use dd/mm/yyyy.']);
            }
        }
        $request->validate([
            'item_id' => [
            'required',
                Rule::unique('invoices')->where(function ($query) {
                    $query->where('deleted', 0);
                }),
            ],
            'customer_name' => 'required',
            'item_description' => 'required',
            'invoice_date' => 'required|date',
            'invoice_no' => 'required',
            'total_amount' => 'required|numeric|min:0',
            'net_amount' => 'required|numeric|min:0',
            'aadhar_card_number'  => 'nullable|digits:12',
            'aadhar_photos.*' => 'image|mimes:jpg,jpeg,png,webp',
            // 'aadhar_photos.*'     => 'image|mimes:jpg,jpeg,png,webp',
        ],  [
            // 'aadhar_photos.*.image' => 'Only image files are allowed.',
            // 'aadhar_photos.*.mimes' => 'Allowed formats: jpg, jpeg, png, webp.',
        ]);
        $aadharPhotos = [];
        if ($request->hasFile('aadhar_photos')) {
            $aadharNumber = $request->aadhar_card_number ?: 'no-aadhar';
            $customerName = Str::slug($request->customer_name, '_') ?: 'customer';
            $datePrefix   = Carbon::now()->format('dmy');
            $directory    = 'invoices/aadhar_photos';

            try {
                foreach ($request->file('aadhar_photos') as $index => $photo) {
                    $counter  = $index > 0 ? '-' . ($index + 1) : '';
                    $fileName = "{$datePrefix}-{$aadharNumber}-{$customerName}{$counter}.webp";

                    $aadharPhotos[] = $this->storeCompressedWebpImage($photo, $directory, $fileName);
                }
            } catch (\Throwable $e) {
                return back()
                    ->withErrors(['aadhar_photos' => 'Unable to compress Aadhar photo. Please upload a valid image.'])
                    ->withInput();
            }
        }

        $aadharPhotoText = ! empty($aadharPhotos) ? implode(',', $aadharPhotos) : null;
        $customer = $this->syncCustomerFromRequest($request, $aadharPhotoText);

        $invoice = new Invoice();
        $invoice->customer_id   = $customer->id;
        $invoice->item_id       = $request->item_id;
        $invoice->item_description = $request->item_description;
        $invoice->customer_name = $customer->name;
        $invoice->customer_no   = $customer->phone;
        $invoice->customer_address = $customer->address;
        $invoice->invoice_date  = $request->invoice_date;
        $invoice->warranty_expiry_date = $request->warranty_expiry_date;
        $invoice->invoice_no    = $request->invoice_no;
        $invoice->total_amount  = $request->total_amount;
        $invoice->net_amount    = $request->net_amount;
        $invoice->declaration   = $request->declaration;
        $invoice->discount      = $request->discount_amount;
        $invoice->discount_rate = $request->discount_rate;
        $invoice->quantity      = $request->quantity;
        $invoice->payment_type  = implode('/', $request->transaction_type);
        $invoice->is_paid = 1;
        $invoice->profit = floatval( $request->net_amount - Purchase::findOrFail($request->item_id)->purchase_price );
        $invoice->invoice_by = auth()->user()->id;
        $invoice->aadhar_photos = $aadharPhotoText;
        $invoice->aadhar_card_number = $customer->aadhar_card_number;

        Purchase::findOrFail($request->item_id)->update([
            'is_sold' => 1,
            'sell_date' => $request->invoice_date
        ]);
        $invoice->save();
        foreach ($request->transaction_type as $index => $type) {
            Transaction::create([
                'invoice_id' => $invoice->id,
                'payment_date' => now(),
                'payment_method' => $request->transaction_type[$index],
                'amount' => $request->amount[$index],
                'created_by' => auth()->id(),
            ]);
        }

        $customer_no_sync = $request->customer_no_sync;
        if($customer_no_sync == 'on') {
            $request->merge(['invoice_id' => $invoice->id]);
            $result = $this->googleContactService->syncContact($request);

            if ($result['success'] == false) {
                if (isset($result['redirect'])) {
                    return redirect()->to($result['redirect']);
                }
                return response()->json(['error' => $result['error']], 500);
            }
        }
        //return redirect()->route('allinvoices')->withStatus('Invoice Created Successfully..');
        return redirect()->route('print-invoice', $invoice->id);
    }

    public function invoiceDetail($id) {
        $invoice = Invoice::with('customer')->findOrFail($id);
        return view('invoice.detail', ['invoice' => $invoice]);
    }

    public function printInvoice($id) { 
        $invoice            = Invoice::with('customer')->findOrFail($id);
        $businessSettings   = Settings::find(1) ?: Settings::first() ?: (object) [
            'business_name' => config('app.name', 'iFirst Mobile'),
            'billing_address' => '',
            'gstin' => null,
            'phone' => '',
        ];
        $amountInWords      = $this->amoutInWords(floatval($invoice->net_amount));
        $user = Auth::user();
        $payments = Transaction::where('invoice_id', $id)->get();
        $paymentText = $payments->map(function ($p) {
            return $p->payment_method . ' ' . number_format($p->amount, 0);
        })->implode(' + ');
        $totalPaid = $payments->sum('amount');
        return view('invoice.print', [
            'invoice'       => $invoice, 
            'amountInWords' => $amountInWords, 
            'user'          => $user, 
            'settings'      => $businessSettings,
            'totalPaid'     => $totalPaid,
            'paymentText'   => $paymentText
        ]);
    }

    public function printDuplicateInvoice($id) {
        $invoice = Invoice::with('customer')->where('invoice_no', $id)->firstOrFail();
        $duplicateInvoice = Dummyinvoice::where('invoice_no', $id)->firstOrFail();
        $amountInWords = $this->amoutInWords(floatval($duplicateInvoice->new_amount));
        return view('invoice.duplicateprint', ['invoice' => $invoice, 'amountInWords' => $amountInWords, 'duplicateInvoice' => $duplicateInvoice]);
    }

    public function fetchModelData($imei) {
        // $purchase = Purchase::where('imei', $imei)->first();
        $purchase = Purchase::where('imei', 'LIKE', "{$imei}%")
            ->where('is_sold', 0)
            ->first();
        $count = $purchase ? 1 : 0;
        // return response()->json($purchase);
        return response()->json([
            'purchase' => $purchase,
            'count' => $count
        ]);
    }

    public function searchImei(Request $request)
    {
        $search = $request->get('imei');

        $results = Purchase::where('imei', 'LIKE', '%'. $search . '%')
                    ->where('is_sold', 0)
                    ->where('deleted', 0)
                    ->take(10)
                    ->get();

        return response()->json($results);
    }

    public function editInvoice($id) {
        $invoice = Invoice::with('customer')->findOrFail($id);
        $stocksModel = Purchase::where('deleted', 0)->orderBy('purchase_date', 'desc')->get();
        return view('invoice.edit', ['invoice' => $invoice, 'stocksModel' => $stocksModel]);
    }

    public function updateInvoice(Request $request, $id) {
        $invoice = Invoice::findOrFail($id);

        $request->validate([
            'item_id' => 'required',
            'customer_name' => 'required',
            'item_description' => 'required',
            'invoice_date' => 'required|date',
            'invoice_no' => 'required',
            'total_amount' => 'required|numeric|min:0',
            'net_amount' => 'required|numeric|min:0',
            'aadhar_card_number' => 'nullable|digits:12',
        ]);

        // check if contact name or contact number is chagnges?
        $isContactInformationChanges = false;
        if($invoice->customer_name != $request->customer_name || $invoice->customer_no != $request->customer_no) {
            $isContactInformationChanges = true;
        }

        $customer = $this->syncCustomerFromRequest($request);

        $updateData = [
            'customer_id' => $customer->id,
            'item_id' => $request->item_id,
            'item_description' => $request->item_description,
            'invoice_date' => $request->invoice_date,
            'warranty_expiry_date' => $request->warranty_expiry_date,
            'invoice_no' => $request->invoice_no,
            'customer_name' => $customer->name,
            'customer_no' => $customer->phone,
            'customer_address' => $customer->address,
            'payment_type' => $request->payment_type,
            'total_amount' => $request->total_amount,
            'cgst_rate' => $request->cgst_rate,
            'sgst_rate' => $request->sgst_rate,
            'igst_rate' => $request->igst_rate,
            'cgst_amount' => $request->cgst_amount,
            'sgst_amount' => $request->sgst_amount,
            'igst_amount' => $request->igst_amount,
            'discount' => $request->discount,
            'tax_amount' => $request->tax_amount,
            'net_amount' => $request->net_amount,
            'declaration' => $request->declaration,
            'quantity' => $request->quantity,
            'profit' => floatval($request->net_amount - Purchase::findOrFail($request->item_id)->purchase_price),
            'invoice_by' => auth()->user()->id,
        ];

        $invoice->update($updateData);

        $customer_no_sync = $request->customer_no_sync;
        if ($customer_no_sync == 'on' && $isContactInformationChanges) {
            $request->merge(['invoice_id' => $invoice->id]);
            $result = $this->googleContactService->syncContact($request);
            if ($result['success'] == false) {
                if (isset($result['redirect'])) {
                    // header('Location: ' . $result['redirect']);
                    // exit;
                    // Redirect the user to the Google authentication page (or other redirect URL)
                    return redirect()->to($result['redirect']);
                }
                // If no redirect URL is set, return an error message
                return response()->json(['error' => $result['error']], 500);
            }
        } else {
            // $invoice->sync_contact = 0;
            // $invoice->save();
        }

        return redirect()->route('allinvoices')->withStatus('Invoice Updated Successfully..');
    }

    private function syncCustomerFromRequest(Request $request, ?string $aadharPhotos = null): Customer
    {
        $name = Customer::normalizeName($request->customer_name);
        $phone = Customer::cleanPhone($request->customer_no);
        $address = trim((string) $request->customer_address) ?: null;
        $aadharNumber = trim((string) $request->aadhar_card_number) ?: null;

        $query = Customer::query();

        if ($phone !== null) {
            $query->where('phone', $phone);
        } else {
            $query->whereRaw('LOWER(name) = ?', [Str::lower($name)])
                ->where('address', $address)
                ->where('aadhar_card_number', $aadharNumber);
        }

        $customer = $query->first() ?: new Customer();

        $customer->name = $name;
        $customer->phone = $phone;
        $customer->address = $address;
        $customer->aadhar_card_number = $aadharNumber ?: $customer->aadhar_card_number;

        if ($aadharPhotos !== null) {
            $customer->aadhar_photos = $aadharPhotos;
        }

        $customer->save();

        return $customer;
    }

    private function storeCompressedWebpImage($photo, string $directory, string $fileName, int $quality = 75): string
    {
        if (! function_exists('imagewebp')) {
            throw new \RuntimeException('WebP image support is not enabled.');
        }

        $imageContents = file_get_contents($photo->getRealPath());
        $image = imagecreatefromstring($imageContents);

        if (! $image) {
            throw new \RuntimeException('The uploaded file could not be read as an image.');
        }

        if (! imageistruecolor($image)) {
            imagepalettetotruecolor($image);
        }

        imagealphablending($image, false);
        imagesavealpha($image, true);

        Storage::disk('public')->makeDirectory($directory);

        $path = "{$directory}/{$fileName}";
        $stored = imagewebp($image, Storage::disk('public')->path($path), $quality);

        imagedestroy($image);

        if (! $stored) {
            throw new \RuntimeException('The uploaded image could not be saved as WebP.');
        }

        return $path;
    }

    public function amoutInWords(float $amount)
    {
        $amount_after_decimal = round($amount - ($num = floor($amount)), 2) * 100;
        // Check if there is any number after decimal
        $amt_hundred = null;
        $count_length = strlen($num);
        $x = 0;
        $string = array();
        $change_words = array(0 => '', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine',10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',16 => 'Sixteen', 17 => 'Seventeen', 18 =>'Eighteen',19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty',70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
            $here_digits = array('', 'Hundred','Thousand','Lakh', 'Crore');

            while( $x < $count_length ) {
            $get_divider = ($x == 2) ? 10 : 100;
            $amount = floor($num % $get_divider);
            $num = floor($num / $get_divider);
            $x += $get_divider == 10 ? 1 : 2;
            if ($amount) {
            $add_plural = (($counter = count($string)) && $amount > 9) ? 's' : null;
            $amt_hundred = ($counter == 1 && $string[0]) ? ' and ' : null;
            $string [] = ($amount < 21) ? $change_words[$amount].' '.$here_digits[$counter]. $add_plural.' '.$amt_hundred:$change_words[floor($amount / 10) * 10].' '.$change_words[$amount %10]. ' '.$here_digits[$counter].$add_plural.' '.$amt_hundred;
                }
        else $string[] = null;
        }
        $implode_to_Rupees = implode('', array_reverse($string));
        $get_paise = ($amount_after_decimal > 0) ? "And " . ($change_words[$amount_after_decimal / 10] . " 
        " . $change_words[$amount_after_decimal % 10]) . ' Paise' : '';
        return ($implode_to_Rupees ? $implode_to_Rupees . 'Only ' : '') . $get_paise;
    }

    public function duplicateinvoice($id) {
        $invoice = Invoice::with('customer')->where('invoice_no', $id)->firstOrFail();
        return view('invoice.dummy', ['invoice' => $invoice]);
    }

    public function saveDummybill(Request $request, $id) {
        $request->validate([
            'invoice_id' => 'required|exists:invoices,id',
            'invoice_no' => 'required|exists:invoices,invoice_no'
        ]);

        Dummyinvoice::updateOrCreate(
            ['invoice_no' => $request->invoice_no],
            [
                'oldamount' => $request->oldamount,
                'new_amount' => $request->net_amount,
                'invoice_id' => $request->invoice_id,
                'invoice_no' => $request->invoice_no,
                'updated_by' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]
        );
        return redirect()->route('duplicateinvoice', ['id' => $request->invoice_no]);
    }
}
