<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Repairing;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class RepairingController extends Controller
{
    //
    public function index(Request $request)
    {
        $month  = $request->input('month');
        $year   = $request->input('year');
        $repairing = Repairing::where('deleted', 0)->orderBy('repairing_date', 'desc')->get();
        $totalRepairingAmount = Repairing::where('deleted', 0)->sum('amount');
        if (($month || $year) && $month!='All') {
            // Convert month name to number
            $monthNumber    = Carbon::parse("1 $month")->month;
            $startOfMonth   = Carbon::create($year, $monthNumber, 1)->startOfMonth();
            $endOfMonth     = Carbon::create($year, $monthNumber, 1)->endOfMonth();
            $totalReparingAmount = Repairing::whereBetween('repairing_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount');
            // $query->whereBetween('repairing_date', [$startOfMonth, $endOfMonth]);

            $repairing = Repairing::whereBetween('repairing_date', [$startOfMonth, $endOfMonth])
                ->where('deleted', 0)
                ->get();
        } else {
            $startOfMonth = Carbon::now()->startOfMonth()->toDateTimeString();
            $endOfMonth = Carbon::now()->endOfMonth()->toDateTimeString();
            if ($month == 'All') {
                $totalReparingAmount = Repairing::where('deleted', 0)->sum('amount');
            } else {
                $totalReparingAmount = Repairing::whereBetween('repairing_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount');
            }
            $repairing = Repairing::where('deleted', 0)->orderBy('repairing_date', 'desc')->get();
        }
        return view('repairing.index', [
            'repairing'     => $repairing, 
            'totalRepairingAmount' => $totalReparingAmount,
            'year'  => $year ?? date('Y'),
            'month' => $month ?? 'All',
        ]);
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'amount' => 'required',
                'customer_name' => 'required',
                'repairing_date' => 'required',
            ]);
            if (! empty($request->id)) {
                $repairing = Repairing::findOrFail($request->id);
                $repairing->customer_name = $request->customer_name;
                $repairing->amount = $request->amount;
                $repairing->repairing_date = $request->repairing_date;
                $repairing->note = $request->note;
                $repairing->device_name = $request->device_name;
                $repairing->phone = $request->phone;
                $repairing->added_by = Auth::id();
                $repairing->update();
                $message = 'Repairing Updated Successfully';
            } else {
                $repairing = new Repairing();
                $repairing->customer_name = $request->customer_name;
                $repairing->phone = $request->phone;
                $repairing->device_name = $request->device_name;
                $repairing->amount = $request->amount;
                $repairing->repairing_date = $request->repairing_date;
                $repairing->note = $request->note;
                $repairing->added_by = Auth::id();
                $repairing->save();
                $message = 'Repairing Added Successfully';
            }
            return redirect()->route('repairing.list')->withStatus($message);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }   
    }

    public function editRepairing($id)
    {
        $repairing = Repairing::findOrFail($id);
        return response()->json($repairing, 200);
    }

    public function deleteRepairing($id)
    {
        Repairing::where('id', $id)->update(['deleted' => 1]);
        return redirect()->route('repairing.list')->withStatus('Repairing Deleted Successfully..');
    }
}
