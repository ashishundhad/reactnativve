<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\{Invoice, Purchase, Expense, Repairing, Customer};
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    //
    public function sale(Request $request)
    {
        $allSales = Invoice::where('deleted', 0)->orderBy('invoice_date', 'desc')->get();
        $period = $request->input('period');
        $totalSalesAmount = $totalProfitAmount = $totalRepairing = 0;
        $fromDate = $toDate = '';
        if ($period == 'thismonth') {
            $startOfMonth = Carbon::now()->startOfMonth();
            $endOfMonth = Carbon::now();  //today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(20);
            $totalSalesAmount   = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount  = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount');

            $timePeriod = Carbon::now()->format('F');
        } elseif ($period == 'lastmonth') {
            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd = Carbon::now()->subMonth()->endOfMonth();  //today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(20);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = Invoice::whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('amount');

            $timePeriod = Carbon::now()->subMonth()->format('F');
        } elseif ($period == 'thisyear') {
            $startOfYear = Carbon::now()->startOfYear();
            $endOfYear = Carbon::now();  //today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$startOfYear, $endOfYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(20);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = Invoice::whereBetween('invoice_date', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('amount');

            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period == 'lastyear') {
            $startOfLastYear  = Carbon::now()->subYear()->startOfYear();
            $endOfLastYear  = Carbon::now()->subYear()->endOfYear();
            $allSales = Invoice::whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->paginate(20);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = Invoice::whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('amount');

            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period == 'custom') {
            $fromDate = $request->input('fromdate');
            $toDate = $request->input('todate');
           // $lastMonthEnd = Carbon::now();  //today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(20);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = Invoice::whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->sum('profit');

            $totalExpenseAmount = Expense::whereBetween('entrydate', [$fromDate, $toDate])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [$fromDate, $toDate])->where('deleted', 0)->sum('amount');

            $timePeriod = Carbon::now()->format('F');
        } elseif ($period == 'alls') {
            $allSales = Invoice::where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(20);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = Invoice::whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } else {
            $allSales = Invoice::where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(20);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = Invoice::whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $totalRepairing     = Repairing::whereBetween('repairing_date', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        }

        return view('reports.sales', [
            'allSales' => $allSales,
            'period' => $period,
            'totalSalesAmount' => number_format($totalSalesAmount, 2, '.', ''),
            'totalProfitAmount' => number_format($totalProfitAmount, 2, '.', ''),
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'totalItems' => $allSales->total(),
            'currentMonth' => Carbon::now()->format('F'),
            'timePeriod' => $timePeriod,
            'totalExpenseAmount' => number_format((float) $totalExpenseAmount, 2, '.', ''),
            'totalRepairing' => $totalRepairing
        ]);
    }

    /** 
     * Download sales records using route(sale-export) 
     * @param $request
     */
    public function downloadExcel(Request $request)
    {
        $period = $request->input('period');
        $monthName = Carbon::now()->format('F');

        if ($period == 'thismonth') {
            $monthName = Carbon::now()->format('F');
            $startOfMonth = Carbon::now()->startOfMonth();
            $endOfMonth = Carbon::now();  //today's date)
            $salesReport = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->get();
        } elseif ($period == 'lastmonth') {
            $monthName = Carbon::now()->subMonth()->format('F');
            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd = Carbon::now()->subMonth()->endOfMonth();  //today's date)
            $salesReport = Invoice::whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->get();
        } elseif ($period == 'thisyear') {
            $monthName = Carbon::now()->format('Y');
            $startOfYear = Carbon::now()->startOfYear();
            $endofYear = Carbon::now();
            $salesReport = Invoice::whereBetween('invoice_date', [$startOfYear, $endofYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->get();
        } elseif ($period == 'custom') {
            $fromDate = $request->input('fromdate');
            $toDate = $request->input('todate');
            $monthName = date('d-m-Y', time());
            $endofYear = Carbon::now();
            $salesReport = Invoice::whereBetween('invoice_date', [$fromDate, $toDate])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->get();
        } else { 
            $salesReport = Invoice::where('deleted', 0)->orderBy('id', 'asc')->get();
        }
        $fileName = $monthName.'-sales.csv';
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );
       $callback = function() use ($salesReport) {
            $file = fopen('php://output', 'w+');

            // Add the CSV header (modify this based on your model)
            fputcsv($file, 
                [
                    'ID', 
                    'Invoice No.', 
                    'Sell Date', 
                    'IMEI', 
                    'Model', 
                    'Storage (GB)', 
                    'Color', 
                    'Customer Name', 
                    'Mobile No', 
                    'Sell Price', 
                    'Profit', 
                    'Payment Mode'
                ], 
                ';'
            );

            // Add the data rows
            foreach ($salesReport as $key=>$row) {
                fputcsv($file, [
                    $key+1,
                    $row->invoice_no,
                    $row->invoice_date,
                    $row->purchase->imei,
                    $row->purchase->model,
                    $row->purchase->storage,
                    $row->purchase->color,
                    $row->customer_name,
                    $row->customer_no,
                    $row->net_amount,
                    $row->profit,
                    $row->payment_type
                ], ';');
            }
            fclose($file);
        };
        return Response::stream($callback, 200, $headers);
    }

    public function downloadPurchaseExcel(Request $request)
    {
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now();
        $period = $request->input('period');
        $fromDate = $toDate = '';
        // $fromDate = $request->input('fromdate');
        // $toDate = $request->input('todate');

        if ($period == 'thismonth') {
            // $startOfMonth = Carbon::now()->startOfMonth();
            // $endOfMonth = Carbon::now(); 
            $monthName = Carbon::now()->format('F');
            $purchaseReport = Purchase::whereBetween('purchase_date', [$startOfMonth, $endOfMonth])
                ->where('deleted', 0)
                ->where('is_sold', 0)
                ->orderBy('purchase_date', 'asc')->get();
        } elseif ($period == 'lastmonth') {
            $monthName = Carbon::now()->subMonth()->format('F');
            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd = Carbon::now()->subMonth()->endOfMonth();  //today's date
            $purchaseReport = Purchase::whereBetween('purchase_date', [$lastMonthStart, $lastMonthEnd])
                ->where('deleted', 0)
                ->where('is_sold', 0)
                ->orderBy('purchase_date', 'asc')->get();
        } elseif ($period == 'alls') {
            $monthName = 'all';
            $purchaseReport = Purchase::where('deleted', 0)
            ->where('is_sold', 0)
            ->orderBy('purchase_date', 'asc')
            ->get();
        } elseif ($period == 'thisyear') {
            $monthName = Carbon::now()->year;
            $startOfYear = Carbon::now()->startOfYear();
            $endofYear = Carbon::now();
            $purchaseReport = Purchase::whereBetween('purchase_date', [$startOfYear, $endofYear])
                ->where('deleted', 0)
                ->where('is_sold', 0)
                ->orderBy('purchase_date', 'asc')->get();
        } elseif ($period == 'custom') {
            $fromDate = $request->input('fromdate');
            $toDate = $request->input('todate');
            $monthName = Carbon::parse($fromDate)->format('d-m-Y').'_to_'.Carbon::parse($toDate)->format('d-m-Y');
            $purchaseReport = Purchase::whereBetween('purchase_date', [$fromDate, $toDate])
                ->where('deleted', 0)
                ->where('is_sold', 0)
                ->orderBy('purchase_date', 'asc')->get();
                // dd($purchaseReport);
        } else { 
            $purchaseReport = Purchase::where('deleted', 0)->where('is_sold', 0)->orderBy('id', 'asc')->get();
            $monthName = 'all';
        }
        // $purchaseReport = Purchase::query()->orderBy('id', 'asc')->get();

        $fileName = 'iFirst-'.$monthName.'-Purchase.csv';
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );
        $callback = function() use ($purchaseReport) {
            $file = fopen('php://output', 'w+');

            // Add the CSV header (modify this based on your model)
            fputcsv($file, ['Sr No', 'Purchase Date', 'IMEI', 'Model', 'Storage', 'Color', 'Sell Date', 'Buy From', 'Mobile No', 'Buy Cost', 'Repairing', 'Buy Price', 'Sold', 'Remark'], ';');

            $totalBuyCost = $totalBuyPrice = $totalRepairingCost = 0;
            // Add the data rows
            $sellDate = '';
            foreach ($purchaseReport as $key=>$row) {
                $totalBuyCost += (float) $row->purchase_cost;
                $totalRepairingCost += (float) $row->repairing_charge;
                $totalBuyPrice += (float) $row->purchase_price;
                fputcsv($file, [
                    $key+1, 
                    Carbon::parse($row->purchase_date)->format('d/m/Y'),
                    (string)$row->imei,
                    $row->model,
                    $row->storage,
                    $row->color,
                    ($row->sell_date)?Carbon::parse($row->sell_date)->format('d/m/Y'):'',
                    $row->purchase_from,
                    $row->contactno,
                    $row->purchase_cost,
                    $row->repairing_charge ?? 0,
                    $row->purchase_price,
                    ($row->is_sold == 1) ? 'Yes' : 'No',
                    $row->remark
                ], ';');
            }
            // Blank row before total (optional)
            fputcsv($file, array_fill(0, 9, ''), ';');
            // Add total buy cost row
            fputcsv($file, ['Total Buy Cost', '', '', '', '', '', '', '', '', $totalBuyCost, $totalRepairingCost, $totalBuyPrice], ';');

            fclose($file);
        };
        return Response::stream($callback, 200, $headers);
    }

    public function downloadPurchaseReport(Request $request)
    {
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now();
        $totalPurchaseAmount = 0;
        // $timePeriod = Carbon::now()->format('F');
        $timePeriod = $request->input('period');
        $allPurchased = Purchase::where('deleted', 0)->orderBy('created_at', 'desc')->paginate(20);

        if ($timePeriod == 'thismonth') {
            $totalPurchaseAmount = Purchase::whereBetween('created_at', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->where('is_sold', 0)->sum('purchase_cost');
        } elseif ($timePeriod == 'lastmonth') {
            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd = Carbon::now()->subMonth()->endOfMonth();  //today's date
            $totalPurchaseAmount = Purchase::whereBetween('created_at', [$lastMonthStart, $lastMonthEnd])
                ->where('deleted', 0)->where('is_sold', 0)->sum('purchase_cost');
        } elseif ($timePeriod == 'alls') {
            $totalPurchaseAmount = Purchase::where('deleted', 0)->where('is_sold', 0)->sum('purchase_cost');
        } else {
            $totalPurchaseAmount = Purchase::where('deleted', 0)->where('is_sold', 0)->sum('purchase_cost');
        }
       /* $totalProfitAmount = Purchase::whereBetween('created_at', [Carbon::now()->startOfMonth(), Carbon::now()])
            ->where('deleted', 0)->sum('profit');*/
        return view('reports.purchase', [
            'totalPurchaseAmount' => number_format($totalPurchaseAmount, 2, '.', ''),
            'timePeriod' => $timePeriod,
            'allPurchased' => $allPurchased
        ]);
    }

    /**
     * display Sales & profit Charts
     * 
     */
    public function displayCharts(Request $request)
    {
        $selectedPeriod = $request->input('selectedperiod');

        if ($selectedPeriod !='') {
            $year = Carbon::now()->year;
            $startOfMonth = Carbon::create($year, $selectedPeriod, 1)->startOfMonth();
            $endOfMonth   = Carbon::create($year, $selectedPeriod, 1)->endOfMonth();
            $monthName = Carbon::createFromDate($year, $selectedPeriod, 1)->format('F');
        } else {
            $startOfMonth = Carbon::now()->startOfMonth();
            $endOfMonth = Carbon::now();
            $monthName = Carbon::now()->format('F');
        }
        $allSales = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
            ->where('deleted', 0)
            ->orderBy('invoice_date', 'asc')
            ->get();

        // Generate full date list for the month
        $datesInMonth = [];
        $currentDate = $startOfMonth->copy();
        while ($currentDate <= $endOfMonth) {
            $datesInMonth[] = $currentDate->format('Y-m-d');
            $currentDate->addDay();
        }

        // Create daily sales data (with 0 fallback)
        $salesByDate = [];
        foreach ($datesInMonth as $date) {
            $salesForDate = $allSales->where('invoice_date', $date);
            $salesByDate[] = [
                'date' => $date,
                'net_amount' => $salesForDate->sum('net_amount'),
                'profit' => $salesForDate->sum('profit'),
            ];
        }

        /** ------------------------------
         * LAST 12 MONTHS BAR CHART DATA
         * ------------------------------ */
        $monthlySales = Invoice::select(
                DB::raw("DATE_FORMAT(invoice_date, '%b %Y') as month"),
                DB::raw("SUM(net_amount) as total_sales"),
                DB::raw("SUM(profit) as total_profit"),
                DB::raw("DATE_FORMAT(invoice_date, '%Y-%m') as sort_key")
            )
            ->where('deleted', 0)
            ->whereRaw("invoice_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)")
            ->groupBy('month', 'sort_key')
            ->orderBy('sort_key', 'asc')
            ->get();

        $highestMonthlySales = Invoice::select(
            DB::raw("DATE_FORMAT(invoice_date, '%b %Y') as month_name"),
            DB::raw("SUM(net_amount) as total_sales"),
            DB::raw("SUM(profit) as total_profit"),
            DB::raw("DATE_FORMAT(invoice_date, '%Y-%m') as sort_key")
        )
        ->where('deleted', 0)
        ->groupBy('month_name', 'sort_key')
        ->orderBy('total_sales', 'DESC')
        ->first();

        return view('reports.saleschart', [
            'salesData' => json_encode($salesByDate),
            'allSales' => json_encode($allSales), // ✅ fix: also pass raw sales
            'monthlySales'   => json_encode($monthlySales),   // ✅ BAR CHART DATA
            'monthName' => $monthName,
            'selectedPeriod' => $selectedPeriod,
            'highestMonthlySales' => $highestMonthlySales
        ]);
    }

    public function customers()
    {
        $customers = Customer::withCount(['invoices' => function ($query) {
                $query->where('deleted', 0);
            }])
            ->selectSub(
                Invoice::selectRaw('COALESCE(SUM(net_amount), 0)')
                    ->whereColumn('customer_id', 'customers.id')
                    ->where('deleted', 0),
                'total_spent'
            )
            ->selectSub(
                Invoice::selectRaw('MAX(invoice_date)')
                    ->whereColumn('customer_id', 'customers.id')
                    ->where('deleted', 0),
                'last_invoice_date'
            )
            ->whereHas('invoices', function ($query) {
                $query->where('deleted', 0);
            })
            ->orderByDesc('last_invoice_date')
            ->orderByDesc('id')
            ->get();

        return view('reports.customers', ['customers' => $customers, 'totalcustomers' => $customers->count()]);
    }

    public function exportcustomers()
    {
        $customers = Customer::whereHas('invoices', function ($query) {
                $query->where('deleted', 0);
            })
            ->orderBy('name')
            ->get();
        $fileName = 'vision-customers.csv';
        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );
        $callback = function() use ($customers) {
            $file = fopen('php://output', 'w+');

            // Add the CSV header (modify this based on your model)
            fputcsv($file, 
                [
                    'ID', 
                    'Customer Name', 
                    'Contact Number'
                ], 
                ';'
            );

            // Add the data rows
            foreach ($customers as $key=>$row) {
                fputcsv($file, [
                    $key+1,
                    $row->name,
                    $row->phone
                ], ';');
            }
            fclose($file);
        };
        return Response::stream($callback, 200, $headers);
    }

    /**
     * Analytics page for super-admin only
     * Shows total sales, total profit, total expense, and net profit
     */
    public function analytics(Request $request)
    {
        $period = $request->input('period', 'thisyear');
        $fromDate = $request->input('fromdate');
        $toDate = $request->input('todate');
        $monthlyData = [];

        // Helper function to get month data
        $getMonthData = function($year, $month) {
            $startOfMonth = Carbon::create($year, $month, 1)->startOfMonth();
            $endOfMonth = Carbon::create($year, $month, 1)->endOfMonth();
            $monthName = $startOfMonth->format('F Y');

            $totalSales = Invoice::whereYear('invoice_date', $year)
                ->whereMonth('invoice_date', $month)
                ->where('deleted', 0)
                ->sum('net_amount');

            $totalProfit = Invoice::whereYear('invoice_date', $year)
                ->whereMonth('invoice_date', $month)
                ->where('deleted', 0)
                ->sum('profit');

            $totalRepairing = Repairing::whereYear('repairing_date', $year)
                ->whereMonth('repairing_date', $month)
                ->where('deleted', 0)
                ->sum('amount');

            $totalExpense = Expense::whereYear('entrydate', $year)
                ->whereMonth('entrydate', $month)
                ->where('deleted', 0)
                ->sum('amount');

            $netProfit = $totalProfit - $totalExpense + $totalRepairing;

            return [
                'monthName'     => $monthName,
                'totalSales'    => $totalSales,
                'totalProfit'   => $totalProfit,
                'totalExpense'  => $totalExpense,
                'netProfit'     => $netProfit,
                'totalRepairing' => $totalRepairing
            ];
        };

        if ($period === 'thisyear') {
            // Get all months from current year up to current month
            $currentYear = Carbon::now()->year;
            $currentMonth = Carbon::now()->month;

            for ($month = 1; $month <= $currentMonth; $month++) {
                $monthlyData[] = $getMonthData($currentYear, $month);
            }

            // Reverse to show current month first
            $monthlyData = array_reverse($monthlyData);
        } elseif ($period === 'lastyear') {
            // Get all 12 months from last year (January to December)
            $lastYear = Carbon::now()->subYear()->year;

            for ($month = 12; $month >= 1; $month--) {
                $monthlyData[] = $getMonthData($lastYear, $month);
            }
        } elseif ($period === 'lastmonth') {
            // Get last month only
            $lastMonth = Carbon::now()->subMonth();
            $monthlyData[] = $getMonthData($lastMonth->year, $lastMonth->month);
        } elseif ($period === 'last3months') {
            // Get last 3 months
            for ($i = 2; $i >= 0; $i--) {
                $date = Carbon::now()->subMonths($i);
                $monthlyData[] = $getMonthData($date->year, $date->month);
            }
        } elseif ($period === 'last6months') {
            // Get last 6 months
            for ($i = 5; $i >= 0; $i--) {
                $date = Carbon::now()->subMonths($i);
                $monthlyData[] = $getMonthData($date->year, $date->month);
            }
        } elseif ($period === 'custom') {
            if ($fromDate && $toDate) {
                $start = Carbon::parse($fromDate);
                $end = Carbon::parse($toDate);

                // Get all months between the date range
                $current = $start->copy()->startOfMonth();

                while ($current->lte($end)) {
                    $monthlyData[] = $getMonthData($current->year, $current->month);
                    $current->addMonth();
                }

                // Reverse to show latest first
                $monthlyData = array_reverse($monthlyData);
            }
        }

        return view('reports.analytics', [
            'period' => $period,
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'monthlyData' => $monthlyData,
        ]);
    }
}
