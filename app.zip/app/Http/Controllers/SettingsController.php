<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Settings;

class SettingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $business = Settings::first() ?: new Settings();
        return view('settings.business', compact('business'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'businessname'=> 'required|string',
            'phone'=> 'required',
            'email'=> 'nullable|email',
            'billing_address'=> 'nullable|string',
            'city'=> 'required',
            'state'=> 'nullable',
            'pincode'=> 'required',
            'logo' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:1024',
        ]);
        // Check if record exists
        $business = Settings::first() ?: new Settings();

        $business->business_name = $request->businessname;
        $business->phone = $request->phone;
        $business->email = $request->email;
        $business->billing_address = $request->billing_address;
        $business->state = $request->state;
        $business->city = $request->city;
        $business->pincode = $request->pincode;
        $business->is_gst_registered = $request->is_gst_registered == 'on' ? 1 : 0;
        $business->gstin = $business->is_gst_registered ? $request->gstin : null;

        if ($request->hasFile('logo')) {
            $file = $request->file('logo');

            if ($business->logo && file_exists(public_path($business->logo))) {
                @unlink(public_path($business->logo));
            }

            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('documents/business/'), $filename);
            $business->logo = 'documents/business/'.$filename;
        }

        $business->save();

        return redirect()->route('managebusiness')->withStatus('Business settings saved successfully!');
    }
}
