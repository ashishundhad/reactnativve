<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\Purchase;
use Illuminate\Http\Request;

class GlobalSearchController extends Controller
{
    public function index(Request $request)
    {
        $query = trim((string) $request->input('q'));
        $user = $request->user();
        // $canViewPurchases = $user?->can('purchases.view') ?? false;
        // $canOpenInvoiceDetail = $user?->can('invoices.detail') ?? false;
        // $canViewInvoices = ($user?->can('invoices.view') ?? false) || $canOpenInvoiceDetail;

        // abort_unless($canViewPurchases || $canViewInvoices, 403);

        $purchaseResults = collect();
        $invoiceResults = collect();

        if ($query !== '') {
            // if ($canViewPurchases) {
                $purchaseResults = Purchase::query()
                    ->where('deleted', 0)
                    ->where(function ($searchQuery) use ($query) {
                        $searchQuery->where('id', 'like', '%' . $query . '%')
                            ->orWhere('imei', 'like', '%' . $query . '%')
                            ->orWhere('model', 'like', '%' . $query . '%')
                            ->orWhere('purchase_from', 'like', '%' . $query . '%')
                            ->orWhere('contactno', 'like', '%' . $query . '%')
                            ->orWhere('remark', 'like', '%' . $query . '%');
                    })
                    ->orderByDesc('purchase_date')
                    ->limit(15)
                    ->get();
            // }

            // if ($canViewInvoices) {
                $invoiceResults = Invoice::query()
                    ->with('customer')
                    ->where('deleted', 0)
                    ->where(function ($searchQuery) use ($query) {
                        $searchQuery->where('id', 'like', '%' . $query . '%')
                            ->orWhere('invoice_no', 'like', '%' . $query . '%')
                            ->orWhere('customer_name', 'like', '%' . $query . '%')
                            ->orWhere('customer_no', 'like', '%' . $query . '%')
                            ->orWhere('item_description', 'like', '%' . $query . '%')
                            ->orWhere('item_id', 'like', '%' . $query . '%')
                            ->orWhereHas('customer', function ($customerQuery) use ($query) {
                                $customerQuery->where('name', 'like', '%' . $query . '%')
                                    ->orWhere('phone', 'like', '%' . $query . '%')
                                    ->orWhere('aadhar_card_number', 'like', '%' . $query . '%');
                            });
                    })
                    ->orderByDesc('invoice_date')
                    ->limit(15)
                    ->get();
            // }
        }

        return view('search.index', [
            'query' => $query,
            'purchaseResults' => $purchaseResults,
            'invoiceResults' => $invoiceResults,
            // 'canViewPurchases' => $canViewPurchases,
            // 'canViewInvoices' => $canViewInvoices,
            // 'canOpenInvoiceDetail' => $canOpenInvoiceDetail,
        ]);
    }
}
